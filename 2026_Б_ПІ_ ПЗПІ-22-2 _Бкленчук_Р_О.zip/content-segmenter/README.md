# Content Segmenter: Text Processing Service

Content Segmenter turns uploaded text into structured chunks for retrieval and test generation workflows.

## Role in Testify

`core-api` calls this service when users upload or process content. The service segments text, then coordinates downstream work with `knowledge-engine` for retrieval workflows and `assessment-generator` for generated questions.

Kubernetes role:

```text
namespace: testify-content
workload: content-segmenter
service: content-segmenter
```

## Technology

- Go HTTP service
- Text segmentation pipeline
- Support for assessment and knowledge-processing flags
- Docker image and Helm chart deployment

## Installation

```bash
cd content-segmenter
go mod tidy
```

## Usage

Run locally:

```bash
task run
```

Run tests:

```bash
task test
```

Build and deploy:

```bash
task docker-push
task helm-upgrade
```

Main endpoint:

```text
POST /process
```

## License

Not specified.
