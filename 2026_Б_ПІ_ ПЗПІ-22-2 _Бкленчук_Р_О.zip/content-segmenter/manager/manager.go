package manager

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// ManagerInterface defines the contract for the Manager.
type ManagerInterface interface {
	BuildQuestions(ctx context.Context, testID string, segments []string, model string) error
}

// Manager forwards question generation work to the horizontally scalable
// question-builder service.
type Manager struct {
	questionBuilderURL string
	httpClient         *http.Client
}

// NewManager initializes a question-builder client.
func NewManager(questionBuilderURL string) *Manager {
	return &Manager{
		questionBuilderURL: questionBuilderURL,
		httpClient: &http.Client{
			Timeout: 2 * time.Minute,
		},
	}
}

type buildQuestionsRequest struct {
	TestID   string   `json:"test_id"`
	Chunks   []string `json:"chunks"`
	Model    string   `json:"model"`
	SourceID string   `json:"source_id,omitempty"`
}

func (m *Manager) BuildQuestions(ctx context.Context, testID string, segments []string, model string) error {
	payload := buildQuestionsRequest{
		TestID:   testID,
		Chunks:   segments,
		Model:    model,
		SourceID: testID,
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("encode question-builder payload: %w", err)
	}

	endpoint := fmt.Sprintf("%s/api/v1/questions/build", m.questionBuilderURL)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("create question-builder request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := m.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("contact question-builder service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusAccepted && resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("question-builder returned status %d: %s", resp.StatusCode, string(respBody))
	}

	return nil
}
