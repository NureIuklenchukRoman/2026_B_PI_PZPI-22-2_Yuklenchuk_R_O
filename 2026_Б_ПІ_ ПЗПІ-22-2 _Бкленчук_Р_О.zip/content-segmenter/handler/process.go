package handler

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	mgr "text-segmenter/manager"
	"text-segmenter/segmenter"

	"github.com/gin-gonic/gin"
)

type ProcessRequest struct {
	Text        string `json:"text" binding:"required"`
	TestID      string `json:"test_id" binding:"required"`
	Window      int    `json:"window" binding:"required,gt=0"`
	Model       string `json:"model" binding:"required"`
	AugmentData bool   `json:"augment_data"`
	CreateTests bool   `json:"create_tests"`
}

func ProcessHandler(manager mgr.ManagerInterface, ragUrl string) gin.HandlerFunc {
	httpClient := &http.Client{
		Timeout: 30 * time.Second,
	}

	return func(c *gin.Context) {
		var req ProcessRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request parameters", "details": err.Error()})
			return
		}

		if !req.AugmentData && !req.CreateTests {
			c.JSON(http.StatusBadRequest, gin.H{"error": "At least one of 'augment_data' or 'create_tests' must be true"})
			return
		}

		log.Printf("Processing TestID: %s | Augment: %v | CreateTests: %v", req.TestID, req.AugmentData, req.CreateTests)

		s := segmenter.NewSegmenter(req.Window)
		segments, err := s.Segment(req.Text)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Segmentation failed", "details": err.Error()})
			return
		}

		if len(segments) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Text segmentation resulted in 0 chunks"})
			return
		}

		var errors []string

		if req.AugmentData {
		        if err := sendToRAG(c, httpClient, ragUrl, req.TestID, segments); err != nil {
		                log.Printf("RAG Error: %v", err)
		                errors = append(errors, fmt.Sprintf("Knowledge base failed: %v", err))
		        }
		}

		if req.CreateTests {
		        if err := manager.BuildQuestions(c.Request.Context(), req.TestID, segments, req.Model); err != nil {
		                log.Printf("Test Gen Error: %v", err)
		                errors = append(errors, fmt.Sprintf("Question generation failed: %v", err))
		        }
		}

		if len(errors) > 0 {
		        status := "partial_success"
		        if (req.AugmentData && req.CreateTests && len(errors) == 2) ||
		           (req.AugmentData && !req.CreateTests && len(errors) == 1) ||
		           (!req.AugmentData && req.CreateTests && len(errors) == 1) {
		                status = "failed"
		                c.JSON(http.StatusInternalServerError, gin.H{
		                        "status":  status,
		                        "error":   "All requested tasks failed",
		                        "details": errors,
		                })
		                return
		        }

		        c.JSON(http.StatusOK, gin.H{
		                "status":  status,
		                "test_id": req.TestID,
		                "chunks":  len(segments),
		                "message": "Some tasks failed",
		                "details": errors,
		        })
		        return
		}

		c.JSON(http.StatusOK, gin.H{
		        "status":  "success",
		        "test_id": req.TestID,
		        "chunks":  len(segments),
		})
		}
		}
func sendToRAG(c *gin.Context, client *http.Client, ragUrl, testID string, segments []string) error {
	log.Printf("Sending %d chunks to RAG service for TestID: %s", len(segments), testID)

	ragPayload := map[string]interface{}{
		"knowledgeId": testID,
		"chunks":      segments,
	}

	payloadBytes, err := json.Marshal(ragPayload)
	if err != nil {
		return fmt.Errorf("encode payload: %w", err)
	}

	ragEndpoint := fmt.Sprintf("%s/api/v1/knowledge", ragUrl)

	reqHTTP, err := http.NewRequestWithContext(c.Request.Context(), http.MethodPost, ragEndpoint, bytes.NewBuffer(payloadBytes))
	if err != nil {
		return fmt.Errorf("create request: %w", err)
	}
	reqHTTP.Header.Set("Content-Type", "application/json")

	resp, err := client.Do(reqHTTP)
	if err != nil {
		return fmt.Errorf("contact RAG service: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusAccepted && resp.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("RAG returned status %d: %s", resp.StatusCode, string(bodyBytes))
	}

	log.Printf("Successfully augmented data in RAG service for TestID: %s", testID)
	return nil
}
