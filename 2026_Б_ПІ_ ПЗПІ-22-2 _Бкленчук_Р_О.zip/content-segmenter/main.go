package main

import (
	"flag"
	"log"

	"github.com/gin-gonic/gin"
	"text-segmenter/handler"
	mgr "text-segmenter/manager"
)

func main() {
	port := flag.String("port", ":8080", "Port to listen on")
	ragUrl := flag.String("rag-url",
		"http://knowledge-engine.testify-knowledge.svc.cluster.local:8080", "URL for the rag engine")
	questionBuilderURL := flag.String("question-builder-url",
		"http://assessment-generator.testify-assessment.svc.cluster.local:80", "URL for the question-builder service")

	flag.Parse()

	manager := mgr.NewManager(*questionBuilderURL)

	router := gin.Default()

	router.GET("/healthz", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "healthy"})
	})
	router.POST("/process", handler.ProcessHandler(manager, *ragUrl))

	log.Printf("Listening on %s", *port)
	if err := router.Run(*port); err != nil {
		log.Fatalf("Server failed: %v", err)
	}
}
