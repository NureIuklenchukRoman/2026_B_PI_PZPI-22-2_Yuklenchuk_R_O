package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"rag-engine-main/connector"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
)

func main() {
	qdrantAddr := getEnvOrDefault("QDRANT_GRPC_ADDR", "localhost:6334")
	ollamaAddr := getEnvOrDefault("OLLAMA_URL", "http://localhost:11434")
	keyStoreURL := getEnvOrDefault("KEY_STORE_URL", "http://localhost:8000")
	openRouterModel := getEnvOrDefault("OPENROUTER_MODEL", "openrouter/free")
	collectionName := getEnvOrDefault("QDRANT_COLLECTION", "rag_knowledge")

	vectorDB, err := connector.NewQdrantDB(qdrantAddr, collectionName)
	if err != nil {
		log.Fatalf("Failed to connect to Qdrant at %s: %v", qdrantAddr, err)
	}
	defer vectorDB.Close()

	embedderModel := getEnvOrDefault("OLLAMA_MODEL", "nomic-embed-text")
	embedder := connector.NewOllamaEmbedder(ollamaAddr, embedderModel)

	openRouterClient := connector.NewOpenRouterClient(keyStoreURL, openRouterModel)

	ragService := NewRAGService(embedder, vectorDB, openRouterClient)
	router := gin.Default()

	router.GET("/healthz", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "healthy"})
	})

	api := router.Group("/api/v1")
	{
		api.POST("/knowledge", handlePutKnowledge(ragService))
		api.DELETE("/knowledge/:id", handleRemoveKnowledge(ragService))
		api.GET("/retrieve", handleRetrieve(ragService))
	}

	srv := &http.Server{
		Addr:    ":8080",
		Handler: router,
	}

	go func() {
		log.Printf("Starting RAG API server on port 8080...")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Listen error: %s\n", err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("Server forced to shutdown:", err)
	}
	log.Println("Server exiting cleanly")
}

func getEnvOrDefault(key, fallback string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return fallback
}
