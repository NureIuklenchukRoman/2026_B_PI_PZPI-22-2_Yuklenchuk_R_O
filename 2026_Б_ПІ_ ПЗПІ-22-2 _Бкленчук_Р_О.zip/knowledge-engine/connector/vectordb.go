package connector

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/google/uuid"
	"github.com/qdrant/go-client/qdrant"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type QdrantDB struct {
	client     qdrant.PointsClient
	conn       *grpc.ClientConn
	collection string
}

func NewQdrantDB(address, collectionName string) (*QdrantDB, error) {
	conn, err := grpc.Dial(address, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, fmt.Errorf("failed to connect to qdrant: %w", err)
	}

	// Create a collections client to manage schema
	collectionsClient := qdrant.NewCollectionsClient(conn)

	// Context with timeout for startup operations
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// 1. Check if the collection already exists
	existsResp, err := collectionsClient.CollectionExists(ctx, &qdrant.CollectionExistsRequest{
		CollectionName: collectionName,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to check if collection exists: %w", err)
	}

	// 2. If it does not exist, create it with the correct Vector dimensions
	if !existsResp.GetResult().GetExists() {
		log.Printf("Collection '%s' not found. Creating it now...", collectionName)
		_, err = collectionsClient.Create(ctx, &qdrant.CreateCollection{
			CollectionName: collectionName,
			VectorsConfig: &qdrant.VectorsConfig{
				Config: &qdrant.VectorsConfig_Params{
					Params: &qdrant.VectorParams{
						Size:     768, // nomic-embed-text outputs 768-dimensional vectors
						Distance: qdrant.Distance_Cosine,
					},
				},
			},
		})
		if err != nil {
			return nil, fmt.Errorf("failed to create collection: %w", err)
		}
		log.Printf("Collection '%s' created successfully.", collectionName)
	}

	return &QdrantDB{
		client:     qdrant.NewPointsClient(conn),
		conn:       conn,
		collection: collectionName,
	}, nil
}

func (db *QdrantDB) Close() {
	_ = db.conn.Close()
}

func (db *QdrantDB) Upsert(ctx context.Context, knowledgeID string, chunkID int, vector []float32, text string) error {
	pointID := uuid.New().String()

	payload := map[string]*qdrant.Value{
		"text":        {Kind: &qdrant.Value_StringValue{StringValue: text}},
		"knowledgeId": {Kind: &qdrant.Value_StringValue{StringValue: knowledgeID}},
		"chunkId":     {Kind: &qdrant.Value_IntegerValue{IntegerValue: int64(chunkID)}},
	}

	_, err := db.client.Upsert(ctx, &qdrant.UpsertPoints{
		CollectionName: db.collection,
		Points: []*qdrant.PointStruct{
			{
				Id:      &qdrant.PointId{PointIdOptions: &qdrant.PointId_Uuid{Uuid: pointID}},
				Vectors: &qdrant.Vectors{VectorsOptions: &qdrant.Vectors_Vector{Vector: &qdrant.Vector{Data: vector}}},
				Payload: payload,
			},
		},
	})

	return err
}

func (db *QdrantDB) Search(ctx context.Context, knowledgeID string, vector []float32, limit int) ([]string, error) {
        var filter *qdrant.Filter
        if knowledgeID != "" && knowledgeID != "-1" {
                filter = &qdrant.Filter{
                        Must: []*qdrant.Condition{
                                {
                                        ConditionOneOf: &qdrant.Condition_Field{
                                                Field: &qdrant.FieldCondition{
                                                        Key: "knowledgeId",
                                                        Match: &qdrant.Match{
                                                                MatchValue: &qdrant.Match_Keyword{
                                                                        Keyword: knowledgeID,
                                                                },
                                                        },
                                                },
                                        },
                                },
                        },
                }
        }

        searchResult, err := db.client.Search(ctx, &qdrant.SearchPoints{
                CollectionName: db.collection,
                Vector:         vector,
                Filter:         filter,
                Limit:          uint64(limit),
                WithPayload:    &qdrant.WithPayloadSelector{SelectorOptions: &qdrant.WithPayloadSelector_Enable{Enable: true}},
        })
        if err != nil {
		return nil, fmt.Errorf("qdrant search failed: %w", err)
	}

	var chunks []string
	for _, point := range searchResult.GetResult() {
		if textValue, ok := point.Payload["text"]; ok {
			chunks = append(chunks, textValue.GetStringValue())
		}
	}

	return chunks, nil
}

func (db *QdrantDB) Delete(ctx context.Context, knowledgeID string) error {
	_, err := db.client.Delete(ctx, &qdrant.DeletePoints{
		CollectionName: db.collection,
		Points: &qdrant.PointsSelector{
			PointsSelectorOneOf: &qdrant.PointsSelector_Filter{
				Filter: &qdrant.Filter{
					Must: []*qdrant.Condition{
						{
							ConditionOneOf: &qdrant.Condition_Field{
								Field: &qdrant.FieldCondition{
									Key: "knowledge_id",
									Match: &qdrant.Match{
										MatchValue: &qdrant.Match_Keyword{Keyword: knowledgeID},
									},
								},
							},
						},
					},
				},
			},
		},
	})
	return err
}
