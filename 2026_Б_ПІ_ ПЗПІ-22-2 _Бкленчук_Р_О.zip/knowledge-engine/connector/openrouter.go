package connector

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
)

type OpenRouterClient struct {
	keyStoreURL string
	model       string
	httpClient  *http.Client
}

// NewOpenRouterClient creates a new client for OpenRouter.
func NewOpenRouterClient(keyStoreURL, model string) *OpenRouterClient {
	return &OpenRouterClient{
		keyStoreURL: keyStoreURL,
		model:       model,
		httpClient:  &http.Client{Timeout: 90 * time.Second},
	}
}

// getAPIKey dynamically fetches the key from your python key store.
func (c *OpenRouterClient) getAPIKey(ctx context.Context) (string, error) {
	reqCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(reqCtx, http.MethodGet, fmt.Sprintf("%s/getkey", c.keyStoreURL), nil)
	if err != nil {
		return "", fmt.Errorf("failed to create key request: %w", err)
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("failed to fetch key: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("key store returned status %d", resp.StatusCode)
	}

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read key response: %w", err)
	}

	rawResponse := string(bodyBytes)

	log.Printf("DEBUG KeyStore Raw Response: '%s'", rawResponse)

	var key string

	var jsonResp map[string]string
	if err := json.Unmarshal(bodyBytes, &jsonResp); err == nil {
		for k, v := range jsonResp {
			if strings.Contains(strings.ToLower(k), "key") || strings.Contains(strings.ToLower(k), "token") {
				key = v
				break
			}
		}
	}

	if key == "" {
		key = rawResponse
	}

	key = strings.TrimSpace(key)
	key = strings.ReplaceAll(key, "\n", "")
	key = strings.ReplaceAll(key, "\r", "")
	key = strings.ReplaceAll(key, "\"", "")
	key = strings.ReplaceAll(key, "'", "")

	if key == "" {
		return "", fmt.Errorf("key store returned an empty key after cleaning")
	}

	return key, nil
}

// GenerateAnswer compiles the chunks and questions, fetches the key, and calls OpenRouter.
func (c *OpenRouterClient) GenerateAnswer(ctx context.Context, chunks []string, question string) (string, error) {
	apiKey, err := c.getAPIKey(ctx)
	if err != nil {
		return "", err
	}

	contextText := strings.Join(chunks, "\n\n---\n\n")

	prompt := fmt.Sprintf(`You are a helpful and knowledgeable assistant. 
Answer the user's question using ONLY the provided context. 
CRITICAL INSTRUCTION: Reply naturally and directly. NEVER mention the context, the provided text, or use phrases like "Based on the provided context", "According to the text", or "As stated". Just give the answer directly as if you knew it yourself.
If the context does not contain the answer, say "I don't have enough information to answer that." Do not use outside knowledge.

Context:
%s

Question: %s
Answer:`, contextText, question)

	payload := map[string]interface{}{
		"model": c.model,
		"messages": []map[string]string{
			{"role": "user", "content": prompt},
		},
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://openrouter.ai/api/v1/chat/completions", bytes.NewReader(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+apiKey)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("HTTP-Referer", "http://localhost:8080")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := io.ReadAll(resp.Body)
		return "", fmt.Errorf("openrouter error %d: %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", err
	}

	if len(result.Choices) == 0 {
		return "", fmt.Errorf("openrouter returned no choices")
	}

	return result.Choices[0].Message.Content, nil
}
