package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// PutRequest represents the incoming JSON payload for indexing knowledge.
type PutRequest struct {
	KnowledgeID string   `json:"knowledgeId" binding:"required"`
	Chunks      []string `json:"chunks" binding:"required,gt=0"`
}

// handlePutKnowledge processes the insertion of text chunks into the vector database.
func handlePutKnowledge(service *RAGService) gin.HandlerFunc {
	return func(c *gin.Context) {
		var req PutRequest

		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request payload: " + err.Error()})
			return
		}

		if err := service.PutKnowledge(c.Request.Context(), req.Chunks, req.KnowledgeID); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to process knowledge chunks: " + err.Error()})
			return
		}

		c.JSON(http.StatusAccepted, gin.H{
			"status":      "indexed successfully",
			"knowledgeId": req.KnowledgeID,
			"chunksCount": len(req.Chunks),
		})
	}
}

// handleRemoveKnowledge processes the deletion of knowledge by its ID.
func handleRemoveKnowledge(service *RAGService) gin.HandlerFunc {
	return func(c *gin.Context) {
		knowledgeID := c.Param("id")
		if knowledgeID == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Knowledge ID is required"})
			return
		}

		if err := service.Remove(c.Request.Context(), knowledgeID); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to remove knowledge: " + err.Error()})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"status":      "removed successfully",
			"knowledgeId": knowledgeID,
		})
	}
}

// handleRetrieve handles semantic search queries strictly within a specific knowledge ID.
func handleRetrieve(service *RAGService) gin.HandlerFunc {
	return func(c *gin.Context) {
		knowledgeID := c.Query("knowledgeId")
		if knowledgeID == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "The 'knowledgeId' query parameter is required"})
			return
		}

		question := c.Query("question")
		if question == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "The 'question' query parameter is required"})
			return
		}

		answer, chunks, err := service.Retrieve(c.Request.Context(), knowledgeID, question)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Retrieval failed: " + err.Error()})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"knowledgeId": knowledgeID,
			"question":    question,
			"answer":      answer,
			"chunks":      chunks,
		})
	}
}
