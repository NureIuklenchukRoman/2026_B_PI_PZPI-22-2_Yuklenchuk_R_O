package main

import (
	"context"
	"fmt"
	"sync"
)

// Embedder generates vector representations (Ollama)
type Embedder interface {
	Embed(ctx context.Context, text string) ([]float32, error)
}

// VectorDB stores and searches vectors (Qdrant)
type VectorDB interface {
	Upsert(ctx context.Context, knowledgeID string, chunkID int, vector []float32, payload string) error
	Delete(ctx context.Context, knowledgeID string) error
	Search(ctx context.Context, knowledgeID string, vector []float32, limit int) ([]string, error)
}

// Generator synthesizes the final answer (OpenRouter)
type Generator interface {
	GenerateAnswer(ctx context.Context, chunks []string, question string) (string, error)
}

// RAGService orchestrates Embedder, DB, and Generator.
type RAGService struct {
	embedder  Embedder
	db        VectorDB
	generator Generator
}

func NewRAGService(e Embedder, db VectorDB, g Generator) *RAGService {
	return &RAGService{embedder: e, db: db, generator: g}
}

func (s *RAGService) PutKnowledge(ctx context.Context, chunks []string, knowledgeID string) error {
	errChan := make(chan error, len(chunks))
	var wg sync.WaitGroup

	const maxConcurrentTasks = 10
	sem := make(chan struct{}, maxConcurrentTasks)

	for i, chunk := range chunks {
		wg.Add(1)
		go func(chunkIndex int, textChunk string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			select {
			case <-ctx.Done():
				errChan <- fmt.Errorf("operation canceled: %w", ctx.Err())
				return
			default:
			}

			vector, err := s.embedder.Embed(ctx, textChunk)
			if err != nil {
				errChan <- fmt.Errorf("embedding failed for chunk %d: %w", chunkIndex, err)
				return
			}

			if err := s.db.Upsert(ctx, knowledgeID, chunkIndex, vector, textChunk); err != nil {
				errChan <- fmt.Errorf("upsert failed for chunk %d: %w", chunkIndex, err)
				return
			}
		}(i, chunk)
	}

	wg.Wait()
	close(errChan)

	for err := range errChan {
		if err != nil {
			return err
		}
	}
	return nil
}

func (s *RAGService) Remove(ctx context.Context, knowledgeID string) error {
	return s.db.Delete(ctx, knowledgeID)
}

// Retrieve returns the generated answer and the source chunks used, strictly filtered by knowledgeID
func (s *RAGService) Retrieve(ctx context.Context, knowledgeID, question string) (string, []string, error) {
	vector, err := s.embedder.Embed(ctx, question)
	if err != nil {
		return "", nil, fmt.Errorf("failed to embed question: %w", err)
	}

	const limit = 5
	chunks, err := s.db.Search(ctx, knowledgeID, vector, limit)
	if err != nil {
		return "", nil, fmt.Errorf("failed to search vector database: %w", err)
	}

	if len(chunks) == 0 {
		return "I could not find any relevant knowledge to answer your question.", nil, nil
	}

	// 3. Generate Answer using OpenRouter
	answer, err := s.generator.GenerateAnswer(ctx, chunks, question)
	if err != nil {
		return "", chunks, fmt.Errorf("failed to generate answer: %w", err)
	}

	return answer, chunks, nil
}
