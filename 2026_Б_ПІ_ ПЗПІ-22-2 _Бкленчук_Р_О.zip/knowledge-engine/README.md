# Knowledge Engine: Retrieval Service

Knowledge Engine provides retrieval and embedding support for Testify knowledge workflows.

## Role in Testify

`content-segmenter` and `core-api` use this service for knowledge-backed interactions. It connects the application to vector search and embedding infrastructure, returning ranked context for chat and retrieval-assisted workflows. It uses `credential-store` for external model credentials.

Kubernetes role:

```text
namespace: testify-knowledge
workloads: knowledge-engine, knowledge-vector-db, knowledge-embedder
services: knowledge-engine, knowledge-vector-db, knowledge-embedder
```

## Technology

- Go HTTP service
- Vector retrieval integration
- Ollama-based embedder image
- Qdrant-compatible vector database service
- Docker images for API and embedder
- Helm chart deployment

## Installation

```bash
cd knowledge-engine
go mod tidy
```

## Usage

Build API image:

```bash
task docker-build-api
```

Push and deploy:

```bash
task docker-push
task helm-upgrade
```

Build and push embedder image:

```bash
task docker-push-ollama
```

## License

Apache License 2.0.
