"""Smoke test that proves the test harness works end-to-end.

Imports the FastAPI app, asserts a route is mounted, and exercises a
request that does NOT touch the database (validation rejection).
"""

from fastapi.testclient import TestClient

from app.api.tests.listing_service import TestListingService
from app.db.session import get_db
from app.main import app


def test_app_has_expected_routers():
    paths = {route.path for route in app.routes}
    assert "/auth/login" in paths
    assert "/users/me" in paths
    assert "/tests" in paths
    assert "/tests/" in paths
    assert "/parse-jobs/text" in paths
    assert "/parse-jobs/media" in paths


def test_login_rejects_empty_body():
    client = TestClient(app)
    response = client.post("/auth/login", data={})
    assert response.status_code == 422


def test_tests_list_route_accepts_no_trailing_slash_without_redirect(monkeypatch):
    async def fake_get_db():
        yield object()

    async def fake_get_tests_list(self, query, user_id=None, is_admin=False):
        return []

    monkeypatch.setattr(TestListingService, "get_tests_list", fake_get_tests_list)
    app.dependency_overrides[get_db] = fake_get_db
    client = TestClient(app)
    try:
        response = client.get("/tests?page=1&page_size=10", follow_redirects=False)
    finally:
        app.dependency_overrides.pop(get_db, None)

    assert response.status_code == 200
