"""Shared pytest fixtures.

Stubs required env vars and provides an in-memory SQLite-backed
AsyncSession fixture for integration tests. Production runs against
Postgres; the only column types that aren't portable are UUID and
ARRAY, which we override at DDL compile time so the same models can
target both backends.
"""

from __future__ import annotations

import os

# Stub required env vars before app modules import settings.
os.environ.setdefault("SECRET_JWT_KEY", "test-secret-do-not-use-in-prod")
os.environ.setdefault("JWT_ALGORITHM", "HS256")
os.environ.setdefault("ACCESS_TOKEN_EXPIRE_MINUTES", "15")
os.environ.setdefault("REFRESH_TOKEN_EXPIRE_MINUTES", "10080")

from collections.abc import AsyncGenerator  # noqa: E402

import pytest_asyncio  # noqa: E402
from sqlalchemy.ext.asyncio import (  # noqa: E402
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

import app.db.models  # noqa: E402, F401  # registers ORM classes with Base.metadata
from app.db.base import Base  # noqa: E402


@pytest_asyncio.fixture
async def db() -> AsyncGenerator[AsyncSession, None]:
    """Fresh in-memory SQLite per test, with all tables created."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:", future=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with Session() as session:
        yield session
    await engine.dispose()
