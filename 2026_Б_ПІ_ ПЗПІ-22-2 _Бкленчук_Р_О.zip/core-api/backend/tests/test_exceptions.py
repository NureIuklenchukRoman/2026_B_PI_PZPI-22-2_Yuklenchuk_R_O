"""Verify the DomainError handler maps service-layer raises to the
right HTTP status codes."""

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.core.exceptions import (
    ConflictError,
    DomainError,
    ForbiddenError,
    NotFoundError,
)
from app.main import _domain_error_handler


def _client_for(error: Exception) -> TestClient:
    app = FastAPI()
    app.add_exception_handler(DomainError, _domain_error_handler)

    @app.get("/boom")
    async def boom():
        raise error

    return TestClient(app)


def test_domain_error_maps_to_400():
    response = _client_for(DomainError("bad input")).get("/boom")
    assert response.status_code == 400
    assert response.json() == {"detail": "bad input"}


def test_not_found_maps_to_404():
    response = _client_for(NotFoundError("test gone")).get("/boom")
    assert response.status_code == 404
    assert response.json() == {"detail": "test gone"}


def test_forbidden_maps_to_403():
    response = _client_for(ForbiddenError("not yours")).get("/boom")
    assert response.status_code == 403
    assert response.json() == {"detail": "not yours"}


def test_conflict_maps_to_409():
    response = _client_for(ConflictError("dupe")).get("/boom")
    assert response.status_code == 409
    assert response.json() == {"detail": "dupe"}
