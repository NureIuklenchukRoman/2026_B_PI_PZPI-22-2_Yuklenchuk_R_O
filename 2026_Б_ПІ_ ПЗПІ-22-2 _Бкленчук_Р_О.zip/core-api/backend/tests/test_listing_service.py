"""Coverage for TestListQuery parsing + TestListingService.get_tests_list."""

from __future__ import annotations

import uuid

import pytest

from app.api.tests.listing_service import TestListingService
from app.api.tests.schema import TestListQuery
from app.db.models import UserTests
from app.db.models.test import Option, Question, Test
from app.db.models.user import User


# ---------------- TestListQuery (unit) ----------------


def test_test_list_query_defaults():
    q = TestListQuery()
    assert q.tags is None
    assert q.page == 1
    assert q.page_size == 10


def test_test_list_query_splits_csv_tags():
    q = TestListQuery(tags="foo,bar,baz")
    assert q.tags == ["foo", "bar", "baz"]


def test_test_list_query_normalizes_repeated_form():
    q = TestListQuery(tags=["foo", "bar"])
    assert q.tags == ["foo", "bar"]


def test_test_list_query_treats_empty_tags_as_none():
    q = TestListQuery(tags="")
    assert q.tags is None


def test_test_list_query_strips_empty_csv_chunks():
    q = TestListQuery(tags="foo,,bar")
    assert q.tags == ["foo", "bar"]


# ---------------- TestListingService (integration) ----------------


def _make_test(*, title: str, tags: list[str], is_public: bool = True) -> Test:
    """Build a Test with one Question carrying the given tags so the
    aggregated tag set is deterministic."""
    test = Test(id=str(uuid.uuid4()), title=title, description="", is_public=is_public)
    q = Question(id=str(uuid.uuid4()), test_id=test.id, question="Q", tags=tags)
    q.options.append(Option(id=str(uuid.uuid4()), text="a", correct=True))
    test.questions.append(q)
    return test


@pytest.mark.asyncio
async def test_get_tests_list_empty(db):
    result = await TestListingService(db).get_tests_list(TestListQuery())
    assert result == []


@pytest.mark.asyncio
async def test_returns_tests_with_aggregated_tags(db):
    db.add(_make_test(title="Alpha", tags=["python", "basics"]))
    await db.commit()

    result = await TestListingService(db).get_tests_list(TestListQuery())

    assert len(result) == 1
    assert result[0]["title"] == "Alpha"
    assert sorted(result[0]["tags"]) == ["basics", "python"]


@pytest.mark.asyncio
async def test_filters_by_single_tag(db):
    db.add_all(
        [
            _make_test(title="Alpha", tags=["python"]),
            _make_test(title="Bravo", tags=["python", "advanced"]),
            _make_test(title="Charlie", tags=["javascript"]),
        ]
    )
    await db.commit()

    result = await TestListingService(db).get_tests_list(TestListQuery(tags=["python"]))
    assert {r["title"] for r in result} == {"Alpha", "Bravo"}


@pytest.mark.asyncio
async def test_filters_by_intersection_of_multiple_tags(db):
    db.add_all(
        [
            _make_test(title="Alpha", tags=["python", "basics"]),
            _make_test(title="Bravo", tags=["python", "advanced"]),
            _make_test(title="Charlie", tags=["python"]),
        ]
    )
    await db.commit()

    result = await TestListingService(db).get_tests_list(TestListQuery(tags=["python", "advanced"]))
    assert {r["title"] for r in result} == {"Bravo"}


@pytest.mark.asyncio
async def test_paginates(db):
    for i in range(15):
        db.add(_make_test(title=f"T{i:02d}", tags=["x"]))
    await db.commit()

    page1 = await TestListingService(db).get_tests_list(TestListQuery(page=1, page_size=10))
    page2 = await TestListingService(db).get_tests_list(TestListQuery(page=2, page_size=10))

    assert len(page1) == 10
    assert len(page2) == 5
    assert {r["title"] for r in page1}.isdisjoint({r["title"] for r in page2})


@pytest.mark.asyncio
async def test_anon_sees_only_public_tests(db):
    db.add(_make_test(title="Public", tags=[]))
    db.add(_make_test(title="Private", tags=[], is_public=False))
    await db.commit()

    result = await TestListingService(db).get_tests_list(TestListQuery())
    assert {r["title"] for r in result} == {"Public"}


@pytest.mark.asyncio
async def test_owner_sees_their_private_test(db):
    user_id = uuid.uuid4()
    db.add(User(id=user_id, email="o@example.com", username="owner", password="x"))

    private = _make_test(title="Private", tags=[], is_public=False)
    db.add(private)
    db.add(UserTests(owner_id=user_id, test_id=private.id))
    await db.commit()

    # listing_service accepts a string in production (route source); on
    # SQLite the Uuid bind processor only accepts uuid.UUID, so the test
    # passes the typed value. The service's where(User.id == user_id)
    # works on both types in PG.
    result = await TestListingService(db).get_tests_list(TestListQuery(), user_id=user_id)
    assert {r["title"] for r in result} == {"Private"}


@pytest.mark.asyncio
async def test_allowed_email_grants_access_to_private_test(db):
    user_id = uuid.uuid4()
    db.add(User(id=user_id, email="invited@example.com", username="invited", password="x"))

    private = Test(
        id=str(uuid.uuid4()),
        title="Invitation only",
        description="",
        is_public=False,
        allowed_emails=["invited@example.com"],
    )
    db.add(private)
    await db.commit()

    # listing_service accepts a string in production (route source); on
    # SQLite the Uuid bind processor only accepts uuid.UUID, so the test
    # passes the typed value. The service's where(User.id == user_id)
    # works on both types in PG.
    result = await TestListingService(db).get_tests_list(TestListQuery(), user_id=user_id)
    assert {r["title"] for r in result} == {"Invitation only"}
