"""Owner-side CRUD for tests, questions, and options."""

from __future__ import annotations

from sqlalchemy import exists, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.exceptions import DomainError, NotFoundError
from app.db.models import UserTests
from app.db.models.test import Option as DbOption
from app.db.models.test import Question as DbQuestion
from app.db.models.test import Test as DbTest
from app.db.models.user import User

from ._common import check_is_owner, normalize_emails


class TestCrudService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def edit_test_question(
        self, data: dict, user_id: str, test_id: str, is_admin: bool = False
    ) -> dict:
        await check_is_owner(self.db, user_id, test_id, is_admin=is_admin)

        if not data.get("question"):
            raise DomainError("Question content is required")
        question_id = data.get("question_id")
        if not question_id:
            raise DomainError("question_id is required")

        q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.id == question_id, DbQuestion.test_id == test_id)
            .options(selectinload(DbQuestion.options))
        )
        question = q_res.scalars().first()
        if not question:
            raise NotFoundError("Question not found")

        question.question = data.get("question", question.question)
        question.tags = data.get("tags", question.tags)
        question.options.clear()
        for opt in data.get("options", []):
            question.options.append(
                DbOption(text=opt.get("text", ""), correct=bool(opt.get("correct", False)))
            )
        self.db.add(question)
        return {"id": question.id}

    async def create_test_question(
        self, data: dict, user_id: str, test_id: str, is_admin: bool = False
    ) -> dict:
        await check_is_owner(self.db, user_id, test_id, is_admin=is_admin)

        if not data.get("question"):
            raise DomainError("Question content is required")

        question = DbQuestion(
            test_id=test_id, question=data.get("question", ""), tags=data.get("tags", [])
        )
        for opt in data.get("options", []):
            question.options.append(
                DbOption(text=opt.get("text", ""), correct=bool(opt.get("correct", False)))
            )
        self.db.add(question)
        return {"id": question.id}

    async def edit_test(
        self, test_id: str, body: dict, user_id: str, is_admin: bool = False
    ) -> dict:
        await check_is_owner(self.db, user_id, test_id, is_admin=is_admin)
        if not body.get("title"):
            raise DomainError("Title is required")

        dbtest_res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
        dbtest = dbtest_res.scalars().first()
        if not dbtest:
            raise NotFoundError("Test not found")

        dbtest.title = body.get("title", dbtest.title)
        dbtest.description = body.get("description", dbtest.description)
        if body.get("is_public") is not None:
            dbtest.is_public = body.get("is_public")  # type: ignore[assignment]
        if body.get("allowed_emails") is not None:
            dbtest.allowed_emails = normalize_emails(body.get("allowed_emails"))  # type: ignore[assignment]
        self.db.add(dbtest)
        return {"message": "Test updated successfully"}

    async def fill_test_details(self, test_id: str, body: dict) -> dict:
        res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
        test = res.scalars().first()
        if not test:
            test = DbTest(
                id=test_id, title=body.get("title", ""), description=body.get("description", "")
            )
        else:
            test.title = body.get("title", test.title)
            test.description = body.get("description", test.description)
        self.db.add(test)
        return {"id": test.id, "title": test.title, "description": test.description or ""}

    async def fill_user_test(self, test_id: str, user_id: str) -> None:
        t_res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
        if not t_res.scalars().first():
            raise NotFoundError("Test not found")

        user_exists_res = await self.db.execute(select(exists().where(User.id == user_id)))
        if not user_exists_res.scalar():
            raise NotFoundError("User not found")

        self.db.add(UserTests(owner_id=user_id, test_id=test_id))

    async def delete_test_question(
        self, test_id: str, question_id: str, user_id: str, is_admin: bool = False
    ) -> dict:
        await check_is_owner(self.db, user_id, test_id, is_admin=is_admin)

        q_res = await self.db.execute(
            select(DbQuestion).where(DbQuestion.id == question_id, DbQuestion.test_id == test_id)
        )
        question = q_res.scalars().first()
        if question:
            await self.db.delete(question)
        return {"message": "Question deleted successfully"}

    async def delete_test(self, test_id: str, user_id: str, is_admin: bool = False) -> dict:
        # Soft delete: the Test row is kept (flagged is_deleted=True) so it
        # disappears from catalogs/search/start while take history that
        # references it still resolves its title/questions. Admins delete
        # regardless of ownership.
        if is_admin:
            t_res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
            test = t_res.scalars().first()
            if test:
                test.is_deleted = True  # type: ignore[assignment]
            return {"message": "Test deleted successfully"}

        await check_is_owner(self.db, user_id, test_id)

        # Caller-scoped UserTests row only. The check_is_owner() above
        # proved this row exists; we delete it explicitly rather than
        # .first() across all UserTests rows for this test_id, so we
        # never touch another user's ownership record.
        owner_res = await self.db.execute(
            select(UserTests).where(UserTests.test_id == test_id, UserTests.owner_id == user_id)
        )
        test_owner = owner_res.scalars().first()
        if test_owner:
            await self.db.delete(test_owner)

        # If no other owners remain, mark the test deleted.
        remaining_owners_res = await self.db.execute(
            select(UserTests).where(UserTests.test_id == test_id)
        )
        if remaining_owners_res.scalars().first() is None:
            t_res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
            test = t_res.scalars().first()
            if test:
                test.is_deleted = True  # type: ignore[assignment]
        return {"message": "Test deleted successfully"}

    async def create_test_manually(self, body: dict, user_id: str) -> dict:
        if not body.get("title"):
            raise DomainError("Title is required")

        questions = body.get("questions") or []
        if not questions:
            raise DomainError("At least one question is required")

        test = DbTest(
            title=body.get("title"),
            description=body.get("description", ""),
            is_public=body.get("is_public", True),
            allowed_emails=normalize_emails(body.get("allowed_emails", [])),
        )
        self.db.add(test)
        await self.db.flush()
        test_id = test.id

        for question_data in questions:
            q = DbQuestion(
                test_id=test_id,
                question=question_data.get("question", ""),
                tags=question_data.get("tags", []),
            )
            for opt in question_data.get("options", []):
                q.options.append(
                    DbOption(
                        text=opt.get("text", ""),
                        correct=bool(opt.get("correct", False)),
                    )
                )
            self.db.add(q)

        self.db.add(UserTests(owner_id=user_id, test_id=test_id))

        return {
            "test_id": test_id,
            "title": body.get("title"),
            "description": body.get("description", ""),
            "question_count": len(questions),
        }
