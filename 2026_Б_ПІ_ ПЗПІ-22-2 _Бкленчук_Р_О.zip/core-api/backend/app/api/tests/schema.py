from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class TestGenerationRequest(BaseModel):
    title: str
    description: str | None = None


class TestResponse(BaseModel):
    test_id: str
    title: str
    description: str
    question_amount: int
    created_at: datetime | None = Field(default=None, description="When the test was created")
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )


class TestListQuery(BaseModel):
    """Query params for GET /tests/.

    `tags` may arrive either as repeated ?tags=foo&tags=bar OR as a
    single comma-separated ?tags=foo,bar — the validator normalizes
    both into a list. Empty/missing means no tag filter.

    `q` is a free-text search matched (case-insensitively) against the
    title, description, and tags. `sort` orders the result set.
    """

    q: str | None = Field(default=None, description="Free-text search term")
    tags: list[str] | None = None
    sort: str = Field(
        default="newest",
        description="Sort order: title | questions | newest | oldest",
    )
    page: int = Field(1, ge=1, description="Page number for pagination")
    page_size: int = Field(10, ge=1, le=100, description="Number of items per page")

    @field_validator("tags", mode="before")
    @classmethod
    def _split_csv_tags(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            v = [v]
        return [t for chunk in v for t in str(chunk).split(",") if t.strip()] or None

    @field_validator("q", mode="before")
    @classmethod
    def _blank_q_to_none(cls, v):
        if v is None:
            return None
        v = str(v).strip()
        return v or None

    @field_validator("sort", mode="before")
    @classmethod
    def _normalize_sort(cls, v):
        allowed = {"title", "questions", "newest", "oldest"}
        if v is None:
            return "newest"
        v = str(v).strip().lower()
        return v if v in allowed else "newest"


class EditTestSchema(BaseModel):
    title: str
    description: str | None = None
    is_public: bool | None = None
    allowed_emails: list[str] | None = None


class OptionSchema(BaseModel):
    id: str | None = None
    text: str
    correct: bool | None = False


class EditQuestionSchema(BaseModel):
    question: str
    options: list[OptionSchema]
    tags: list[str] = Field(default_factory=list)
    test_id: str | None = None
    question_id: str | None = None


class SubmitAnswerSchema(BaseModel):
    answers: list[str] = Field(..., description="List of answers submitted by the user")


class CreateTestManuallySchema(BaseModel):
    title: str = Field(..., description="Title of the test")
    description: str | None = Field(None, description="Description of the test")
    is_public: bool = Field(True, description="Whether the test is public or private")
    allowed_emails: list[str] = Field(
        default_factory=list, description="List of emails allowed to access private tests"
    )
    questions: list[EditQuestionSchema] = Field(..., description="List of questions for the test")
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )
