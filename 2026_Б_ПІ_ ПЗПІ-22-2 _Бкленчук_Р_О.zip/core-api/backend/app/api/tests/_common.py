"""Helpers shared by the three test services (crud / listing / session)."""

from __future__ import annotations

import random

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ForbiddenError
from app.db.models import UserTests
from app.db.models.test import Question as DbQuestion
from app.db.models.test import Test as DbTest
from app.db.models.user import User


def serialize_question(
    q: DbQuestion, include_correct: bool = False, shuffle_options: bool = False
) -> dict:
    """Wire-format for a question with its options. Pure function.

    ``include_correct`` controls whether each option's ``correct`` flag is
    exposed. It defaults to False so the test-taking flow never leaks the
    answer key to the client; only the owner-facing edit view passes True.

    ``shuffle_options`` randomizes the option order so the correct answer
    isn't always in the same slot. Grading matches by option id (see
    TestSessionService._check_answer), so order has no effect on scoring;
    the edit view leaves it False to keep a stable order while editing.
    """

    def _option(o: DbQuestion) -> dict:
        data = {"id": o.id, "text": o.text}
        if include_correct:
            data["correct"] = o.correct
        return data

    options = list(q.options)
    if shuffle_options:
        random.shuffle(options)

    return {
        "id": q.id,
        "question": q.question,
        "tags": q.tags or [],
        "options": [_option(o) for o in options],
    }


def normalize_emails(emails: list[str] | None) -> list[str]:
    """Lowercase, trim, drop blanks, de-duplicate — applied before storing an
    allowlist so access matching is consistent regardless of how it was typed."""
    seen: set[str] = set()
    out: list[str] = []
    for e in emails or []:
        v = str(e).strip().lower()
        if v and v not in seen:
            seen.add(v)
            out.append(v)
    return out


def email_in_allowlist(email: str | None, allowed: list[str] | None) -> bool:
    """Case-insensitive membership check. Emails are case-insensitive in
    practice, and the UI lowercases the allowlist, so a creator who lists
    'Bob@X.com' must still match an account stored as 'bob@x.com'."""
    if not email or not allowed:
        return False
    needle = email.strip().lower()
    return any(needle == str(a).strip().lower() for a in allowed)


async def check_test_access(
    db: AsyncSession,
    dbtest: DbTest,
    user_id: str | None,
    is_admin: bool = False,
) -> None:
    """Raises ForbiddenError if the test is private and the caller is
    neither owner nor in allowed_emails. Public tests always pass.
    Admins bypass the privacy check entirely."""
    if is_admin:
        return

    if dbtest.is_public:
        return

    if user_id is not None:
        owner_res = await db.execute(
            select(UserTests).where(UserTests.test_id == dbtest.id, UserTests.owner_id == user_id)
        )
        if owner_res.scalars().first() is not None:
            return

        if dbtest.allowed_emails:
            user_res = await db.execute(select(User).where(User.id == user_id))
            user = user_res.scalars().first()
            if user and email_in_allowlist(user.email, dbtest.allowed_emails):
                return

    raise ForbiddenError("Access denied: This test is private")


async def check_is_owner(
    db: AsyncSession, user_id: str, test_id: str, is_admin: bool = False
) -> None:
    """Raises ForbiddenError if the caller does not own the test.
    Admins bypass the ownership check entirely."""
    if is_admin:
        return
    res = await db.execute(
        select(UserTests).where(UserTests.test_id == test_id, UserTests.owner_id == user_id)
    )
    if res.scalars().first() is None:
        raise ForbiddenError("You are not the owner of this test")
