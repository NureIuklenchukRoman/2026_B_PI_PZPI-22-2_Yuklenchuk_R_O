"""Read-only views over the test catalog: detail pages, edit views,
question counts, and the paginated list."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.exceptions import NotFoundError
from app.db.models import UserTests
from app.db.models.test import Question as DbQuestion
from app.db.models.test import Test as DbTest
from app.db.models.user import User
from app.utils.helpers import collect_tags_from_questions

from ._common import check_test_access, email_in_allowlist, serialize_question
from .schema import TestListQuery


class TestListingService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_test_info(
        self, test_id: str, user_id: str | None = None, is_admin: bool = False
    ) -> dict:
        """Detail view used by the home page."""
        dbtest_res = await self.db.execute(
            select(DbTest).where(DbTest.id == test_id, DbTest.is_deleted.is_(False))
        )
        dbtest = dbtest_res.scalars().first()
        if not dbtest:
            raise NotFoundError("Test not found")

        await check_test_access(self.db, dbtest, user_id, is_admin=is_admin)

        q_res = await self.db.execute(select(DbQuestion).where(DbQuestion.test_id == dbtest.id))
        questions = q_res.scalars().all()
        return {
            "id": dbtest.id,
            "title": dbtest.title,
            "description": dbtest.description or "",
            "question_amount": len(questions),
            "tags": collect_tags_from_questions([{"tags": q.tags or []} for q in questions]),
        }

    async def get_test_info_for_edit(
        self, test_id: str, user_id: str | None = None, is_admin: bool = False
    ) -> dict:
        """Edit view: detail info + privacy fields + every question."""
        test_info = await self.get_test_info(test_id, user_id=user_id, is_admin=is_admin)
        if not test_info:
            raise NotFoundError("Test not found")

        dbtest_res = await self.db.execute(select(DbTest).where(DbTest.id == test_id))
        dbtest = dbtest_res.scalars().first()
        is_public = dbtest.is_public if dbtest else True
        allowed_emails = dbtest.allowed_emails if dbtest and dbtest.allowed_emails else []

        q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.test_id == test_id)
            .options(selectinload(DbQuestion.options))
        )
        questions = q_res.scalars().all()

        return {
            "id": test_info["id"],
            "title": test_info["title"],
            "description": test_info["description"],
            "question_amount": test_info["question_amount"],
            "is_public": is_public,
            "allowed_emails": allowed_emails,
            "tags": test_info["tags"],
            "questions": [serialize_question(q, include_correct=True) for q in questions],
        }

    async def get_questions_amount(self, test_id: str) -> int:
        t_res = await self.db.execute(
            select(DbTest).where(DbTest.id == test_id, DbTest.is_deleted.is_(False))
        )
        if not t_res.scalars().first():
            raise NotFoundError("Test not found")

        q_res = await self.db.execute(select(DbQuestion).where(DbQuestion.test_id == test_id))
        return len(q_res.scalars().all())

    async def get_tests_list(
        self,
        query: TestListQuery,
        user_id: str | None = None,
        is_admin: bool = False,
    ) -> list[dict]:
        """Paginated, tag-filtered test catalog with privacy filtering.

        Tag filter semantics: every tag in query.tags must appear in the
        test's aggregated tag set (intersection match), matching the
        client-side useTestFiltering hook. Admins see every test
        regardless of privacy. Soft-deleted tests are excluded for everyone.
        """
        tests_res = await self.db.execute(select(DbTest).where(DbTest.is_deleted.is_(False)))
        dbtests = tests_res.scalars().all()
        res: list[dict] = []

        user_email: str | None = None
        if user_id is not None:
            user_res = await self.db.execute(select(User).where(User.id == user_id))
            user = user_res.scalars().first()
            if user:
                user_email = str(user.email)

        for t in dbtests:
            if not t.is_public and not is_admin:
                if user_id is None:
                    continue

                owner_res = await self.db.execute(
                    select(UserTests).where(
                        UserTests.test_id == t.id, UserTests.owner_id == user_id
                    )
                )
                is_owner = owner_res.scalars().first() is not None

                is_allowed_by_email = email_in_allowlist(user_email, t.allowed_emails)

                if not is_owner and not is_allowed_by_email:
                    continue

            q_res = await self.db.execute(select(DbQuestion).where(DbQuestion.test_id == t.id))
            qs = q_res.scalars().all()
            test_tags = collect_tags_from_questions([{"tags": q.tags or []} for q in qs])

            if query.tags and not all(tag in test_tags for tag in query.tags):
                continue

            # Free-text search across title, description, and tags.
            if query.q:
                needle = query.q.lower()
                haystack = " ".join(
                    [t.title or "", t.description or "", " ".join(test_tags)]
                ).lower()
                if needle not in haystack:
                    continue

            res.append(
                {
                    "test_id": t.id,
                    "title": t.title,
                    "description": t.description or "",
                    "question_amount": len(qs),
                    "created_at": t.created_at,
                    "tags": test_tags,
                }
            )

        # Server-side ordering. `newest`/`oldest` key off created_at (rows
        # without it sink to the bottom either way); the others are stable.
        epoch = datetime.min
        sort = getattr(query, "sort", "newest")
        if sort == "title":
            res.sort(key=lambda r: (r.get("title") or "").lower())
        elif sort == "questions":
            res.sort(key=lambda r: r.get("question_amount") or 0, reverse=True)
        elif sort == "oldest":
            res.sort(key=lambda r: r.get("created_at") or epoch)
        else:  # newest (default)
            res.sort(key=lambda r: r.get("created_at") or epoch, reverse=True)

        offset = (query.page - 1) * query.page_size
        return res[offset : offset + query.page_size]

    async def get_available_tags(
        self, user_id: str | None = None, is_admin: bool = False
    ) -> list[str]:
        """Distinct tags across every test the caller can access — powers the
        catalog's tag filter independently of the current page/filters."""
        full_query = TestListQuery(page=1, page_size=100, sort="title")
        all_visible: list[dict] = []
        # Walk every page so the tag set covers the whole accessible catalog.
        while True:
            page = await self.get_tests_list(full_query, user_id=user_id, is_admin=is_admin)
            all_visible.extend(page)
            if len(page) < full_query.page_size:
                break
            full_query = full_query.model_copy(update={"page": full_query.page + 1})

        tags: set[str] = set()
        for row in all_visible:
            for tag in row.get("tags") or []:
                tags.add(tag)
        return sorted(tags)
