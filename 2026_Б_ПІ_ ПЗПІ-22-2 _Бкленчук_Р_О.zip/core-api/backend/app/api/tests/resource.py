import logging

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, get_current_user, get_optional_user
from app.db.session import get_db

from .crud_service import TestCrudService
from .listing_service import TestListingService
from .response_schema import TestInfoEditResponse, TestInfoResponse
from .schema import (
    CreateTestManuallySchema,
    EditQuestionSchema,
    EditTestSchema,
    SubmitAnswerSchema,
    TestGenerationRequest,
    TestListQuery,
    TestResponse,
)
from .session_service import TestSessionService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tests", tags=["tests"])


@router.get("", response_model=list[TestResponse], include_in_schema=False)
@router.get("/", response_model=list[TestResponse])
async def get_tests(
    query: TestListQuery = Query(),
    user: AuthUser | None = Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    return await TestListingService(db).get_tests_list(
        query,
        user_id=user.id if user else None,
        is_admin=bool(user and user.is_admin),
    )


@router.get("/tags", response_model=list[str])
async def get_test_tags(
    user: AuthUser | None = Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    """Distinct tags across the accessible catalog, for the filter UI."""
    return await TestListingService(db).get_available_tags(
        user_id=user.id if user else None,
        is_admin=bool(user and user.is_admin),
    )


@router.get("/{test_id}", response_model=TestInfoResponse)
async def get_test(
    test_id: str,
    user: AuthUser | None = Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    test_info = await TestListingService(db).get_test_info(
        test_id,
        user_id=user.id if user else None,
        is_admin=bool(user and user.is_admin),
    )
    if not test_info:
        raise HTTPException(status_code=404, detail="Test not found")
    return TestInfoResponse(
        id=test_info["id"],
        title=test_info["title"],
        description=test_info["description"],
        question_amount=test_info["question_amount"],
        tags=test_info["tags"] or [],
    )


@router.put("/edit-question/{test_id}/{question_id}")
async def edit_test_question(
    test_id: str,
    question_id: str,
    body: EditQuestionSchema,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    updated_body = body.model_copy(update={"test_id": test_id, "question_id": question_id})
    await TestCrudService(db).edit_test_question(
        updated_body.model_dump(), user.id, test_id, is_admin=user.is_admin
    )
    return {"message": "Question edited successfully"}


@router.post("/create-question/{test_id}", status_code=status.HTTP_201_CREATED)
async def create_test_question(
    test_id: str,
    body: EditQuestionSchema,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    updated_body = body.model_copy(update={"test_id": test_id})
    await TestCrudService(db).create_test_question(
        updated_body.model_dump(), user.id, test_id, is_admin=user.is_admin
    )
    return {"message": "Question created successfully"}


@router.get("/tests/edit/{test_id}", response_model=TestInfoEditResponse)
async def get_test_info_for_edit(
    test_id: str,
    user: AuthUser | None = Depends(get_optional_user),
    db: AsyncSession = Depends(get_db),
):
    test_info = await TestListingService(db).get_test_info_for_edit(
        test_id,
        user_id=user.id if user else None,
        is_admin=bool(user and user.is_admin),
    )
    if not test_info:
        raise HTTPException(status_code=404, detail="Test not found")
    return TestInfoEditResponse(
        id=test_info["id"],
        title=test_info["title"],
        description=test_info["description"],
        question_amount=test_info["question_amount"],
        is_public=test_info.get("is_public", True),
        allowed_emails=test_info.get("allowed_emails", []),
        tags=test_info["tags"] or [],
        questions=test_info["questions"] or [],
    )


@router.put("/edit/{test_id}")
async def edit_test(
    test_id: str,
    body: EditTestSchema = Body(),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await TestCrudService(db).edit_test(
        test_id=test_id, body=body.model_dump(), user_id=user.id, is_admin=user.is_admin
    )
    return {"message": "Test edited successfully"}


@router.get("/start-test/{test_id}")
async def start_test(
    test_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await TestSessionService(db).start_test(test_id, user_id=user.id, is_admin=user.is_admin)


@router.get("/{test_id}/questions-amount")
async def get_questions_amount(test_id: str, db: AsyncSession = Depends(get_db)):
    return await TestListingService(db).get_questions_amount(test_id)


@router.post("/{test_id}/submit-answer/{question_id}")
async def submit_answer(
    test_id: str,
    question_id: str,
    body: SubmitAnswerSchema = Body(),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    session = TestSessionService(db)
    await session.handle_answer_submission(
        test_id=test_id, question_id=question_id, answers=body.answers, user_id=user.id
    )
    next_question = await session.select_next_question(
        question_id=question_id,
        test_id=test_id,
        user_answers=body.answers,
        user_id=user.id,
    )
    return next_question or {"message": "No more questions available"}


@router.post("/fill-test-details/{test_id}")
async def fill_test_details(
    test_id: str,
    body: TestGenerationRequest = Body(),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    crud = TestCrudService(db)
    await crud.fill_user_test(test_id=test_id, user_id=user.id)
    await crud.fill_test_details(test_id=test_id, body=body.model_dump())
    return {"message": "Test details filled successfully"}


@router.get("/finish-test/{test_id}")
async def finish_test(
    test_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await TestSessionService(db).finish_test(test_id, user_id=user.id)
    return {"message": "Test finished successfully"}


@router.delete("/delete/{test_id}/{question_id}")
async def delete_test_question(
    test_id: str,
    question_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await TestCrudService(db).delete_test_question(
        test_id, question_id, user.id, is_admin=user.is_admin
    )
    return status.HTTP_204_NO_CONTENT


@router.delete("/delete/{test_id}")
async def delete_test(
    test_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await TestCrudService(db).delete_test(test_id, user.id, is_admin=user.is_admin)
    return status.HTTP_204_NO_CONTENT


@router.post("/create-manually", status_code=status.HTTP_201_CREATED)
async def create_test_manually(
    body: CreateTestManuallySchema = Body(),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await TestCrudService(db).create_test_manually(body.model_dump(), user.id)
