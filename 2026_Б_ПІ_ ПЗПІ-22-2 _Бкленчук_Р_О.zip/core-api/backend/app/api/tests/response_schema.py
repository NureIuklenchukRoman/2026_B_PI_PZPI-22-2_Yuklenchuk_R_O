from pydantic import BaseModel, Field


class TestInfoResponse(BaseModel):
    """
    Response schema for test information.
    """

    id: str
    title: str
    description: str
    question_amount: int
    is_public: bool = Field(default=True, description="Whether the test is public or private")
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )


class TestInfoEditResponse(BaseModel):
    """
    Response schema for test information used in editing.
    """

    id: str
    title: str
    description: str
    question_amount: int
    is_public: bool = Field(default=True, description="Whether the test is public or private")
    allowed_emails: list[str] = Field(
        default_factory=list, description="List of emails allowed to access private tests"
    )
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )
    questions: list[dict] = Field(
        default_factory=list, description="List of questions associated with the test"
    )
