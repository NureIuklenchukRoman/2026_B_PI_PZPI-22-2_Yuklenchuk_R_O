"""Test-taking session lifecycle: start -> submit answers -> finish."""

from __future__ import annotations

import random

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.exceptions import DomainError, NotFoundError
from app.core.time import utcnow
from app.db.models import UserAnswers, UserTakes
from app.db.models.test import Question as DbQuestion
from app.db.models.test import Test as DbTest

from ._common import check_test_access, serialize_question


class TestSessionService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def start_test(self, test_id: str, user_id: str, is_admin: bool = False) -> dict:
        t_res = await self.db.execute(
            select(DbTest).where(DbTest.id == test_id, DbTest.is_deleted.is_(False))
        )
        dbtest = t_res.scalars().first()
        if not dbtest:
            raise NotFoundError("Test not found")

        await check_test_access(self.db, dbtest, user_id, is_admin=is_admin)

        user_take = UserTakes(user_id=user_id, test_id=test_id, completed_at=None)
        self.db.add(user_take)
        # Autoflush makes the row visible to the SELECT below; the
        # request-end commit (in get_db) makes it durable.

        q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.test_id == test_id)
            .options(selectinload(DbQuestion.options))
        )
        questions = q_res.scalars().all()
        if not questions:
            return {"message": "No questions available for this test"}
        return serialize_question(random.choice(questions), shuffle_options=True)

    async def handle_answer_submission(
        self, test_id: str, question_id: str, answers: list[str], user_id: str
    ) -> dict:
        is_correct = await self._check_answer(test_id, question_id, answers)

        user_take_res = await self.db.execute(
            select(UserTakes).where(
                UserTakes.test_id == test_id,
                UserTakes.user_id == user_id,
                UserTakes.completed_at.is_(None),
            )
        )
        user_take = user_take_res.scalars().first()
        if not user_take:
            raise NotFoundError("No active session found for the user and test")

        user_answer = UserAnswers(
            user_take_id=user_take.id, question_id=question_id, answers_ids=answers
        )
        self.db.add(user_answer)
        return {"correct": is_correct}

    async def _check_answer(self, test_id: str, question_id: str, answers: list[str]) -> bool:
        """A submission is correct iff the set of selected option ids
        exactly matches the set of options marked correct on the
        question. Supports both single-correct and multi-correct
        questions; answer order doesn't matter; duplicates in the
        submission don't count.
        """
        if not answers:
            raise DomainError("No answer provided")
        q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.id == question_id, DbQuestion.test_id == test_id)
            .options(selectinload(DbQuestion.options))
        )
        question = q_res.scalars().first()
        if not question:
            raise NotFoundError("Question not found")

        correct_ids = {o.id for o in question.options if o.correct}
        if not correct_ids:
            return False
        return correct_ids == set(answers)

    async def select_next_question(
        self,
        question_id: str,
        test_id: str,
        user_answers: list[str],
        user_id: str,
    ) -> dict | None:
        """Returns the next un-answered question for the active session,
        or auto-completes the session and returns a 'No more questions
        available' marker."""
        session_res = await self.db.execute(
            select(UserTakes).where(
                UserTakes.test_id == test_id,
                UserTakes.user_id == user_id,
                UserTakes.completed_at.is_(None),
            )
        )
        current_session = session_res.scalars().first()
        if not current_session:
            raise NotFoundError("No active session found for the user and test")

        answers_res = await self.db.execute(
            select(UserAnswers).where(UserAnswers.user_take_id == current_session.id)
        )
        answered_ids = {a.question_id for a in answers_res.scalars().all()}

        all_q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.test_id == test_id)
            .options(selectinload(DbQuestion.options))
        )
        all_questions = all_q_res.scalars().all()
        remaining = [q for q in all_questions if q.id not in answered_ids]
        if remaining:
            return {
                "next_question": serialize_question(random.choice(remaining), shuffle_options=True)
            }

        # mypy sees Column[datetime] on the LHS in 1.x-style declarations;
        # runtime assigns the value as expected. Migrating to Mapped[]
        # in app/db/models/* would lift this ignore.
        current_session.completed_at = utcnow()  # type: ignore[assignment]
        return {"next_question": "No more questions available"}

    async def finish_test(self, test_id: str, user_id: str) -> dict:
        user_take_res = await self.db.execute(
            select(UserTakes).where(
                UserTakes.test_id == test_id,
                UserTakes.user_id == user_id,
                UserTakes.completed_at.is_(None),
            )
        )
        user_take = user_take_res.scalars().first()
        if not user_take:
            raise NotFoundError("No active session found for the user and test")

        user_take.completed_at = utcnow()  # type: ignore[assignment]
        return {"status": "Ok"}
