import json

from fastapi import APIRouter, Body, Depends, File, Form, Header, HTTPException, UploadFile, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, get_current_admin, get_current_user
from app.core.settings import settings
from app.db.session import get_db

from .schema import CreateTextParseJobRequest, ParseJobResponse, SpeechCallbackRequest
from .service import ParseJobService


class CreateGlobalTextRequest(BaseModel):
    text: str = Field(..., min_length=1)

router = APIRouter(prefix="/parse-jobs", tags=["parse-jobs"])


@router.post("/text", response_model=ParseJobResponse, status_code=status.HTTP_202_ACCEPTED)
async def create_text_parse_job(
    body: CreateTextParseJobRequest,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await ParseJobService(db).create_text_job(body, user.id)


@router.post("/media", response_model=ParseJobResponse, status_code=status.HTTP_202_ACCEPTED)
async def create_media_parse_job(
    title: str = Form(...),
    description: str | None = Form(None),
    is_public: bool = Form(True),
    allowed_emails: str = Form("[]"),
    augment_data: bool = Form(False),
    create_tests: bool = Form(True),
    file: UploadFile = File(...),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    try:
        parsed_allowed = json.loads(allowed_emails)
        if not isinstance(parsed_allowed, list):
            parsed_allowed = []
    except json.JSONDecodeError:
        parsed_allowed = []

    return await ParseJobService(db).create_media_job(
        title=title,
        description=description,
        is_public=is_public,
        allowed_emails=[str(item) for item in parsed_allowed],
        augment_data=augment_data,
        create_tests=create_tests,
        user_id=user.id,
        filename=file.filename or "upload",
        content_type=file.content_type,
        file=file.file,
    )


@router.post(
    "/admin/global/text",
    response_model=ParseJobResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def create_global_text_parse_job(
    body: CreateGlobalTextRequest = Body(...),
    admin: AuthUser = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    return await ParseJobService(db).create_global_text_job(body.text, admin.id)


@router.post(
    "/admin/global/media",
    response_model=ParseJobResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def create_global_media_parse_job(
    file: UploadFile = File(...),
    admin: AuthUser = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    return await ParseJobService(db).create_global_media_job(
        user_id=admin.id,
        filename=file.filename or "upload",
        content_type=file.content_type,
        file=file.file,
    )


@router.get("", response_model=list[ParseJobResponse], include_in_schema=False)
@router.get("/", response_model=list[ParseJobResponse])
async def list_parse_jobs(
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await ParseJobService(db).list_jobs(str(user.id))


@router.get("/{job_id}", response_model=ParseJobResponse)
async def get_parse_job(
    job_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await ParseJobService(db).get_job(job_id, str(user.id))


@router.post("/internal/speech-callback", response_model=ParseJobResponse)
async def speech_callback(
    body: SpeechCallbackRequest,
    x_internal_token: str | None = Header(default=None),
    db: AsyncSession = Depends(get_db),
):
    if x_internal_token != settings.INTERNAL_CALLBACK_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid internal callback token")
    return await ParseJobService(db).apply_speech_callback(body)
