from __future__ import annotations

import logging
from typing import Any, BinaryIO

import httpx
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.tests._common import normalize_emails
from app.core.exceptions import DomainError, NotFoundError
from app.core.settings import settings
from app.db.models import UserTests
from app.db.models.parse_job import ParseJob, ParseJobEvent
from app.db.models.test import Test

from .schema import CreateTextParseJobRequest, ParseJobResponse, SpeechCallbackRequest

logger = logging.getLogger(__name__)

TERMINAL_STATUSES = {"completed", "failed", "canceled"}


def serialize_job(job: ParseJob) -> ParseJobResponse:
    return ParseJobResponse(
        job_id=job.id,
        source_type=job.source_type,
        status=job.status,
        stage=job.stage,
        total_chunks=job.total_chunks,
        completed_chunks=job.completed_chunks,
        failed_chunks=job.failed_chunks,
        message=job.message,
        error_message=job.error_message,
        test_id=job.test_id,
        augment_data=job.augment_data,
        create_tests=job.create_tests,
        created_at=job.created_at,
        updated_at=job.updated_at,
    )


class ParseJobService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_text_job(
        self, body: CreateTextParseJobRequest, user_id: Any
    ) -> ParseJobResponse:
        test = Test(
            title=body.title,
            description=body.description or "",
            is_public=body.is_public,
            allowed_emails=normalize_emails(body.allowed_emails),
        )
        self.db.add(test)
        await self.db.flush()

        self.db.add(UserTests(owner_id=user_id, test_id=test.id))
        job = ParseJob(
            user_id=str(user_id),
            test_id=test.id,
            source_type="text",
            status="queued",
            stage="segmenting_text",
            source_text=body.text,
            augment_data=body.augment_data,
            create_tests=body.create_tests,
            message="Text queued for parsing",
        )
        self.db.add(job)
        await self.db.flush()
        self._add_event(job, "Text queued for parsing")
        return serialize_job(job)

    async def create_media_job(
        self,
        *,
        title: str,
        description: str | None,
        is_public: bool,
        allowed_emails: list[str],
        augment_data: bool,
        create_tests: bool,
        user_id: Any,
        filename: str,
        content_type: str | None,
        file: BinaryIO,
    ) -> ParseJobResponse:
        test = Test(
            title=title,
            description=description or "",
            is_public=is_public,
            allowed_emails=normalize_emails(allowed_emails),
        )
        self.db.add(test)
        await self.db.flush()

        self.db.add(UserTests(owner_id=user_id, test_id=test.id))
        job = ParseJob(
            user_id=str(user_id),
            test_id=test.id,
            source_type="media",
            status="uploading",
            stage="media_received",
            augment_data=augment_data,
            create_tests=create_tests,
            message="Media upload accepted",
        )
        self.db.add(job)
        await self.db.flush()
        self._add_event(job, "Media upload accepted")
        await self.db.commit()

        callback_url = f"{settings.CORE_CALLBACK_URL.rstrip('/')}/parse-jobs/internal/speech-callback"
        files = {"video": (filename, file, content_type or "application/octet-stream")}
        data = {
            "job_id": job.id,
            "callback_url": callback_url,
            "callback_token": settings.INTERNAL_CALLBACK_TOKEN,
        }
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{settings.SPEECH_API_URL.rstrip('/')}/v1/transcriptions/jobs",
                    data=data,
                    files=files,
                )
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            await self.mark_failed(job, f"Speech service returned {e.response.status_code}")
            await self.db.commit()
            raise DomainError("Speech service rejected the upload") from e
        except httpx.RequestError as e:
            await self.mark_failed(job, "Could not reach speech service")
            await self.db.commit()
            raise DomainError("Could not reach speech service") from e

        job.status = "processing"
        job.stage = "media_received"
        job.message = "Media queued for transcription"
        self._add_event(job, job.message)
        return serialize_job(job)

    async def create_global_text_job(self, text: str, user_id: Any) -> ParseJobResponse:
        """Admin-only text ingest into the shared 'global' Qdrant pool.

        No Test/UserTests row is created — the job leaves test_id NULL
        and the worker rewrites that to the 'global' sentinel when it
        forwards to content-segmenter.
        """
        job = ParseJob(
            user_id=str(user_id),
            test_id=None,
            source_type="text",
            status="queued",
            stage="segmenting_text",
            source_text=text,
            augment_data=True,
            create_tests=False,
            message="Text queued for global parsing",
        )
        self.db.add(job)
        await self.db.flush()
        self._add_event(job, "Text queued for global parsing")
        return serialize_job(job)

    async def create_global_media_job(
        self,
        *,
        user_id: Any,
        filename: str,
        content_type: str | None,
        file: BinaryIO,
    ) -> ParseJobResponse:
        """Admin-only media ingest into the global pool. Pushes the file
        to speech-service which transcribes asynchronously and calls
        back into /parse-jobs/internal/speech-callback by job_id; the
        worker then forwards the transcript with test_id='global'."""
        job = ParseJob(
            user_id=str(user_id),
            test_id=None,
            source_type="media",
            status="uploading",
            stage="media_received",
            augment_data=True,
            create_tests=False,
            message="Media upload accepted (global)",
        )
        self.db.add(job)
        await self.db.flush()
        self._add_event(job, "Media upload accepted (global)")
        await self.db.commit()

        callback_url = f"{settings.CORE_CALLBACK_URL.rstrip('/')}/parse-jobs/internal/speech-callback"
        files = {"video": (filename, file, content_type or "application/octet-stream")}
        data = {
            "job_id": job.id,
            "callback_url": callback_url,
            "callback_token": settings.INTERNAL_CALLBACK_TOKEN,
        }
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{settings.SPEECH_API_URL.rstrip('/')}/v1/transcriptions/jobs",
                    data=data,
                    files=files,
                )
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            await self.mark_failed(job, f"Speech service returned {e.response.status_code}")
            await self.db.commit()
            raise DomainError("Speech service rejected the upload") from e
        except httpx.RequestError as e:
            await self.mark_failed(job, "Could not reach speech service")
            await self.db.commit()
            raise DomainError("Could not reach speech service") from e

        job.status = "processing"
        job.stage = "media_received"
        job.message = "Media queued for transcription"
        self._add_event(job, job.message)
        return serialize_job(job)

    async def list_jobs(self, user_id: str) -> list[ParseJobResponse]:
        res = await self.db.execute(
            select(ParseJob)
            .where(ParseJob.user_id == str(user_id))
            .order_by(desc(ParseJob.updated_at))
            .limit(50)
        )
        return [serialize_job(job) for job in res.scalars().all()]

    async def get_job(self, job_id: str, user_id: str) -> ParseJobResponse:
        job = await self._get_owned_job(job_id, user_id)
        return serialize_job(job)

    async def apply_speech_callback(self, body: SpeechCallbackRequest) -> ParseJobResponse:
        res = await self.db.execute(select(ParseJob).where(ParseJob.id == body.job_id))
        job = res.scalars().first()
        if not job:
            raise NotFoundError("Parse job not found")

        if body.total_chunks is not None:
            job.total_chunks = body.total_chunks
        if body.completed_chunks is not None:
            job.completed_chunks = max(job.completed_chunks, body.completed_chunks)
        if body.failed_chunks is not None:
            job.failed_chunks = max(job.failed_chunks, body.failed_chunks)
        if body.error_message:
            job.error_message = body.error_message

        if body.transcript is not None:
            job.source_text = body.transcript
            job.status = "queued"
            job.stage = "segmenting_text"
            job.message = body.message or "Transcript ready for parsing"
        else:
            job.status = body.status or job.status
            job.stage = body.stage
            job.message = body.message

        if job.status == "failed":
            job.error_message = body.error_message or job.error_message or body.message

        self._add_event(job, job.message)
        return serialize_job(job)

    async def mark_failed(self, job: ParseJob, error: str) -> None:
        job.status = "failed"
        job.error_message = error
        job.message = error
        self._add_event(job, error)

    async def _get_owned_job(self, job_id: str, user_id: str) -> ParseJob:
        res = await self.db.execute(
            select(ParseJob).where(ParseJob.id == job_id, ParseJob.user_id == str(user_id))
        )
        job = res.scalars().first()
        if not job:
            raise NotFoundError("Parse job not found")
        return job

    def _add_event(self, job: ParseJob, message: str | None) -> None:
        self.db.add(
            ParseJobEvent(
                job_id=job.id,
                status=job.status,
                stage=job.stage,
                message=message,
            )
        )
