from datetime import datetime

from pydantic import BaseModel, Field


class ParseJobResponse(BaseModel):
    job_id: str
    source_type: str
    status: str
    stage: str
    total_chunks: int = 0
    completed_chunks: int = 0
    failed_chunks: int = 0
    message: str | None = None
    error_message: str | None = None
    test_id: str | None = None
    augment_data: bool = False
    create_tests: bool = True
    created_at: datetime
    updated_at: datetime


class CreateTextParseJobRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: str | None = Field(None, max_length=1000)
    text: str = Field(..., min_length=1)
    is_public: bool = True
    allowed_emails: list[str] = Field(default_factory=list)
    augment_data: bool = True
    create_tests: bool = True
    window: int = Field(5, gt=0)
    model: str = "poolside/laguna-xs.2:free"


class SpeechCallbackRequest(BaseModel):
    job_id: str
    status: str | None = None
    stage: str
    message: str | None = None
    error_message: str | None = None
    total_chunks: int | None = None
    completed_chunks: int | None = None
    failed_chunks: int | None = None
    transcript: str | None = None

