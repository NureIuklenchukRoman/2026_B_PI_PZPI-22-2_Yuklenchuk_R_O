import re

from pydantic import BaseModel, EmailStr, Field, field_validator


class CreateUser(BaseModel):
    email: EmailStr = Field(
        ...,
        max_length=255,
        description="Valid email address used for login",
        examples=["user@example.com"],
    )

    password: str = Field(
        ...,
        min_length=8,
        max_length=100,
        description="Password used for login",
        examples=["password"],
    )

    @field_validator("password")
    def validate_strong_password(cls, v):
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain at least one lowercase letter")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit")
        if not re.search(r"[-_@#!?]", v):
            raise ValueError("Password must contain at least one special character")
        return v


class Token(BaseModel):
    access_token: str
    token_type: str
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    """Body for POST /auth/change-password. Knowing the current password is
    required so a stolen access cookie alone is not enough to rotate
    the credential out from under the legitimate owner."""

    current_password: str = Field(..., min_length=1, max_length=100)
    new_password: str = Field(..., min_length=8, max_length=100)

    @field_validator("new_password")
    def validate_strong_password(cls, v):
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain at least one lowercase letter")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit")
        if not re.search(r"[-_@#!?]", v):
            raise ValueError("Password must contain at least one special character")
        return v
