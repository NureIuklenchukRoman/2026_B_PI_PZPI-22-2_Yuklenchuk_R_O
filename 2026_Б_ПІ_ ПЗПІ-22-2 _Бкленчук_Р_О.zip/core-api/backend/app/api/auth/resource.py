from fastapi import APIRouter, Cookie, Depends, Response
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, get_current_user
from app.db.session import get_db

from .schema import ChangePasswordRequest, CreateUser, Token
from .service import change_user_password, login_user, refresh_user_token, register_user

auth_router = APIRouter(prefix="/auth", tags=["auth"])


@auth_router.post("/register")
async def register(response: Response, user: CreateUser, db: AsyncSession = Depends(get_db)):
    new_user = await register_user(user, response, db)
    return new_user


@auth_router.post("/login", response_model=Token)
async def login(
    response: Response,
    db: AsyncSession = Depends(get_db),
    form_data: OAuth2PasswordRequestForm = Depends(),
):
    user_token = await login_user(form_data, response, db)
    return user_token


@auth_router.post("/refresh")
async def refresh(
    response: Response, db: AsyncSession = Depends(get_db), refresh_token: str = Cookie(None)
):
    new_tokens = await refresh_user_token(response, refresh_token, db)
    return new_tokens


@auth_router.post("/change-password")
async def change_password(
    body: ChangePasswordRequest,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await change_user_password(user.id, body, db)


@auth_router.get("/logout")
async def logout(response: Response):
    response.delete_cookie("access_token")
    response.delete_cookie("refresh_token")
    return {"msg": "Logged out successfully"}
