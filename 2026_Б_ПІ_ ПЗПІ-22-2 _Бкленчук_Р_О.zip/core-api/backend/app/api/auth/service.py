import uuid

from fastapi import HTTPException, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, authenticate_by_password, get_user_for_refresh
from app.core.exceptions import DomainError
from app.core.security import (
    COOKIE_OPTIONS,
    create_access_token,
    create_refresh_token,
    hash_password,
    verify_password,
)
from app.core.settings import settings
from app.db.models.user import User
from app.utils.queries.fetching import fetch_one_or_none

from .schema import ChangePasswordRequest, CreateUser


def _token_payload(user: AuthUser) -> dict:
    return {
        "id": user.id,
        "email": user.email,
        "username": user.username,
        "is_admin": user.is_admin,
    }


async def _create_tokens_and_set_cookies(user_data: dict, response: Response) -> dict:
    access_token = create_access_token(user_data)
    refresh_token = create_refresh_token(user_data)

    response.set_cookie(
        "access_token",
        access_token,
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        **COOKIE_OPTIONS,
    )
    response.set_cookie(
        "refresh_token",
        refresh_token,
        max_age=settings.REFRESH_TOKEN_EXPIRE_MINUTES * 60,
        **COOKIE_OPTIONS,
    )

    return {"access_token": access_token, "refresh_token": refresh_token, "token_type": "bearer"}


async def register_user(user: CreateUser, response: Response, db: AsyncSession):
    query = select(User).where(User.email == user.email)
    existing_user = await fetch_one_or_none(db, query)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists",
        )

    hashed_password = hash_password(user.password)
    new_user = User(
        email=user.email,
        username=uuid.uuid4().hex,
        password=hashed_password,
    )
    db.add(new_user)
    # Explicit commit: token issuance below must be gated on durable
    # persistence — we don't want to set an access cookie for a user
    # that may not exist if the request-end commit later fails.
    await db.commit()

    auth_user = AuthUser.from_orm_user(new_user)
    return await _create_tokens_and_set_cookies(_token_payload(auth_user), response)


async def login_user(form_data: OAuth2PasswordRequestForm, response: Response, db: AsyncSession):
    user = await authenticate_by_password(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return await _create_tokens_and_set_cookies(_token_payload(user), response)


async def change_user_password(
    user_id: str, body: ChangePasswordRequest, db: AsyncSession
) -> dict:
    """Verify the caller's current password and rotate it to the new one.

    Raises DomainError on wrong current password or a no-op rotation so the
    handler returns a 400 rather than a generic 500.
    """
    db_user = await fetch_one_or_none(db, select(User).where(User.id == user_id))
    if db_user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
        )
    if not verify_password(body.current_password, db_user.password):
        raise DomainError("Current password is incorrect")
    if verify_password(body.new_password, db_user.password):
        raise DomainError("New password must be different from the current one")
    db_user.password = hash_password(body.new_password)
    return {"message": "Password updated successfully"}


async def refresh_user_token(response: Response, refresh_token: str, db: AsyncSession):
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )

    user = await get_user_for_refresh(refresh_token, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )

    return await _create_tokens_and_set_cookies(_token_payload(user), response)
