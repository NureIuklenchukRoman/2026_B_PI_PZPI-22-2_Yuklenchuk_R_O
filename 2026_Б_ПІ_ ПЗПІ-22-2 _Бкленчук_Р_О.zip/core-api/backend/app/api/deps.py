"""Shared FastAPI dependencies.

Single source of truth for the "current user" resolution. Routes get a
typed AuthUser pydantic model (or None for optional auth) — they
never see a raw SQLAlchemy User row.
"""

from __future__ import annotations

import logging
from datetime import datetime

import jwt
from fastapi import Depends, HTTPException, Request, status
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import decode_token, verify_password
from app.db.models.user import User
from app.db.session import get_db
from app.utils.queries.fetching import fetch_one_or_none

logger = logging.getLogger(__name__)


class AuthUser(BaseModel):
    """Authenticated user identity exposed to route handlers and services.
    Always carries id as a str so callers don't need to think about UUID.
    """

    id: str
    email: EmailStr
    username: str
    is_admin: bool = False
    created_at: datetime | None = None

    @classmethod
    def from_orm_user(cls, user: User) -> AuthUser:
        return cls(
            id=str(user.id),
            email=str(user.email),
            username=str(user.username),
            is_admin=bool(user.is_admin),
            created_at=user.created_at,
        )


def _extract_token(request: Request) -> str | None:
    """Pull the bearer token out of the Authorization header or the
    access_token cookie, in that order."""
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return auth_header.split(" ", 1)[1]
    return request.cookies.get("access_token")


async def _user_from_token(token: str, db: AsyncSession) -> User | None:
    """Decode + DB-resolve. Returns None for any failure (bad token,
    expired, missing email, user gone). Raises only on programming errors."""
    try:
        payload = decode_token(token)
    except jwt.PyJWTError:
        return None
    user_email = payload.get("email")
    if user_email is None:
        return None
    return await fetch_one_or_none(db, select(User).where(User.email == user_email))


async def get_current_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> AuthUser:
    """Required-auth dependency: 401 if missing/invalid token."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )
    token = _extract_token(request)
    if not token:
        raise credentials_exception

    try:
        payload = decode_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired"
        ) from None
    except jwt.PyJWTError as e:
        raise credentials_exception from e

    user_email = payload.get("email")
    if user_email is None:
        raise credentials_exception

    user = await fetch_one_or_none(db, select(User).where(User.email == user_email))
    if user is None:
        raise credentials_exception
    return AuthUser.from_orm_user(user)


async def get_optional_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> AuthUser | None:
    """Optional-auth dependency: returns None for unauthenticated or
    invalid-token requests (does not raise)."""
    token = _extract_token(request)
    if not token:
        return None
    user = await _user_from_token(token, db)
    return AuthUser.from_orm_user(user) if user else None


async def authenticate_by_password(db: AsyncSession, email: str, password: str) -> AuthUser | None:
    """Verify email+password against the User table. Used by the login
    route. Returns None on bad credentials (route maps to 401)."""
    user = await fetch_one_or_none(db, select(User).where(User.email == email))
    if not user or not verify_password(password, user.password):
        return None
    return AuthUser.from_orm_user(user)


async def get_current_admin(
    user: AuthUser = Depends(get_current_user),
) -> AuthUser:
    """Required-admin dependency: 403 if the caller is not an admin."""
    if not user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required",
        )
    return user


async def get_user_for_refresh(token: str, db: AsyncSession) -> AuthUser | None:
    """Resolve a refresh token to an AuthUser. Returns None on any
    failure — the auth router decides whether to 401."""
    user = await _user_from_token(token, db)
    return AuthUser.from_orm_user(user) if user else None
