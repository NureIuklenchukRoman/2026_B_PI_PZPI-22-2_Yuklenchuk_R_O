from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.db.models import UserAnswers, UserTakes, UserTests
from app.db.models.test import Question as DbQuestion
from app.db.models.test import Test as DbTest
from app.utils.helpers import collect_tags_from_questions


class UserService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_user_takes(self, user_id) -> list[dict]:
        query = (
            select(UserTakes, DbTest)
            .join(DbTest, DbTest.id == UserTakes.test_id)
            .where(UserTakes.user_id == user_id, UserTakes.completed_at.isnot(None))
        )
        result = await self.db.execute(query)
        rows = result.all()
        res = []
        for take, test in rows:
            q_res = await self.db.execute(
                select(DbQuestion).where(DbQuestion.test_id == take.test_id)
            )
            test_questions = q_res.scalars().all()

            res.append(
                {
                    "id": take.id,
                    "test_id": take.test_id,
                    "completed_at": take.completed_at,
                    "title": test.title,
                    "description": test.description or "",
                    "questions_amount": len(test_questions),
                    "tags": collect_tags_from_questions(
                        [{"tags": q.tags or []} for q in test_questions]
                    ),
                    "res_count": await self.__get_test_result(take.id, take.test_id),
                }
            )
        return res

    async def get_user_take(self, take_id, user_id) -> dict | None:
        take_query = (
            select(UserTakes, DbTest)
            .join(DbTest, DbTest.id == UserTakes.test_id)
            .where(UserTakes.id == take_id, UserTakes.user_id == user_id)
        )
        take_result = await self.db.execute(take_query)
        take_row = take_result.one_or_none()

        if not take_row:
            return None

        take, test = take_row

        answers_query = select(UserAnswers).where(UserAnswers.user_take_id == take.id)
        answers_result = await self.db.execute(answers_query)
        user_answers = answers_result.scalars().all()

        q_res = await self.db.execute(
            select(DbQuestion)
            .where(DbQuestion.test_id == take.test_id)
            .options(selectinload(DbQuestion.options))
        )
        test_questions = q_res.scalars().all()

        test_question_answers = []
        for test_question in test_questions:
            matched = False
            for user_answer in user_answers:
                if user_answer.question_id == test_question.id:
                    test_question_answers.append(
                        {
                            "id": test_question.id,
                            "question": test_question.question,
                            "tags": test_question.tags or [],
                            "options": [
                                {"id": o.id, "text": o.text, "correct": o.correct}
                                for o in test_question.options
                            ],
                            "selected_answers": user_answer.answers_ids,
                        }
                    )
                    matched = True
                    break
            if not matched:
                test_question_answers.append(
                    {
                        "id": test_question.id,
                        "question": test_question.question,
                        "tags": test_question.tags or [],
                        "options": [
                            {"id": o.id, "text": o.text, "correct": o.correct}
                            for o in test_question.options
                        ],
                        "selected_answers": [],
                    }
                )

        return {
            "id": take.id,
            "test_id": take.test_id,
            "completed_at": take.completed_at,
            "title": test.title,
            "description": test.description or "",
            "questions_amount": len(test_questions),
            "tags": collect_tags_from_questions([{"tags": q.tags or []} for q in test_questions]),
            "res_count": await self.__get_test_result(take.id, take.test_id),
            "questions": test_question_answers,
        }

    async def get_user_tests(self, user_id) -> list[dict]:
        """Retrieve a list of tests available for the user."""
        user_tests_ids_query = select(UserTests.test_id).where(UserTests.owner_id == user_id)
        user_tests_ids_exec = await self.db.execute(user_tests_ids_query)
        user_tests_ids = user_tests_ids_exec.scalars().all()

        if not user_tests_ids:
            return []

        test_query = select(DbTest).where(
            DbTest.id.in_(user_tests_ids), DbTest.is_deleted.is_(False)
        )
        test_exec = await self.db.execute(test_query)
        tests = test_exec.scalars().all()

        res = []
        for test in tests:
            q_res = await self.db.execute(select(DbQuestion).where(DbQuestion.test_id == test.id))
            test_questions = q_res.scalars().all()

            res.append(
                {
                    "test_id": test.id,
                    "title": test.title,
                    "description": test.description or "",
                    "tags": collect_tags_from_questions(
                        [{"tags": q.tags or []} for q in test_questions]
                    ),
                    "question_amount": len(test_questions),
                }
            )
        return res

    async def __get_test_result(self, test_take_id, test_id) -> int:
        query = select(UserAnswers).where(
            UserAnswers.user_take_id == test_take_id,
        )
        answers_res = await self.db.execute(query)
        answers = answers_res.scalars().all()
        count = 0
        for answer in answers:
            q_res = await self.db.execute(
                select(DbQuestion)
                .where(DbQuestion.id == answer.question_id, DbQuestion.test_id == test_id)
                .options(selectinload(DbQuestion.options))
            )
            question = q_res.scalars().first()
            if not question:
                continue

            correct_opt = next((o for o in question.options if o.correct), None)
            if correct_opt and [correct_opt.id] == answer.answers_ids:
                count += 1
        return count
