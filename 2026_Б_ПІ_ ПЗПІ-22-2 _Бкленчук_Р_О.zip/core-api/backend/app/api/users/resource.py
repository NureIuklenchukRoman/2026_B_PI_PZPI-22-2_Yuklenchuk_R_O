from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, get_current_user
from app.core.exceptions import NotFoundError
from app.db.models.user import User
from app.db.session import get_db
from app.utils.queries.fetching import fetch_one_or_none

from .schema import UserResponseSchema, UserTakesResponseSchema, UserTestsResponse, UserUpdateSchema
from .service import UserService

user_router = APIRouter(
    prefix="/users",
    tags=["users"],
)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")


@user_router.get("/auth-token-schema")
async def get_oauth2_scheme_schema(token: str = Depends(oauth2_scheme)):
    """Returns the OAuth2PasswordBearer schema for documentation."""
    return oauth2_scheme


@user_router.get("/me", response_model=UserResponseSchema)
async def get_user(user: AuthUser = Depends(get_current_user)):
    return user


@user_router.put("/me", response_model=UserResponseSchema)
async def update_user(
    body: UserUpdateSchema,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Persist email/username changes for the authenticated user.
    Loads the SQLAlchemy row by id, mutates, then returns the AuthUser
    shape so the response_model stays consistent.
    """
    db_user = await fetch_one_or_none(db, select(User).where(User.id == user.id))
    if db_user is None:
        raise NotFoundError("User not found")
    db_user.email = body.email
    db_user.username = body.username
    return AuthUser.from_orm_user(db_user)


@user_router.get("/my-takes", response_model=list[UserTakesResponseSchema])
async def get_user_takes(
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user_service = UserService(db)
    return await user_service.get_user_takes(user.id)


@user_router.get("/my-takes/{take_id}")
async def get_user_take(
    take_id: str,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user_service = UserService(db)
    user_take_details = await user_service.get_user_take(take_id, user.id)
    if not user_take_details:
        raise HTTPException(status_code=404, detail="Take not found")
    return user_take_details


@user_router.get("/my-tests", response_model=list[UserTestsResponse])
async def get_user_tests(
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user_service = UserService(db)
    return await user_service.get_user_tests(user.id)
