import uuid
from datetime import datetime

from pydantic import BaseModel, Field


class UserResponseSchema(BaseModel):
    email: str = Field(..., description="Email address of the user")
    username: str = Field(..., description="Username of the user")
    is_admin: bool = Field(False, description="Whether the user has admin privileges")
    created_at: datetime | None = Field(
        None, description="When the account was created (UTC)"
    )


class UserUpdateSchema(BaseModel):
    """Body for PUT /users/me — admin status is intentionally not editable here."""

    email: str = Field(..., description="Email address of the user")
    username: str = Field(..., description="Username of the user")


class UserTakesResponseSchema(BaseModel):
    id: uuid.UUID = Field(..., description="Unique identifier for the user take")
    test_id: str = Field(..., description="Unique identifier for the test taken by the user")
    completed_at: datetime = Field(..., description="Timestamp when the test was completed")
    title: str = Field(..., description="Title of the test")
    description: str = Field(..., description="Description of the test")
    questions_amount: int = Field(..., description="Total number of questions in the test")
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )
    res_count: int = Field(..., description="Count of correct answers provided by the user")


class UserTakeDetailsResponseSchema(BaseModel):
    id: uuid.UUID = Field(..., description="Unique identifier for the user take")
    test_id: str = Field(..., description="Unique identifier for the test taken by the user")
    completed_at: datetime = Field(..., description="Timestamp when the test was completed")
    title: str = Field(..., description="Title of the test")
    description: str = Field(..., description="Description of the test")
    questions_amount: int = Field(..., description="Total number of questions in the test")
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )
    res_count: int = Field(..., description="Count of correct answers provided by the user")
    questions: list[dict] = Field(
        default_factory=list, description="List of questions with user's answers"
    )


class UserTestsResponse(BaseModel):
    test_id: str
    title: str
    description: str
    question_amount: int
    tags: list[str] = Field(
        default_factory=list, description="List of tags associated with the test"
    )
