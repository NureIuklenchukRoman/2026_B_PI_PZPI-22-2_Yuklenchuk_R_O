from datetime import datetime

from pydantic import BaseModel, Field


class AskKnowledgeRequest(BaseModel):
    message: str
    knowledge_id: str | None = None


class AskKnowledgeResponse(BaseModel):
    answer: str


class ConversationMessage(BaseModel):
    role: str
    content: str
    created_at: datetime | None = None


class ConversationResponse(BaseModel):
    knowledge_id: str
    messages: list[ConversationMessage] = Field(default_factory=list)


class ProcessKnowledgeRequest(BaseModel):
    test_id: str
    text: str
    augment_data: bool = True
    create_tests: bool = False
    window: int = Field(5, gt=0)
    model: str = "poolside/laguna-xs.2:free"
