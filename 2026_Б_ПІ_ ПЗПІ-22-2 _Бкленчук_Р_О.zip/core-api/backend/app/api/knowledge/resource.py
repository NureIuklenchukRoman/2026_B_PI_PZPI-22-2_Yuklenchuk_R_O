import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import AuthUser, get_current_user
from app.core.settings import settings
from app.db.session import get_db

from .conversation_service import GLOBAL_KNOWLEDGE_ID, ConversationService
from .schema import (
    AskKnowledgeRequest,
    AskKnowledgeResponse,
    ConversationMessage,
    ConversationResponse,
    ProcessKnowledgeRequest,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["knowledge"])


@router.get("/conversations", response_model=ConversationResponse)
async def get_conversation(
    knowledge_id: str | None = Query(default=None),
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Load the caller's saved chat history for a knowledge context."""
    kid = knowledge_id if knowledge_id else GLOBAL_KNOWLEDGE_ID
    messages = await ConversationService(db).get_messages(user.id, kid)
    return ConversationResponse(
        knowledge_id=kid,
        messages=[
            ConversationMessage(role=m.role, content=m.content, created_at=m.created_at)
            for m in messages
        ],
    )


@router.post("/ask-knowledge", response_model=AskKnowledgeResponse)
async def ask_knowledge(
    body: AskKnowledgeRequest,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    knowledge_id = body.knowledge_id if body.knowledge_id else GLOBAL_KNOWLEDGE_ID

    params = {
        "question": body.message,
        "knowledgeId": knowledge_id,
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                settings.KNOWLEDGE_RETRIEVE_URL, params=params, timeout=30.0
            )
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPStatusError as e:
        logger.error("Retrieve API returned error: %s", e.response.text)
        raise HTTPException(
            status_code=502, detail="Knowledge base service returned an error"
        ) from e
    except httpx.RequestError as e:
        logger.error("Failed to reach retrieve API: %s", e)
        raise HTTPException(status_code=502, detail="Could not reach knowledge base service") from e

    answer = data.get("answer") or data.get("response") or str(data)

    # Persist the exchange so the thread survives reloads. A storage failure
    # must not lose the answer the user just received, so it's best-effort.
    try:
        await ConversationService(db).record_exchange(user.id, knowledge_id, body.message, answer)
    except Exception:
        logger.exception("Failed to persist conversation turn")

    return AskKnowledgeResponse(answer=answer)


@router.post("/process")
async def process_knowledge(
    body: ProcessKnowledgeRequest,
    _user: AuthUser = Depends(get_current_user),
):
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                settings.TEXT_SEGMENTER_URL,
                json=body.model_dump(),
                timeout=120.0,
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        logger.error("Text segmenter returned error: %s", e.response.text)
        raise HTTPException(
            status_code=502, detail="Text segmenter service returned an error"
        ) from e
    except httpx.RequestError as e:
        logger.error("Failed to reach text segmenter: %s", e)
        raise HTTPException(status_code=502, detail="Could not reach text segmenter service") from e


