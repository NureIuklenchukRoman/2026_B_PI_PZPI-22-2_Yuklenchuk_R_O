"""Persistence for AI chat threads — one conversation per user per
knowledge context (`knowledge_id`)."""

from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.db.models.conversation import Conversation, Message

GLOBAL_KNOWLEDGE_ID = "-1"


def _as_uuid(value: str) -> uuid.UUID:
    return value if isinstance(value, uuid.UUID) else uuid.UUID(str(value))


class ConversationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    @staticmethod
    def _normalize(knowledge_id: str | None) -> str:
        kid = (knowledge_id or "").strip()
        return kid or GLOBAL_KNOWLEDGE_ID

    async def get_messages(self, user_id: str, knowledge_id: str | None) -> list[Message]:
        """Ordered history for the caller's thread in this context. Returns an
        empty list when the thread doesn't exist yet (no row is created)."""
        kid = self._normalize(knowledge_id)
        res = await self.db.execute(
            select(Conversation)
            .where(
                Conversation.user_id == _as_uuid(user_id),
                Conversation.knowledge_id == kid,
            )
            .options(selectinload(Conversation.messages))
        )
        convo = res.scalars().first()
        return list(convo.messages) if convo else []

    async def get_or_create(self, user_id: str, knowledge_id: str | None) -> Conversation:
        kid = self._normalize(knowledge_id)
        res = await self.db.execute(
            select(Conversation).where(
                Conversation.user_id == _as_uuid(user_id),
                Conversation.knowledge_id == kid,
            )
        )
        convo = res.scalars().first()
        if convo is None:
            convo = Conversation(user_id=_as_uuid(user_id), knowledge_id=kid)
            self.db.add(convo)
            await self.db.flush()
        return convo

    async def record_exchange(
        self, user_id: str, knowledge_id: str | None, question: str, answer: str
    ) -> None:
        """Append the user's question and the assistant's answer as two turns,
        committing them together so a chat is never left half-saved."""
        convo = await self.get_or_create(user_id, knowledge_id)
        self.db.add(Message(conversation_id=convo.id, role="user", content=question))
        self.db.add(Message(conversation_id=convo.id, role="assistant", content=answer))
        await self.db.commit()
