def collect_tags_from_questions(questions: list[dict]) -> list[str]:
    """Collect unique tags from a list of question dicts with 'tags' key."""
    tags = set()
    for question in questions:
        if "tags" in question:
            tags.update(question["tags"])
    return list(tags)
