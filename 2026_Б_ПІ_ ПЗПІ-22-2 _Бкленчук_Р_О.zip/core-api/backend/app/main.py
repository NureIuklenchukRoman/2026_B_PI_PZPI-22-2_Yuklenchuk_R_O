import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.auth.resource import auth_router
from app.api.knowledge.resource import router as knowledge_router
from app.api.parse_jobs.resource import router as parse_jobs_router
from app.api.tests.resource import router as test_router
from app.api.users.resource import user_router
from app.core.exceptions import DomainError
from app.core.settings import settings

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    logger.info("Testify backend started")
    yield


app = FastAPI(
    title="Testify",
    description="Testify is a test management system that helps you manage your tests and their results.",
    version="0.1.0",
    lifespan=lifespan,
)

# Add CORS middleware BEFORE including routers
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(DomainError)
async def _domain_error_handler(_request: Request, exc: DomainError) -> JSONResponse:
    """Map service-layer exceptions to HTTP responses (400/403/404/409)."""
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


app.include_router(auth_router)
app.include_router(test_router)
app.include_router(user_router)
app.include_router(knowledge_router)
app.include_router(parse_jobs_router)
