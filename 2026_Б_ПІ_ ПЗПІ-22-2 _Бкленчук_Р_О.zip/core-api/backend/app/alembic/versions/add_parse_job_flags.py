"""add augment_data and create_tests to parse_jobs

Revision ID: add_parse_job_flags
Revises: b2_parse_jobs
Create Date: 2026-05-10

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'add_parse_job_flags'
down_revision: Union[str, None] = 'b2_parse_jobs'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('parse_jobs', sa.Column('augment_data', sa.Boolean(), nullable=False, server_default='false'))
    op.add_column('parse_jobs', sa.Column('create_tests', sa.Boolean(), nullable=False, server_default='true'))


def downgrade() -> None:
    op.drop_column('parse_jobs', 'create_tests')
    op.drop_column('parse_jobs', 'augment_data')
