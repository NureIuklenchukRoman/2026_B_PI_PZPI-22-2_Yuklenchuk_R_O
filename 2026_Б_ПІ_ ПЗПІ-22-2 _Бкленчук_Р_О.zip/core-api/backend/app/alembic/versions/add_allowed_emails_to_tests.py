"""add_allowed_emails_to_tests

Revision ID: add_allowed_emails
Revises: f8c545c4ea01
Create Date: 2025-10-20 20:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'add_allowed_emails'
down_revision: Union[str, None] = 'f8c545c4ea01'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # Add allowed_emails column to tests table
    op.add_column('tests', sa.Column('allowed_emails', postgresql.ARRAY(sa.String()), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    # Remove allowed_emails column
    op.drop_column('tests', 'allowed_emails')
