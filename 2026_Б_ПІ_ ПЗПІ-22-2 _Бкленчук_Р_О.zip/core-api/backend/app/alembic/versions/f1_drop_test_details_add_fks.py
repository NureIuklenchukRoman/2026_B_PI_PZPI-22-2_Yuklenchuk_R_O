"""Drop test_details + add user_tests/user_takes FKs to tests.id

Revision ID: f1_drop_test_details
Revises: add_allowed_emails
Create Date: 2026-04-29

This migration consolidates several pieces that were intentionally
loose since the af_manual_tests_models migration introduced the new
`tests` table:

  1. Backfill: any test_details row whose test_id has no matching tests
     row gets a synthetic tests row created so its title/description
     don't disappear.
  2. Drop the test_details table — its content is now redundant with
     tests.title / tests.description.
  3. Clean up orphan user_tests / user_takes rows whose test_id
     doesn't match any tests.id (otherwise step 4 would fail).
  4. Add a foreign key from user_tests.test_id and user_takes.test_id
     to tests.id ON DELETE CASCADE so deletes finally cascade properly
     (audit C6) and the application no longer needs the legacy
     unscoped fallback path.

The downgrade re-creates test_details (empty — no data round-trip) and
removes the FKs so the schema can be rolled back, but the original
test_details rows are gone after the upgrade. That's the same trade
the application has been silently making for months: TestDetails was
just a stale duplicate of test metadata.
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "f1_drop_test_details"
down_revision: str | None = "add_allowed_emails"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()

    # 1. Backfill orphan test_details rows into tests.
    bind.execute(
        sa.text(
            """
            INSERT INTO tests (id, title, description, is_public, created_at)
            SELECT td.test_id,
                   COALESCE(td.title, 'Untitled'),
                   td.description,
                   TRUE,
                   COALESCE(td.created_at, now())
            FROM test_details td
            WHERE td.test_id IS NOT NULL
              AND NOT EXISTS (SELECT 1 FROM tests t WHERE t.id = td.test_id)
            """
        )
    )

    # 2. Drop test_details (and its indexes — Alembic's drop_table cascades indexes).
    op.drop_index("ix_test_details_id", table_name="test_details")
    op.drop_index("ix_test_details_test_id", table_name="test_details")
    op.drop_index("ix_test_details_title", table_name="test_details")
    op.drop_table("test_details")

    # 3. Orphan cleanup before adding FKs.
    bind.execute(
        sa.text(
            "DELETE FROM user_tests "
            "WHERE test_id IS NULL "
            "   OR NOT EXISTS (SELECT 1 FROM tests t WHERE t.id = user_tests.test_id)"
        )
    )
    bind.execute(
        sa.text(
            "DELETE FROM user_takes "
            "WHERE test_id IS NULL "
            "   OR NOT EXISTS (SELECT 1 FROM tests t WHERE t.id = user_takes.test_id)"
        )
    )

    # 4. Make test_id NOT NULL and add FK to tests.id with cascade delete.
    op.alter_column("user_tests", "test_id", existing_type=sa.String(), nullable=False)
    op.alter_column("user_takes", "test_id", existing_type=sa.String(), nullable=False)
    op.create_foreign_key(
        "fk_user_tests_test_id",
        "user_tests",
        "tests",
        ["test_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_foreign_key(
        "fk_user_takes_test_id",
        "user_takes",
        "tests",
        ["test_id"],
        ["id"],
        ondelete="CASCADE",
    )


def downgrade() -> None:
    op.drop_constraint("fk_user_takes_test_id", "user_takes", type_="foreignkey")
    op.drop_constraint("fk_user_tests_test_id", "user_tests", type_="foreignkey")
    op.alter_column("user_takes", "test_id", existing_type=sa.String(), nullable=True)
    op.alter_column("user_tests", "test_id", existing_type=sa.String(), nullable=True)

    op.create_table(
        "test_details",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("test_id", sa.String(), nullable=True),
        sa.Column("title", sa.String(length=100), nullable=True),
        sa.Column("description", sa.String(length=500), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_test_details_id", "test_details", ["id"], unique=True)
    op.create_index("ix_test_details_test_id", "test_details", ["test_id"], unique=False)
    op.create_index("ix_test_details_title", "test_details", ["title"], unique=False)
