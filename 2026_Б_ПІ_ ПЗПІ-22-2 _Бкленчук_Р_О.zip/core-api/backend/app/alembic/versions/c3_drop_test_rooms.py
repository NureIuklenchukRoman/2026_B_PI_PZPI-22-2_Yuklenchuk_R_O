"""drop unused test_rooms and room_user_association

The test-rooms collaboration tables were never wired to any API. Test
access is governed solely by tests.is_public + tests.allowed_emails, so the
tables are removed to keep the schema in line with the implementation.

Revision ID: c3_drop_test_rooms
Revises: c2_soft_delete_tests
Create Date: 2026-06-08 01:00:00.000000

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "c3_drop_test_rooms"
down_revision: Union[str, None] = "c2_soft_delete_tests"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Association first (it FKs into test_rooms), then the rooms table.
    op.drop_table("room_user_association")
    op.drop_index(op.f("ix_test_rooms_name"), table_name="test_rooms")
    op.drop_index(op.f("ix_test_rooms_id"), table_name="test_rooms")
    op.drop_table("test_rooms")


def downgrade() -> None:
    op.create_table(
        "test_rooms",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=True),
        sa.Column("description", sa.String(length=255), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_test_rooms_id"), "test_rooms", ["id"], unique=True)
    op.create_index(op.f("ix_test_rooms_name"), "test_rooms", ["name"], unique=True)
    op.create_table(
        "room_user_association",
        sa.Column("room_id", sa.Uuid(), nullable=False),
        sa.Column("user_id", sa.Uuid(), nullable=False),
        sa.ForeignKeyConstraint(["room_id"], ["test_rooms.id"]),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("room_id", "user_id"),
    )
