"""add is_deleted to tests (soft delete)

Revision ID: c2_soft_delete_tests
Revises: c1_add_conversations
Create Date: 2026-06-08 00:30:00.000000

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "c2_soft_delete_tests"
down_revision: Union[str, None] = "c1_add_conversations"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "tests",
        sa.Column("is_deleted", sa.Boolean(), nullable=False, server_default="false"),
    )


def downgrade() -> None:
    op.drop_column("tests", "is_deleted")
