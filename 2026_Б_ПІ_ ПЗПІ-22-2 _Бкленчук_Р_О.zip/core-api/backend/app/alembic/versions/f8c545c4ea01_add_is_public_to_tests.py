"""add_is_public_to_tests

Revision ID: f8c545c4ea01
Revises: af_manual_tests_models
Create Date: 2025-10-20 19:14:40.677608

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f8c545c4ea01'
down_revision: Union[str, None] = 'af_manual_tests_models'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # Add is_public column to tests table, defaulting to True for existing tests
    op.add_column('tests', sa.Column('is_public', sa.Boolean(), nullable=False, server_default='true'))


def downgrade() -> None:
    """Downgrade schema."""
    # Remove is_public column
    op.drop_column('tests', 'is_public')
