"""add parse jobs

Revision ID: b2_parse_jobs
Revises: f1_drop_test_details
Create Date: 2026-05-10 20:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "b2_parse_jobs"
down_revision: Union[str, None] = "f1_drop_test_details"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "parse_jobs",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("test_id", sa.String(), nullable=True),
        sa.Column("source_type", sa.String(length=20), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("stage", sa.String(length=50), nullable=False),
        sa.Column("total_chunks", sa.Integer(), nullable=False),
        sa.Column("completed_chunks", sa.Integer(), nullable=False),
        sa.Column("failed_chunks", sa.Integer(), nullable=False),
        sa.Column("message", sa.String(length=500), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("source_text", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["test_id"], ["tests.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_parse_jobs_id"), "parse_jobs", ["id"], unique=True)
    op.create_index(op.f("ix_parse_jobs_status"), "parse_jobs", ["status"], unique=False)
    op.create_index(op.f("ix_parse_jobs_test_id"), "parse_jobs", ["test_id"], unique=False)
    op.create_index(op.f("ix_parse_jobs_user_id"), "parse_jobs", ["user_id"], unique=False)
    op.create_index("ix_parse_jobs_status_updated", "parse_jobs", ["status", "updated_at"])
    op.create_index("ix_parse_jobs_user_updated", "parse_jobs", ["user_id", "updated_at"])

    op.create_table(
        "parse_job_events",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("job_id", sa.String(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("stage", sa.String(length=50), nullable=False),
        sa.Column("message", sa.String(length=500), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["job_id"], ["parse_jobs.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_parse_job_events_id"), "parse_job_events", ["id"], unique=True)
    op.create_index(op.f("ix_parse_job_events_job_id"), "parse_job_events", ["job_id"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_parse_job_events_job_id"), table_name="parse_job_events")
    op.drop_index(op.f("ix_parse_job_events_id"), table_name="parse_job_events")
    op.drop_table("parse_job_events")
    op.drop_index("ix_parse_jobs_user_updated", table_name="parse_jobs")
    op.drop_index("ix_parse_jobs_status_updated", table_name="parse_jobs")
    op.drop_index(op.f("ix_parse_jobs_user_id"), table_name="parse_jobs")
    op.drop_index(op.f("ix_parse_jobs_test_id"), table_name="parse_jobs")
    op.drop_index(op.f("ix_parse_jobs_status"), table_name="parse_jobs")
    op.drop_index(op.f("ix_parse_jobs_id"), table_name="parse_jobs")
    op.drop_table("parse_jobs")
