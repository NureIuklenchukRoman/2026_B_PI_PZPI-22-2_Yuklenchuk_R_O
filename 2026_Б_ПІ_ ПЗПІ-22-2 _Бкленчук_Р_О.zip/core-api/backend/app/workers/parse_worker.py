from __future__ import annotations

import asyncio
import logging

import httpx
from sqlalchemy import select

from app.core.settings import settings
from app.db.models.parse_job import ParseJob, ParseJobEvent
from app.db.session import async_session

logger = logging.getLogger(__name__)


class ParseWorker:
    async def run_forever(self) -> None:
        logger.info("parse worker started")
        while True:
            try:
                did_work = await self.process_one()
            except Exception:
                logger.exception("parse worker iteration failed")
                did_work = False
            if not did_work:
                await asyncio.sleep(settings.PARSE_WORKER_POLL_SECONDS)

    async def process_one(self) -> bool:
        async with async_session() as db:
            async with db.begin():
                stmt = (
                    select(ParseJob)
                    .where(ParseJob.status == "queued", ParseJob.source_text.is_not(None))
                    .order_by(ParseJob.updated_at)
                    .limit(1)
                )
                bind = db.get_bind()
                if bind and bind.dialect.name == "postgresql":
                    stmt = stmt.with_for_update(skip_locked=True)
                res = await db.execute(stmt)
                job = res.scalars().first()
                if not job:
                    return False
                job.status = "processing"
                job.stage = "segmenting_text"
                job.message = "Segmenting source text"
                db.add(ParseJobEvent(job_id=job.id, status=job.status, stage=job.stage, message=job.message))

            await self._process_job(job.id)
            return True

    async def _process_job(self, job_id: str) -> None:
        async with async_session() as db:
            res = await db.execute(select(ParseJob).where(ParseJob.id == job_id))
            job = res.scalars().first()
            if not job or not job.source_text:
                return

            if job.augment_data and job.create_tests:
                job.create_tests = False
                job.source_type = "knowledge_base"
                job.message = "Processing knowledge base"
                
                new_job = ParseJob(
                    user_id=job.user_id,
                    test_id=job.test_id,
                    source_type="test_gen",
                    status="queued",
                    stage="queued",
                    source_text=job.source_text,
                    augment_data=False,
                    create_tests=True,
                    message="Queued for test generation",
                )
                db.add(new_job)
                await db.commit()
            elif job.augment_data:
                job.source_type = "knowledge_base"
                job.message = "Processing knowledge base"
                await db.commit()
            elif job.create_tests:
                job.source_type = "test_gen"
                job.message = "Processing test generation"
                await db.commit()

            # A null test_id marks an admin global-knowledge job. The
            # segmenter requires a non-empty test_id string and uses it
            # as the Qdrant knowledgeId; the literal 'global' is the
            # sentinel for the shared pool that Admin-Mode chats
            # surface (knowledgeId=-1 retrieve drops the filter).
            segmenter_test_id = job.test_id or "global"
            payload = {
                "test_id": segmenter_test_id,
                "text": job.source_text,
                "augment_data": job.augment_data,
                "create_tests": job.create_tests,
                "window": 5,
                "model": "poolside/laguna-xs.2:free",
            }
            try:
                job.stage = "processing"
                db.add(
                    ParseJobEvent(
                        job_id=job.id,
                        status=job.status,
                        stage=job.stage,
                        message=job.message,
                    )
                )
                await db.commit()

                async with httpx.AsyncClient(timeout=20 * 60.0) as client:
                    response = await client.post(settings.TEXT_SEGMENTER_URL, json=payload)
                    response.raise_for_status()
                    data = response.json()

                job.status = "completed"
                job.stage = "completed"
                job.message = f"Completed with {data.get('chunks', 0)} chunks"
                db.add(
                    ParseJobEvent(
                        job_id=job.id,
                        status=job.status,
                        stage=job.stage,
                        message=job.message,
                    )
                )
                await db.commit()
            except httpx.HTTPStatusError as exc:
                await self._mark_failed(
                    db,
                    job_id,
                    f"Content segmenter returned {exc.response.status_code}: {exc.response.text}",
                )
            except Exception as exc:
                await self._mark_failed(db, job_id, str(exc))

    async def _mark_failed(self, db, job_id: str, error_message: str) -> None:
        await db.rollback()
        res = await db.execute(select(ParseJob).where(ParseJob.id == job_id))
        failed = res.scalars().first()
        if not failed:
            return
        failed.status = "failed"
        failed.error_message = error_message
        failed.message = "Parsing failed"
        db.add(
            ParseJobEvent(
                job_id=failed.id,
                status=failed.status,
                stage=failed.stage,
                message=failed.message,
            )
        )
        await db.commit()


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    await ParseWorker().run_forever()


if __name__ == "__main__":
    asyncio.run(main())
