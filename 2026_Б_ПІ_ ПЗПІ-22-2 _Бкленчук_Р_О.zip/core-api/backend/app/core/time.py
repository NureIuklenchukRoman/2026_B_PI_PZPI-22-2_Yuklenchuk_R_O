from datetime import UTC, datetime


def utcnow() -> datetime:
    """Current UTC time as a naive datetime, matching the DateTime
    (timezone-naive) column storage used across the schema. Replaces
    the deprecated `datetime.utcnow()` builtin in Python 3.12+.
    """
    return datetime.now(UTC).replace(tzinfo=None)
