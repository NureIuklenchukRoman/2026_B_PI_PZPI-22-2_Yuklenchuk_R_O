"""Domain exceptions raised by the service layer.

Resource handlers in api/* should rarely catch these — instead, the
exception handlers registered in main.py map each one to the right
HTTP status. Services raise; routes return.
"""

from __future__ import annotations


class DomainError(Exception):
    """Generic invalid-input / business-rule violation. Maps to HTTP 400."""

    status_code: int = 400

    def __init__(self, detail: str):
        super().__init__(detail)
        self.detail = detail


class NotFoundError(DomainError):
    """Resource not found. Maps to HTTP 404."""

    status_code = 404


class ForbiddenError(DomainError):
    """Authenticated user lacks permission for this action. Maps to HTTP 403."""

    status_code = 403


class ConflictError(DomainError):
    """Request conflicts with current state (e.g. duplicate). Maps to HTTP 409."""

    status_code = 409
