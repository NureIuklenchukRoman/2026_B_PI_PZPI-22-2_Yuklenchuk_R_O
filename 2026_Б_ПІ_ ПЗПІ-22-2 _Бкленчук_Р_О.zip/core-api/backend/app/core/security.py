"""Password hashing + JWT token helpers.

Pure-functional helpers — no FastAPI dependencies, no DB access.
The Authorization() / get_current_user() FastAPI deps live in
api/deps.py and call into this module.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

import bcrypt
import jwt

from app.core.settings import settings
from app.core.time import utcnow

# Cookie attributes used by the auth router when setting the access /
# refresh token cookies. httponly is always on; secure + samesite are
# settings-driven so HTTPS prod and HTTP localhost can both work.
COOKIE_OPTIONS: dict[str, Any] = {
    "httponly": True,
    "secure": settings.COOKIE_SECURE,
    "samesite": settings.COOKIE_SAMESITE,
    "path": "/",
}


def hash_password(password: str) -> str:
    """Bcrypt-hash a plaintext password. Returns the storable string."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Constant-time check of a plaintext password against a stored bcrypt hash."""
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))


def _encode_token(payload: dict, expire_minutes: int) -> str:
    to_encode = {
        "id": str(payload["id"]),
        "email": payload["email"],
        "username": payload["username"],
        "exp": utcnow() + timedelta(minutes=expire_minutes),
    }
    return jwt.encode(to_encode, settings.SECRET_JWT_KEY, algorithm=settings.JWT_ALGORITHM)


def create_access_token(payload: dict) -> str:
    return _encode_token(payload, settings.ACCESS_TOKEN_EXPIRE_MINUTES)


def create_refresh_token(payload: dict) -> str:
    return _encode_token(payload, settings.REFRESH_TOKEN_EXPIRE_MINUTES)


def decode_token(token: str) -> dict:
    """Decode and verify a JWT. Raises jwt.PyJWTError on invalid/expired."""
    return jwt.decode(token, key=settings.SECRET_JWT_KEY, algorithms=[settings.JWT_ALGORITHM])
