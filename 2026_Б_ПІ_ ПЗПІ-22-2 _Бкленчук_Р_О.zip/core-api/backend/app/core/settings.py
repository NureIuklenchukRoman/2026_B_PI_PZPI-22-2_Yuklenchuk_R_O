from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Application settings.
    """

    # Database settings
    POSTGRES_USER: str = "admin"
    POSTGRES_PASSWORD: str = "admin"
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: str = "5432"
    POSTGRES_DB: str = "testify"

    # JWT settings
    SECRET_JWT_KEY: str
    JWT_ALGORITHM: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    REFRESH_TOKEN_EXPIRE_MINUTES: int

    # CORS
    CORS_ORIGINS: list[str] = ["http://localhost:3000", "http://localhost:30001"]

    # External knowledge / RAG service
    KNOWLEDGE_RETRIEVE_URL: str = "http://knowledge-engine.testify-knowledge.svc.cluster.local:8080/api/v1/retrieve"
    TEXT_SEGMENTER_URL: str = "http://content-segmenter.testify-content.svc.cluster.local/process"
    SPEECH_API_URL: str = "http://speech-api.testify-speech.svc.cluster.local"
    CORE_CALLBACK_URL: str = "http://core-api.testify-core.svc.cluster.local:8080"
    INTERNAL_CALLBACK_TOKEN: str = "dev-callback-token"
    PARSE_WORKER_POLL_SECONDS: float = 2.0

    # Auth cookie flags. Defaults are production-safe (https only,
    # samesite=lax). For HTTP local dev set COOKIE_SECURE=false.
    COOKIE_SECURE: bool = True
    COOKIE_SAMESITE: str = "lax"  # "lax" | "strict" | "none"

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:"
            f"{self.POSTGRES_PASSWORD}@"
            f"{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/"
            f"{self.POSTGRES_DB}"
        )

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()  # type: ignore[call-arg]  # values come from .env / process env
