from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.core.settings import settings

engine = create_async_engine(
    settings.database_url,
    future=True,
    echo=False,
)

# expire_on_commit=False prevents attribute access from triggering a
# refetch after the request-end commit (we keep returning the same
# instance the route already serialized).
async_session = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Per-request transaction boundary. Commits once at the end of a
    successful request; rolls back on any exception. Service code must
    NOT call session.commit() — let this dependency own the boundary."""
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
