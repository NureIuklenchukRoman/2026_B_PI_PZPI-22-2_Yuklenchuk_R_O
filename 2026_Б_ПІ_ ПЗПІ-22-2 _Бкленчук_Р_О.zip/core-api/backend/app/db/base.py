from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.schema import MetaData

BASE_METADATA = MetaData()
Base = declarative_base(metadata=BASE_METADATA)
