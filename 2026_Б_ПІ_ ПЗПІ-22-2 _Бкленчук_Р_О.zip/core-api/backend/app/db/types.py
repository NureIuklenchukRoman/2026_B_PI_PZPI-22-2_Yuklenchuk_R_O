"""Portable column types.

The application's tags / allowed_emails / answers_ids columns store
lists of strings. Postgres provides a native ARRAY type for this;
SQLite (used in tests) does not. StringList is a TypeDecorator that
emits ARRAY(String()) on Postgres and falls back to JSON on every
other dialect — at the Python level both behave as `list[str] | None`.
"""

from __future__ import annotations

import json

from sqlalchemy import JSON, String
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.types import TypeDecorator, TypeEngine


class StringList(TypeDecorator[list[str]]):
    """list[str] column. ARRAY on Postgres, JSON elsewhere."""

    impl = JSON
    cache_ok = True

    def load_dialect_impl(self, dialect) -> TypeEngine:
        if dialect.name == "postgresql":
            return dialect.type_descriptor(ARRAY(String()))
        return dialect.type_descriptor(JSON())

    def process_bind_param(self, value, dialect):
        # Postgres path receives the list directly; JSON path encodes
        # via the dialect's json serializer (which handles the list
        # natively).
        return value

    def process_result_value(self, value, dialect):
        # SQLite returns JSON columns as a JSON-encoded string; decode.
        if dialect.name == "postgresql":
            return value
        if isinstance(value, str):
            return json.loads(value)
        return value
