"""Association tables for many-to-many relationships.

(Currently none — the test-rooms collaboration tables were removed; test
access is governed solely by tests.is_public + tests.allowed_emails.)
"""
