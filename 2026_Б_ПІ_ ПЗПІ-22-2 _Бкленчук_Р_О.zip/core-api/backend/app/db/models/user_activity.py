"""Tables tracking what users have done with tests:

- UserTests:   who owns which test (also serves as the per-test ACL).
- UserTakes:   a single test session (start -> answers -> finish).
- UserAnswers: per-question answers within a UserTakes session.

The test_id columns reference tests.id with ON DELETE CASCADE — see
the F1 alembic migration. Code that previously needed to manually
clean these up on test delete relies on the FK now.
"""

import uuid

from sqlalchemy import Column, DateTime, ForeignKey, String, Uuid

from ..base import Base
from ..types import StringList


class UserTests(Base):
    __tablename__ = "user_tests"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4, unique=True, index=True)
    owner_id = Column(Uuid, ForeignKey("users.id"))
    test_id = Column(
        String(), ForeignKey("tests.id", ondelete="CASCADE"), nullable=False, index=True
    )

    def __repr__(self):
        return f"<UserTests(owner_id={self.owner_id}, test_id={self.test_id})>"


class UserTakes(Base):
    __tablename__ = "user_takes"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4, unique=True, index=True)
    user_id = Column(Uuid, ForeignKey("users.id"), index=True)
    test_id = Column(
        String(), ForeignKey("tests.id", ondelete="CASCADE"), nullable=False, index=True
    )
    completed_at = Column(DateTime)

    def __repr__(self):
        return f"<UserTakes(user_id={self.user_id})>"


class UserAnswers(Base):
    __tablename__ = "user_answers"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4, unique=True, index=True)
    user_take_id = Column(Uuid, ForeignKey("user_takes.id"), index=True)
    question_id = Column(String(), index=True)
    answers_ids: Column[list[str] | None] = Column(StringList(), nullable=True)

    def __repr__(self):
        return f"<UserAnswers(user_take_id={self.user_take_id})>"
