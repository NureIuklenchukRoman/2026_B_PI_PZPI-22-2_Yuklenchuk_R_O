import uuid

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, String
from sqlalchemy.orm import relationship

from app.core.time import utcnow

from ..base import Base
from ..types import StringList


class Test(Base):
    __tablename__ = "tests"

    id = Column(
        String, primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True
    )
    title = Column(String(200), nullable=False, index=True)
    description = Column(String(1000), nullable=True)
    is_public = Column(Boolean, default=True, nullable=False)
    is_deleted = Column(Boolean, nullable=False, default=False, server_default="false")
    allowed_emails: Column[list[str] | None] = Column(StringList(), nullable=True)
    created_at = Column(DateTime, default=utcnow)

    questions = relationship("Question", back_populates="test", cascade="all, delete-orphan")

    __table_args__ = (Index("ix_tests_created_at", "created_at"),)


class Question(Base):
    __tablename__ = "questions"

    id = Column(
        String, primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True
    )
    test_id = Column(String, ForeignKey("tests.id", ondelete="CASCADE"), nullable=False, index=True)
    question = Column(String(1000), nullable=False)
    tags: Column[list[str] | None] = Column(StringList(), nullable=True)

    test = relationship("Test", back_populates="questions")
    options = relationship("Option", back_populates="question", cascade="all, delete-orphan")


class Option(Base):
    __tablename__ = "options"

    id = Column(
        String, primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True
    )
    question_id = Column(
        String, ForeignKey("questions.id", ondelete="CASCADE"), nullable=False, index=True
    )
    text = Column(String(500), nullable=False)
    correct = Column(Boolean, default=False, nullable=False)

    question = relationship("Question", back_populates="options")
