import uuid

from sqlalchemy import (
    Column,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    UniqueConstraint,
    Uuid,
)
from sqlalchemy.orm import relationship

from app.core.time import utcnow

from ..base import Base


class Conversation(Base):
    """One persisted AI chat thread, scoped per user per knowledge context.

    `knowledge_id` is the chat key the frontend already uses for /ask-knowledge
    ('-1' is the global/admin knowledge base; otherwise a test's id). A user has
    at most one conversation per knowledge_id — enforced by the unique
    constraint below.
    """

    __tablename__ = "conversations"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4, unique=True, index=True)
    user_id = Column(
        Uuid, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    knowledge_id = Column(String(64), nullable=False, default="-1")
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    messages = relationship(
        "Message",
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="Message.created_at",
    )

    __table_args__ = (
        UniqueConstraint("user_id", "knowledge_id", name="uq_conversation_user_knowledge"),
        Index("ix_conversations_user_knowledge", "user_id", "knowledge_id"),
    )


class Message(Base):
    """A single turn in a conversation. `role` is 'user' or 'assistant'."""

    __tablename__ = "conversation_messages"

    id = Column(Uuid, primary_key=True, default=uuid.uuid4, unique=True, index=True)
    conversation_id = Column(
        Uuid, ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role = Column(String(16), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=utcnow)

    conversation = relationship("Conversation", back_populates="messages")
