import uuid

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Index, Integer, String, Text

from app.core.time import utcnow

from ..base import Base


class ParseJob(Base):
    __tablename__ = "parse_jobs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True)
    user_id = Column(String, nullable=False, index=True)
    test_id = Column(String, ForeignKey("tests.id", ondelete="CASCADE"), nullable=True, index=True)
    source_type = Column(String(20), nullable=False)
    status = Column(String(20), nullable=False, default="queued", index=True)
    stage = Column(String(50), nullable=False, default="queued")
    total_chunks = Column(Integer, nullable=False, default=0)
    completed_chunks = Column(Integer, nullable=False, default=0)
    failed_chunks = Column(Integer, nullable=False, default=0)
    message = Column(String(500), nullable=True)
    error_message = Column(Text, nullable=True)
    source_text = Column(Text, nullable=True)
    augment_data = Column(Boolean, nullable=False, default=False)
    create_tests = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    __table_args__ = (
        Index("ix_parse_jobs_user_updated", "user_id", "updated_at"),
        Index("ix_parse_jobs_status_updated", "status", "updated_at"),
    )


class ParseJobEvent(Base):
    __tablename__ = "parse_job_events"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, index=True)
    job_id = Column(String, ForeignKey("parse_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    status = Column(String(20), nullable=False)
    stage = Column(String(50), nullable=False)
    message = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=utcnow, nullable=False)

