# Core API: Testify Product API

Core API is the primary product API for Testify. It owns authentication, users, tests, questions, options, test sessions, user takes, and ownership metadata.

## Role in Testify

`interface-web` calls this service for product workflows: login, current user lookup, test discovery, test taking, manual test editing, and knowledge-processing requests. Core API stores relational product data in Postgres and calls `content-segmenter` when uploaded content needs to become structured text chunks.

Kubernetes role:

```text
namespace: testify-core
workloads: core-api, core-postgres, core-pgadmin
service: core-api
```

## Technology

- Python FastAPI application
- SQLAlchemy async ORM
- Alembic migrations
- Postgres with asyncpg
- JWT authentication with cookie-based session handling
- Docker image and Helm chart deployment

## Installation

```bash
cd core-api/backend
pip install -r requirements.txt
```

Runtime configuration is loaded from environment variables or `.env`. See `.env.example`.

## Usage

Run locally:

```bash
cd core-api/backend
uvicorn app.main:app --reload
```

Run tests:

```bash
cd core-api/backend
pytest
```

Build and deploy:

```bash
cd core-api
task push
task helm-install
```

## License

MIT License.
