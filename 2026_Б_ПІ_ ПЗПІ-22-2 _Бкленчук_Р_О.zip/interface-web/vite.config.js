import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In dev, leave VITE_API_BASE_URL unset and let the proxy below forward
// backend paths. The browser then sees a single origin
// (the Vite host), so SameSite=Lax cookies aren't treated as cross-site and
// CORS preflight is skipped entirely. Production builds inject absolute URLs.
const BACKEND_TARGET = process.env.BACKEND_TARGET ?? 'http://localhost:30001';

const backendPaths = [
  '/auth',
  '/users',
  '/tests',
  '/ask-knowledge',
  '/conversations',
  '/process',
  '/parse-jobs',
];

// In mock mode (VITE_MOCK=1) the browser intercepts fetch (src/mocks/devServer.ts),
// so the dev-server proxy is not only unnecessary but harmful: it would capture
// SPA routes like /tests/:id and forward them to a backend that isn't running.
// Skip it entirely so every client-side route resolves to index.html.
const proxy =
  process.env.VITE_MOCK === '1'
    ? undefined
    : Object.fromEntries([
        ...backendPaths.map((p) => [p, { target: BACKEND_TARGET, changeOrigin: true }]),
      ]);

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    host: true,
    proxy,
  },
  preview: {
    port: 3000,
    host: true,
  },
  css: {
    postcss: './postcss.config.js',
  },
});
