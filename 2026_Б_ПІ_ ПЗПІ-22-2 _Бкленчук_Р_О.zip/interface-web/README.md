# Interface Web: Testify Browser App

Interface Web is the browser application for Testify. It is the user-facing surface for authentication, browsing tests, taking tests, editing owned tests, uploading content, and using knowledge chat.

## Role in Testify

The app talks to `core-api` for product data and routes media or speech-to-text actions to `speech-service`. In Kubernetes it is the public entry point for the platform and proxies internal service calls through the deployment configuration.

Kubernetes role:

```text
namespace: testify-interface
workload: interface-web
service: interface-web
```

## Technology

- React
- TypeScript
- Vite
- React Router
- Tailwind CSS
- Vitest and Testing Library
- Docker image and Helm chart deployment

## Installation

```bash
cd interface-web
npm install
```

## Usage

Run locally:

```bash
npm run dev
```

Run checks:

```bash
npm run lint
npm run typecheck
npm run test
```

Build and deploy:

```bash
task deploy
```

## License

Not specified.
