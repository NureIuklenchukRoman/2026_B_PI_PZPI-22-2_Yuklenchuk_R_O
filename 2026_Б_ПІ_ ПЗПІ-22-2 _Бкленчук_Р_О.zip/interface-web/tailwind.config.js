import colors from 'tailwindcss/colors';

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // "Clean light" palette — soft-gray page, white panels, hairline
        // borders, one refined blue accent. Status colors (emerald/red/amber/
        // sky) live outside the brand and are reserved for PASS/FAIL/RUN.
        base: '#f7f8fa', // page background
        surface: '#ffffff', // panels, cards, sidebar
        raised: '#f1f3f6', // hover / inset / raised rows
        line: '#e6e8ec', // hairline borders
        'line-strong': '#d4d8de',
        accent: {
          DEFAULT: '#2563eb',
          hover: '#1d4ed8',
          muted: '#dbeafe',
        },
        brand: colors.blue,
      },
      fontFamily: {
        sans: [
          'DM Sans',
          'ui-sans-serif',
          'system-ui',
          '-apple-system',
          'Segoe UI',
          'Helvetica',
          'Arial',
          'sans-serif',
        ],
        // Headings use the same geometric sans (set via `font-display`).
        display: ['DM Sans', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
    },
  },
  plugins: [],
};
