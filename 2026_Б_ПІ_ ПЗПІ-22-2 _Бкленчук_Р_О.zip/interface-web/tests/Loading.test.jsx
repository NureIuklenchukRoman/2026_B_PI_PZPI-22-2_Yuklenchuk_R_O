import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import Loading from '../src/components/Loading';

describe('<Loading>', () => {
  it('renders the default message', () => {
    render(<Loading />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
    expect(screen.getByText('Please wait')).toBeInTheDocument();
  });

  it('renders custom message and submessage', () => {
    render(<Loading message="Fetching tests" submessage="Almost there" />);
    expect(screen.getByText('Fetching tests')).toBeInTheDocument();
    expect(screen.getByText('Almost there')).toBeInTheDocument();
  });
});
