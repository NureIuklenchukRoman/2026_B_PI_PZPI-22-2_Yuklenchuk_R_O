import { describe, it, expect } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import useTestFiltering from '../src/hooks/useTestFiltering';

const items = [
  {
    test_id: 'a',
    title: 'Alpha',
    description: 'first test',
    tags: ['x'],
    question_amount: 5,
    created_at: '2025-01-01T00:00:00Z',
  },
  {
    test_id: 'b',
    title: 'Bravo',
    description: 'second test',
    tags: ['x', 'y'],
    question_amount: 10,
    created_at: '2025-06-15T00:00:00Z',
  },
  {
    test_id: 'c',
    title: 'Charlie',
    description: 'third',
    tags: ['y'],
    question_amount: 2,
    created_at: '2025-03-10T00:00:00Z',
  },
];

describe('useTestFiltering', () => {
  it('sorts by title by default', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['a', 'b', 'c']);
  });

  it('sorts newest first by created_at', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    act(() => result.current.setSortBy('newest'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['b', 'c', 'a']);
  });

  it('sorts oldest first by created_at', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    act(() => result.current.setSortBy('oldest'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['a', 'c', 'b']);
  });

  it('sorts by question count', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    act(() => result.current.setSortBy('questions'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['b', 'a', 'c']);
  });

  it('falls back to completed_at when created_at is absent (takes)', () => {
    const takes = [
      { id: 't1', title: 'one', completed_at: '2025-02-01T00:00:00Z' },
      { id: 't2', title: 'two', completed_at: '2025-04-01T00:00:00Z' },
    ];
    const { result } = renderHook(() => useTestFiltering(takes, { defaultSort: 'newest' }));
    expect(result.current.filteredItems.map((i) => i.id)).toEqual(['t2', 't1']);
  });

  it('filters by search term against title and description', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    act(() => result.current.setSearchTerm('second'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['b']);
  });

  it('filters by tags (all selected tags must match)', () => {
    const { result } = renderHook(() => useTestFiltering(items));
    act(() => result.current.toggleTag('y'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['b', 'c']);
    act(() => result.current.toggleTag('x'));
    expect(result.current.filteredItems.map((i) => i.test_id)).toEqual(['b']);
  });
});
