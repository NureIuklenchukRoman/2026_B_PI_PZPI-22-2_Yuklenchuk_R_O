import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Dev-only: when started with `VITE_MOCK=1 npm run dev`, stand up an in-browser
// mock backend so every page renders without the Kubernetes stack. No-op in a
// normal build.
if (import.meta.env.VITE_MOCK === '1') {
  const { installMockServer } = await import('./mocks/devServer');
  installMockServer();
}

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('No #root element found in index.html');
ReactDOM.createRoot(rootElement).render(<App />);
