/**
 * Compatibility shim — preserves the old `testService.someMethod()` shape
 * for the .jsx pages while they still exist. Each .jsx page migrates to
 * importing from `lib/api/*` directly in D12, after which this file is
 * deleted.
 */

import * as auth from '../lib/api/auth';
import * as knowledge from '../lib/api/knowledge';
import * as tests from '../lib/api/tests';
import * as users from '../lib/api/users';

export const testService = {
  // Auth
  login: auth.login,
  register: auth.register,
  logout: auth.logout,

  // Tests catalog
  getTests: tests.listTests,
  getTestTags: tests.listTestTags,
  getTestInfo: tests.getTestInfo,
  getTestInfoForEdit: tests.getTestForEdit,
  getTestQuestionsAmount: tests.getTestQuestionsAmount,
  startTest: tests.startTest,
  endTest: tests.endTest,
  submitAnswer: tests.submitAnswer,
  editTest: tests.editTest,
  editTestQuestion: tests.editTestQuestion,
  addTestQuestion: tests.addTestQuestion,
  deleteTest: tests.deleteTest,
  deleteTestQuestion: tests.deleteTestQuestion,
  createTestManually: tests.createTestManually,

  // User-scoped views
  getUserTests: users.getMyTests,
  getUserTakes: users.getMyTakes,
  getUserTakeDetails: users.getMyTakeDetails,
  getMe: users.getMe,
  updateMe: users.updateMe,

  // External knowledge / upload service
  askKnowledge: knowledge.askKnowledge,
  getConversation: knowledge.getConversation,
  processTestKnowledgeBase: knowledge.processTestKnowledgeBase,
};
