// In dev, leave this unset; the Vite proxy routes known backend paths so
// requests stay same-origin and cookies stick. Production builds can set an
// absolute URL via VITE_API_BASE_URL.
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '';

