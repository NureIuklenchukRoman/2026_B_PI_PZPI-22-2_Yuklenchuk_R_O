/** The old design layered animated indigo/purple/pink blur blobs behind every
 * page — the hallmark of the gradient look we've retired. The "Calm academic"
 * system uses a flat slate-50 page instead, so this renders nothing.
 *
 * Kept as a no-op (rather than deleted) so PageLayout and the pages that import
 * it don't need to change their structure. */
export default function BackgroundElements() {
  return null;
}
