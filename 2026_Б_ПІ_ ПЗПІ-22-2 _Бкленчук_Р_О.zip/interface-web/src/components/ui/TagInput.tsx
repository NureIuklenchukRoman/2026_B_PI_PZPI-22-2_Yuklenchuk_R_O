/** Generic add-and-display chip list. The user types a value, presses
 * Enter (or clicks the inline Add button), and the value joins the
 * `value` array. Each chip has a remove button.
 *
 * Used directly for tag lists, and composed with stricter validation
 * by EmailListInput.
 */

import { useState } from 'react';
import { Hash, X } from 'lucide-react';
import type { ComponentType, KeyboardEvent } from 'react';

export interface TagInputProps {
  value: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  /** Called on each commit attempt. Return null to reject. */
  normalize?: (raw: string) => string | null;
  /** Type of the underlying <input>. Default 'text'. */
  inputType?: 'text' | 'email';
  /** Optional icon shown inside each chip. */
  chipIcon?: ComponentType<{ className?: string }>;
  /** Tailwind classes for the chip — useful for indigo vs purple variants. */
  chipClassName?: string;
  /** Show an explicit Add button next to the input. */
  showAddButton?: boolean;
  ariaLabel?: string;
}

const DEFAULT_CHIP_CLASS =
  'inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs bg-raised text-slate-700 border border-line';

export default function TagInput({
  value,
  onChange,
  placeholder = 'Add and press Enter',
  normalize,
  inputType = 'text',
  chipIcon: ChipIcon,
  chipClassName = DEFAULT_CHIP_CLASS,
  showAddButton = false,
  ariaLabel,
}: TagInputProps) {
  const [draft, setDraft] = useState('');

  const commit = () => {
    const raw = draft.trim();
    if (!raw) return;
    const normalized = normalize ? normalize(raw) : raw;
    if (!normalized) return;
    if (value.includes(normalized)) {
      setDraft('');
      return;
    }
    onChange([...value, normalized]);
    setDraft('');
  };

  const remove = (item: string) => onChange(value.filter((v) => v !== item));

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      commit();
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-2">
        <input
          type={inputType}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          aria-label={ariaLabel}
          className="input flex-1 px-3 py-2.5"
        />
        {showAddButton && (
          <button type="button" onClick={commit} className="btn-primary px-5 py-2.5">
            Add
          </button>
        )}
      </div>
      {value.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {value.map((item) => (
            <span key={item} className={chipClassName}>
              {ChipIcon && <ChipIcon className="w-3 h-3" />}
              {item}
              <button
                type="button"
                onClick={() => remove(item)}
                aria-label={`Remove ${item}`}
                className="text-current opacity-70 hover:opacity-100"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

/** Tag chip variant with the # icon, used by test/question tag fields. */
export function HashTagInput(props: Omit<TagInputProps, 'chipIcon'>) {
  return <TagInput chipIcon={Hash} {...props} />;
}
