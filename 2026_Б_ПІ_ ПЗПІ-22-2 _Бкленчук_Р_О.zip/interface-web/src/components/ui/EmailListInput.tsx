/** Email-validated wrapper around TagInput. Used for the
 * "allowed emails" field in private-test forms.
 */

import TagInput from './TagInput';

const EMAIL_RE = /[^\s@]+@[^\s@]+\.[^\s@]+/;

const normalizeEmail = (raw: string): string | null => {
  const lowered = raw.trim().toLowerCase();
  return EMAIL_RE.test(lowered) ? lowered : null;
};

interface EmailListInputProps {
  value: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  showAddButton?: boolean;
}

export default function EmailListInput({
  value,
  onChange,
  placeholder = 'name@example.com',
  showAddButton = true,
}: EmailListInputProps) {
  return (
    <TagInput
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      inputType="email"
      normalize={normalizeEmail}
      showAddButton={showAddButton}
      ariaLabel="Allowed email"
    />
  );
}
