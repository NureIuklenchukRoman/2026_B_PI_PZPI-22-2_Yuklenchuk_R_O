/** Accessible modal primitive.
 *
 * Handles:
 *   - role="dialog" + aria-modal + aria-labelledby
 *   - Esc key closes
 *   - basic focus trap: focus moves into the dialog on open;
 *     Tab/Shift-Tab cycle between focusable descendants.
 *   - background scroll lock while open
 *   - clicking the backdrop closes
 *
 * It does not impose a visual style beyond the centered overlay; the
 * caller renders any header / body / footer they want inside.
 */

import { useCallback, useEffect, useId, useRef } from 'react';
import type { KeyboardEvent, MouseEvent, ReactNode } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  /** Used as the dialog's accessible name. Required. */
  title: string;
  children: ReactNode;
  /** Wider variant for forms; defaults to max-w-md. */
  size?: 'sm' | 'md' | 'lg';
  /** When true, clicking the backdrop won't close. Useful while a
   *  destructive action is in flight. */
  blockBackdropClose?: boolean;
}

const SIZE_CLASSES: Record<NonNullable<ModalProps['size']>, string> = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-2xl',
};

const FOCUSABLE_SELECTOR =
  'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';

export default function Modal({
  isOpen,
  onClose,
  title,
  children,
  size = 'md',
  blockBackdropClose = false,
}: ModalProps) {
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const titleId = useId();

  const focusFirst = useCallback(() => {
    const node = dialogRef.current;
    if (!node) return;
    const focusable = node.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
    (focusable[0] ?? node).focus();
  }, []);

  // Mount/unmount side effects — Esc, scroll lock, autofocus.
  useEffect(() => {
    if (!isOpen) return;

    const previouslyFocused = document.activeElement as HTMLElement | null;
    document.body.style.overflow = 'hidden';
    focusFirst();

    const onKey = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      previouslyFocused?.focus?.();
    };
  }, [isOpen, focusFirst, onClose]);

  if (!isOpen) return null;

  const handleBackdropClick = (e: MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget && !blockBackdropClose) onClose();
  };

  /** Focus trap: cycle Tab between focusable descendants. */
  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== 'Tab') return;
    const node = dialogRef.current;
    if (!node) return;
    const focusable = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
      (el) => !el.hasAttribute('disabled')
    );
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    const active = document.activeElement;
    if (e.shiftKey && active === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && active === last) {
      e.preventDefault();
      first.focus();
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4"
      onMouseDown={handleBackdropClick}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
        className={`bg-surface rounded shadow-2xl w-full ${SIZE_CLASSES[size]} mx-auto border border-line outline-none`}
      >
        {/* Hidden a11y label; callers can render their own visual heading. */}
        <span id={titleId} className="sr-only">
          {title}
        </span>
        {children}
      </div>
    </div>
  );
}
