/** Status badge — subtle tinted background + a mono label.
 *
 * Tones map to the reserved status palette (see index.css):
 *   pass → emerald · fail → red · run → sky (pulses) · warn → amber ·
 *   idle → slate · accent → brand amber.
 *
 * Examples:
 *   <Badge tone="pass">PASS</Badge>
 *   <Badge tone="run">RUNNING</Badge>
 *   <Badge tone="idle">PRIVATE</Badge>
 */

import type { ReactNode } from 'react';

export type BadgeTone = 'pass' | 'fail' | 'run' | 'warn' | 'idle' | 'accent';

const TONE_CLASS: Record<BadgeTone, string> = {
  pass: 'badge-pass',
  fail: 'badge-fail',
  run: 'badge-run',
  warn: 'badge-warn',
  idle: 'badge-idle',
  accent: 'badge-accent',
};

const DOT_CLASS: Record<BadgeTone, string> = {
  pass: 'bg-emerald-400',
  fail: 'bg-red-400',
  run: 'bg-sky-400',
  warn: 'bg-amber-400',
  idle: 'bg-slate-400',
  accent: 'bg-accent',
};

interface BadgeProps {
  tone: BadgeTone;
  /** Label text — convenient with the `scoreBadge`/`jobStatusBadge` helpers
   *  (which return `{ tone, label }`). Use `children` for richer content. */
  label?: string;
  children?: ReactNode;
  /** Show a leading status dot; pulses for the `run` tone. */
  dot?: boolean;
  className?: string;
}

export default function Badge({ tone, label, children, dot = false, className = '' }: BadgeProps) {
  return (
    <span className={`badge ${TONE_CLASS[tone]} ${className}`}>
      {dot && (
        <span
          className={`w-1.5 h-1.5 rounded-full ${DOT_CLASS[tone]} ${tone === 'run' ? 'animate-pulse' : ''}`}
        />
      )}
      {children ?? label}
    </span>
  );
}

/** Maps a parse-job status to a badge tone + label. */
export function jobStatusBadge(status: string): { tone: BadgeTone; label: string } {
  switch (status) {
    case 'completed':
      return { tone: 'pass', label: 'Completed' };
    case 'failed':
      return { tone: 'fail', label: 'Failed' };
    case 'canceled':
      return { tone: 'idle', label: 'Canceled' };
    case 'processing':
      return { tone: 'run', label: 'Running' };
    case 'uploading':
      return { tone: 'run', label: 'Uploading' };
    case 'queued':
      return { tone: 'warn', label: 'Queued' };
    default:
      return { tone: 'idle', label: status.charAt(0).toUpperCase() + status.slice(1) };
  }
}

/** Maps a score percentage to a PASS/FAIL badge (60% threshold). */
export function scoreBadge(pct: number): { tone: BadgeTone; label: string } {
  return pct >= 60 ? { tone: 'pass', label: 'Passed' } : { tone: 'fail', label: 'Failed' };
}
