import { useState } from 'react';
import type { ComponentType } from 'react';
import {
  BookOpen,
  User,
  LogOut,
  ArrowLeft,
  FileText,
  Award,
  Loader2,
  Settings,
  Shield,
  MessageCircle,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth/AuthContext';

interface MenuItem {
  label: string;
  icon: ComponentType<{ className?: string }>;
  onClick: () => void;
}

interface NavbarProps {
  title: string;
  icon?: ComponentType<{ className?: string }>;
  showBackButton?: boolean;
  backButtonPath?: string;
  menuItems?: MenuItem[];
}

function Navbar({
  title,
  icon: Icon,
  showBackButton = false,
  backButtonPath = '/home',
  menuItems = [],
}: NavbarProps) {
  const { user: userData, status, logout: authLogout } = useAuth();
  const loading = status === 'loading';

  const [showMenu, setShowMenu] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await authLogout();
    navigate('/');
  };

  const defaultMenuItems = [
    {
      label: 'Home',
      icon: BookOpen,
      onClick: () => navigate('/home'),
    },
    {
      label: 'My Takes',
      icon: Award,
      onClick: () => navigate('/my-takes'),
    },
    {
      label: 'My Tests',
      icon: FileText,
      onClick: () => navigate('/my-tests'),
    },
    {
      label: 'Profile Settings',
      icon: Settings,
      onClick: () => navigate('/profile'),
    },
    {
      label: 'Log Out',
      icon: LogOut,
      onClick: handleLogout,
    },
  ];

  const finalMenuItems = menuItems.length > 0 ? menuItems : defaultMenuItems;

  // Show loading state while fetching user data
  if (loading) {
    return (
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              {showBackButton && (
                <button
                  onClick={() => navigate(backButtonPath)}
                  className="btn-secondary w-9 h-9 p-0"
                >
                  <ArrowLeft className="w-5 h-5 text-slate-500" />
                </button>
              )}
              {Icon && (
                <div className="w-9 h-9 bg-accent rounded-lg flex items-center justify-center">
                  <Icon className="w-5 h-5 text-white" />
                </div>
              )}
              <h1 className="text-xl font-semibold text-slate-900">{title}</h1>
            </div>

            <div className="flex items-center gap-2 text-slate-500 text-sm">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Loading…</span>
            </div>
          </div>
        </div>
      </header>
    );
  }

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            {showBackButton && (
              <button onClick={() => navigate(backButtonPath)} className="btn-secondary w-9 h-9 p-0">
                <ArrowLeft className="w-5 h-5 text-slate-500" />
              </button>
            )}
            {Icon && (
              <div className="w-9 h-9 bg-accent rounded-lg flex items-center justify-center">
                <Icon className="w-5 h-5 text-white" />
              </div>
            )}
            <h1 className="text-xl font-semibold text-slate-900">{title}</h1>
            <button
              onClick={() => navigate('/chat')}
              className="btn-ghost w-9 h-9 p-0 text-slate-500 hover:text-accent"
              title="AI Chat"
            >
              <MessageCircle className="w-5 h-5" />
            </button>
          </div>

          {userData && (
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="flex items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-slate-100 transition-colors"
              >
                <div className="text-right hidden sm:block">
                  <div className="text-slate-800 text-sm font-medium flex items-center justify-end gap-2">
                    {userData.username}
                    {userData.is_admin && (
                      <span
                        title="Administrator"
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-100 text-amber-700"
                      >
                        <Shield className="w-3 h-3" />
                        Admin
                      </span>
                    )}
                  </div>
                  <div className="text-slate-500 text-xs">{userData.email}</div>
                </div>
                <div className="w-9 h-9 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4" />
                </div>
              </button>

              {showMenu && (
                <div className="absolute right-0 mt-2 w-52 rounded-lg shadow-lg bg-white border border-slate-200 overflow-hidden z-50">
                  {finalMenuItems.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        item.onClick();
                        setShowMenu(false);
                      }}
                      className="flex items-center gap-2.5 w-full text-left px-4 py-2.5 text-sm text-slate-500 hover:bg-slate-50 hover:text-slate-900 transition-colors border-b border-slate-100 last:border-b-0 focus:outline-none focus:bg-slate-50"
                    >
                      <item.icon className="w-4 h-4 text-slate-500" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default Navbar;
