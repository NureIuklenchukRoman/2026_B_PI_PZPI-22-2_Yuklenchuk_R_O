function Loading({ message = 'Loading...', submessage = 'Please wait' }) {
  return (
    <div className="min-h-screen bg-base flex items-center justify-center">
      <div className="text-center">
        <div className="w-9 h-9 mx-auto mb-5 rounded-full border-2 border-line border-t-accent animate-spin"></div>
        <p className="text-sm font-medium text-slate-800">{message}</p>
        <p className="text-xs text-slate-500 mt-1">{submessage}</p>
      </div>
    </div>
  );
}

export default Loading;
