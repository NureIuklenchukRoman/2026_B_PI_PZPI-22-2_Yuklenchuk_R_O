import type { ReactNode } from 'react';
import { Play, Clock } from 'lucide-react';
import type { TestSummary } from '../lib/types';

interface TestCardProps {
  test: TestSummary;
  index?: number;
  onClick: () => void;
  actions?: ReactNode;
}

export default function TestCard({ test, index = 0, onClick, actions }: TestCardProps) {
  return (
    <div
      className="group card-interactive p-6 cursor-pointer hover:border-accent/40"
      onClick={onClick}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="w-11 h-11 bg-accent/10 text-accent rounded-lg flex items-center justify-center group-hover:bg-accent/15 transition-colors">
          <Play className="w-5 h-5" />
        </div>
        <div className="flex items-center gap-1 text-slate-500">
          <Clock className="w-3.5 h-3.5" />
          <span className="text-xs">{test.question_amount}q</span>
        </div>
      </div>

      <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-accent transition-colors">
        {test.title}
      </h3>

      <p className="text-sm text-slate-500 mb-4 line-clamp-2 leading-relaxed">
        {test.description || 'No description available'}
      </p>

      <div className="flex flex-wrap gap-1.5 mb-4">
        {test.tags?.map((tag) => (
          <span key={tag} className="tag">
            {tag}
          </span>
        ))}
      </div>

      <div className="flex justify-between items-center pt-4 border-t border-slate-100">
        <div className="flex items-center gap-1 text-sm">
          <span className="font-medium text-slate-700">{test.question_amount}</span>
          <span className="text-slate-500">questions</span>
        </div>
        {actions}
      </div>
    </div>
  );
}
