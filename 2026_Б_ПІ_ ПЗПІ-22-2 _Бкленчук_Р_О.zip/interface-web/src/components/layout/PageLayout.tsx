/** Standard page chrome: flat page background + navbar slot. Pages provide
 * their own <main> with whatever max-width they need; PageLayout doesn't
 * impose one.
 */

import type { ReactNode } from 'react';
import BackgroundElements from '../BackgroundElements';

interface PageLayoutProps {
  children: ReactNode;
  navbar?: ReactNode;
  /** Override the default page background. */
  gradientClass?: string;
}

const DEFAULT_GRADIENT = 'min-h-screen bg-slate-50';

export default function PageLayout({
  children,
  navbar,
  gradientClass = DEFAULT_GRADIENT,
}: PageLayoutProps) {
  return (
    <div className={gradientClass}>
      <BackgroundElements />
      {navbar}
      {children}
    </div>
  );
}
