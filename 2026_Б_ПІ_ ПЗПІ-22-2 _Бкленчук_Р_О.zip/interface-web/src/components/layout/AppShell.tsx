/** Application shell for the signed-in product surface.
 *
 * Persistent left sidebar — brand · grouped navigation sections · user card —
 * over a dark "refined utilitarian" surface, with a dense standardized page
 * header. Collapses behind a hamburger drawer on small screens.
 *
 * Browsing/management pages render inside this shell. Focused "task mode"
 * screens (login/register, taking a test, editing a test) deliberately do NOT
 * use it, so they get the full viewport without navigation chrome.
 */

import { useState } from 'react';
import type { ComponentType, ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  LayoutGrid,
  FileText,
  Award,
  Sparkles,
  Settings,
  LogOut,
  Shield,
  Menu,
  X,
  ChevronLeft,
  ChevronDown,
} from 'lucide-react';

import { useAuth } from '../../lib/auth/AuthContext';

interface NavItem {
  label: string;
  to: string;
  icon: ComponentType<{ className?: string }>;
  match?: string[];
}

interface NavSection {
  label: string;
  items: NavItem[];
}

const NAV_SECTIONS: NavSection[] = [
  {
    label: 'Menu',
    items: [
      { label: 'Browse tests', to: '/home', icon: LayoutGrid, match: ['/tests'] },
      { label: 'My tests', to: '/my-tests', icon: FileText },
      { label: 'My results', to: '/my-takes', icon: Award, match: ['/results'] },
      { label: 'Assistant', to: '/chat', icon: Sparkles },
    ],
  },
];

interface AppShellProps {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  backTo?: { to: string; label: string };
  maxWidth?: string;
  children: ReactNode;
}

function isActive(pathname: string, item: NavItem): boolean {
  if (pathname === item.to) return true;
  if (pathname.startsWith(item.to + '/')) return true;
  return (item.match ?? []).some((m) => pathname === m || pathname.startsWith(m + '/'));
}

export default function AppShell({
  title,
  subtitle,
  actions,
  backTo,
  maxWidth = 'max-w-6xl',
  children,
}: AppShellProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <div className="flex items-center gap-2.5 px-4 h-16 border-b border-line">
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-sm shadow-blue-500/30">
          <GraduationCap className="w-[18px] h-[18px] text-white" />
        </div>
        <span className="font-display text-base font-semibold text-slate-900 tracking-tight">
          Testify
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-6 overflow-y-auto">
        {NAV_SECTIONS.map((section) => (
          <div key={section.label}>
            <div className="space-y-1">
              {section.items.map((item) => {
                const active = isActive(pathname, item);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setDrawerOpen(false)}
                    className={`group relative flex items-center gap-2.5 rounded-md pl-3 pr-2 py-1.5 text-sm transition-colors ${
                      active
                        ? 'bg-accent/10 text-accent font-medium'
                        : 'text-slate-500 hover:bg-raised hover:text-slate-900'
                    }`}
                  >
                    {active && (
                      <span className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-accent" />
                    )}
                    <item.icon
                      className={`w-4 h-4 ${active ? 'text-accent' : 'text-slate-500 group-hover:text-slate-700'}`}
                    />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* User card */}
      {user && (
        <div className="relative border-t border-line p-2.5">
          {userMenuOpen && (
            <div className="absolute bottom-full left-2.5 right-2.5 mb-2 rounded-md border border-line bg-raised shadow-xl overflow-hidden">
              <Link
                to="/profile"
                onClick={() => {
                  setUserMenuOpen(false);
                  setDrawerOpen(false);
                }}
                className="flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-surface hover:text-slate-900"
              >
                <Settings className="w-4 h-4 text-slate-500" />
                Profile settings
              </Link>
              <button
                onClick={handleLogout}
                className="flex w-full items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-surface hover:text-slate-900 border-t border-line"
              >
                <LogOut className="w-4 h-4 text-slate-500" />
                Log out
              </button>
            </div>
          )}
          <button
            onClick={() => setUserMenuOpen((v) => !v)}
            className="flex w-full items-center gap-2.5 rounded-md p-1.5 hover:bg-raised transition-colors"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white flex items-center justify-center text-sm font-semibold shadow-sm shadow-blue-500/30">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="flex items-center gap-1.5">
                <span className="truncate text-sm font-medium text-slate-800">{user.username}</span>
                {user.is_admin && (
                  <span className="badge badge-accent" title="Administrator">
                    <Shield className="w-2.5 h-2.5" />
                    Admin
                  </span>
                )}
              </div>
              <div className="truncate text-xs text-slate-500">{user.email}</div>
            </div>
            <ChevronDown
              className={`w-4 h-4 text-slate-500 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`}
            />
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-base">
      {/* Desktop sidebar */}
      <aside className="hidden lg:fixed lg:inset-y-0 lg:left-0 lg:z-40 lg:flex lg:w-60 lg:flex-col border-r border-line bg-surface">
        {sidebar}
      </aside>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60" onClick={() => setDrawerOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-60 bg-surface border-r border-line shadow-xl">
            <button
              onClick={() => setDrawerOpen(false)}
              aria-label="Close menu"
              className="absolute right-3 top-3.5 text-slate-500 hover:text-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
            {sidebar}
          </div>
        </div>
      )}

      {/* Content */}
      <div className="lg:pl-60">
        {/* Mobile top bar */}
        <div className="lg:hidden sticky top-0 z-30 flex items-center gap-3 h-12 px-4 bg-surface border-b border-line">
          <button
            onClick={() => setDrawerOpen(true)}
            aria-label="Open menu"
            className="text-slate-500 hover:text-slate-900"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center shadow-sm shadow-blue-500/30">
              <GraduationCap className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-display text-sm font-semibold text-slate-900">Testify</span>
          </div>
        </div>

        <main className="px-4 sm:px-6 lg:px-10 py-8">
          <div className={`${maxWidth} mx-auto`}>
            {/* Page header */}
            <header className="mb-8">
              {backTo && (
                <Link
                  to={backTo.to}
                  className="inline-flex items-center gap-1 text-sm font-medium text-slate-500 hover:text-accent mb-3"
                >
                  <ChevronLeft className="w-4 h-4" />
                  {backTo.label}
                </Link>
              )}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h1 className="font-display text-[28px] leading-tight font-bold text-slate-900">
                    {title}
                  </h1>
                  {subtitle && <p className="mt-1.5 text-[15px] text-slate-500">{subtitle}</p>}
                </div>
                {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
              </div>
            </header>

            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
