import { Play, X, AlertCircle, Clock, MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import type { TestSummary } from '../lib/types';
import Modal from './ui/Modal';

interface TestConfirmModalProps {
  isOpen: boolean;
  test: TestSummary | null;
  onConfirm: () => void;
  onCancel: () => void;
}

function TestConfirmModal({ isOpen, test, onConfirm, onCancel }: TestConfirmModalProps) {
  const navigate = useNavigate();
  if (!test) return null;

  return (
    <Modal isOpen={isOpen} onClose={onCancel} title={`Start ${test.title}?`}>
      {/* Modal Header */}
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-line">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-accent/10 text-accent border border-accent/20 rounded-md flex items-center justify-center">
            <Play className="w-4 h-4" />
          </div>
          <h3 className="text-sm font-semibold text-slate-900">
            Start test
          </h3>
        </div>
        <button
          onClick={onCancel}
          aria-label="Close"
          className="text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Modal Content */}
      <div className="p-5">
        <div className="mb-4">
          <h4 className="text-lg font-semibold text-slate-900 mb-1.5">{test.title}</h4>
          <p className="text-slate-500 text-sm mb-3">
            {test.description || 'No description available'}
          </p>
          <div className="flex items-center gap-1.5 text-sm text-slate-500">
            <Clock className="w-4 h-4" />
            <span>{test.question_amount} questions</span>
          </div>
        </div>

        {test.tags && test.tags.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-1.5">
            {test.tags.map((tag) => (
              <span key={tag} className="tag">
                {tag}
              </span>
            ))}
          </div>
        )}

        <div className="flex gap-2.5 rounded-md bg-amber-50 border border-amber-100 p-3 mb-1">
          <AlertCircle className="w-4.5 h-4.5 text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-amber-700 text-sm">
            Once you start, the test timer begins. Make sure you have enough time to finish all
            questions.
          </p>
        </div>
      </div>

      {/* Modal Actions */}
      <div className="px-5 py-3.5 flex gap-2 border-t border-line">
        <button onClick={onCancel} className="btn-secondary flex-1 px-4 py-2 text-sm">
          Cancel
        </button>
        <button
          onClick={() => navigate(`/chat?knowledgeId=${test.test_id}`)}
          className="btn-secondary flex-1 px-4 py-2 text-sm"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Ask</span>
        </button>
        <button onClick={onConfirm} className="btn-primary flex-1 px-4 py-2 text-sm">
          Start test
        </button>
      </div>
    </Modal>
  );
}

export default TestConfirmModal;
