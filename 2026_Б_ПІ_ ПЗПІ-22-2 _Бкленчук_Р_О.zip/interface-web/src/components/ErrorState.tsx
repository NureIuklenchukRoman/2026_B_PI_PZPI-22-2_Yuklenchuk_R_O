import { AlertTriangle } from 'lucide-react';

interface ErrorStateProps {
  error: string;
}

/** Calm, informative error surface — a bordered panel, not an alarm. */
export default function ErrorState({ error }: ErrorStateProps) {
  return (
    <div className="min-h-screen bg-base flex items-center justify-center px-4">
      <div className="card p-6 max-w-md w-full">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-md bg-amber-50 border border-amber-100 flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-4.5 h-4.5 text-amber-600" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-slate-900 mb-1">Something went wrong</h3>
            <p className="text-sm text-slate-500 break-words">{error}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
