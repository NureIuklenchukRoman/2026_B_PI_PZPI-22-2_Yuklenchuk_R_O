import { useState } from 'react';
import { Search, Hash } from 'lucide-react';

interface SortOption {
  value: string;
  label: string;
}

interface FilterBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  sortBy: string;
  onSortChange: (value: string) => void;
  sortOptions?: SortOption[];
  availableTags?: string[];
  selectedTags?: string[];
  onToggleTag: (tag: string) => void;
  searchPlaceholder?: string;
}

const DEFAULT_SORT_OPTIONS: SortOption[] = [
  { value: 'title', label: 'Sort by Title' },
  { value: 'questions', label: 'Sort by Questions' },
  { value: 'newest', label: 'Sort by Newest' },
];

/** How many unselected tags to show before collapsing the rest. */
const TAG_LIMIT = 8;

export default function FilterBar({
  searchTerm,
  onSearchChange,
  sortBy,
  onSortChange,
  sortOptions = DEFAULT_SORT_OPTIONS,
  availableTags = [],
  selectedTags = [],
  onToggleTag,
  searchPlaceholder = 'Search tests, topics, descriptions...',
}: FilterBarProps) {
  const [tagQuery, setTagQuery] = useState('');
  const [showAll, setShowAll] = useState(false);

  // Selected tags always stay visible; the rest are searchable and capped.
  const unselected = availableTags.filter((t) => !selectedTags.includes(t));
  const matched = tagQuery
    ? unselected.filter((t) => t.toLowerCase().includes(tagQuery.toLowerCase()))
    : unselected;
  const visible = showAll ? matched : matched.slice(0, TAG_LIMIT);
  const hiddenCount = matched.length - visible.length;
  const canSearchTags = availableTags.length > TAG_LIMIT;

  const chipClass = (active: boolean) =>
    `px-2 py-0.5 rounded-md text-[11px] transition-colors border ${
      active
        ? 'bg-accent/15 text-accent border-accent/30'
        : 'bg-raised text-slate-500 border-line hover:text-slate-800 hover:border-line-strong'
    }`;

  return (
    <div className="mb-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-2">
        <div className="flex-1">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-slate-500 w-4 h-4" />
            <input
              type="text"
              placeholder={searchPlaceholder}
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="input pl-9 pr-3 py-2 text-sm"
            />
          </div>
        </div>
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value)}
          className="input py-2 px-2.5 pr-8 text-sm cursor-pointer sm:w-48"
        >
          {sortOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {availableTags.length > 0 && (
        <div className="mt-3 flex items-center flex-wrap gap-1.5">
          <Hash className="w-3.5 h-3.5 text-slate-500 mr-0.5 flex-shrink-0" />

          {canSearchTags && (
            <input
              type="text"
              value={tagQuery}
              onChange={(e) => {
                setTagQuery(e.target.value);
                setShowAll(false);
              }}
              placeholder="Filter tags…"
              aria-label="Filter tags"
              className="rounded-md border border-line bg-surface text-[11px] px-2 py-0.5 w-32 text-slate-700 placeholder-slate-400 focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent/20"
            />
          )}

          {/* Selected tags first, so a filtered query never hides the active ones. */}
          {selectedTags.map((tag) => (
            <button key={tag} onClick={() => onToggleTag(tag)} className={chipClass(true)}>
              {tag}
            </button>
          ))}

          {visible.map((tag) => (
            <button key={tag} onClick={() => onToggleTag(tag)} className={chipClass(false)}>
              {tag}
            </button>
          ))}

          {hiddenCount > 0 && (
            <button
              onClick={() => setShowAll(true)}
              className="px-2 py-0.5 text-[11px] text-accent hover:underline"
            >
              +{hiddenCount} more
            </button>
          )}
          {showAll && matched.length > TAG_LIMIT && (
            <button
              onClick={() => setShowAll(false)}
              className="px-2 py-0.5 text-[11px] text-slate-500 hover:underline"
            >
              Show less
            </button>
          )}
          {tagQuery && matched.length === 0 && (
            <span className="text-[11px] text-slate-400">No tags match “{tagQuery}”.</span>
          )}
        </div>
      )}
    </div>
  );
}
