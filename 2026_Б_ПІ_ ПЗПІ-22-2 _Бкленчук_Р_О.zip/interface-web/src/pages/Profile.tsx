import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import {
  Award,
  CheckCircle,
  FileText,
  KeyRound,
  Loader2,
  Lock,
  Mail,
  Save,
  Settings,
  Shield,
  Target,
  Trophy,
  UserCircle,
} from 'lucide-react';

import AppShell from '../components/layout/AppShell';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';
import * as authApi from '../lib/api/auth';
import * as usersApi from '../lib/api/users';
import { ApiError } from '../lib/api/client';
import { useAuth } from '../lib/auth/AuthContext';

type Banner = { kind: 'success' | 'error'; text: string } | null;

interface ActivityStats {
  testsCreated: number;
  takesCount: number;
  /** Number of correctly-answered questions across all completed takes,
   * divided by the total questions answered. null when there are no takes. */
  averageScore: number | null;
}

function formatMemberSince(iso?: string | null): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export default function Profile() {
  const { user, status, refresh } = useAuth();

  const [profileForm, setProfileForm] = useState({ username: '', email: '' });
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileBanner, setProfileBanner] = useState<Banner>(null);

  const [passwordForm, setPasswordForm] = useState({
    current: '',
    next: '',
    confirm: '',
  });
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordBanner, setPasswordBanner] = useState<Banner>(null);

  const [stats, setStats] = useState<ActivityStats | null>(null);
  const [statsError, setStatsError] = useState<string | null>(null);

  // Pull the form in sync with whatever the AuthContext just loaded.
  useEffect(() => {
    if (user) {
      setProfileForm({ username: user.username || '', email: user.email || '' });
    }
  }, [user]);

  // Activity counts come from existing per-user endpoints, computed
  // client-side: no new backend surface needed for the stats panel.
  useEffect(() => {
    let active = true;
    async function loadStats() {
      try {
        const [createdTests, takes] = await Promise.all([
          usersApi.getMyTests(),
          usersApi.getMyTakes(),
        ]);
        if (!active) return;
        const totalQuestions = takes.reduce((sum, t) => sum + (t.questions_amount ?? 0), 0);
        const correctAnswers = takes.reduce((sum, t) => sum + (t.res_count ?? 0), 0);
        const averageScore = totalQuestions > 0 ? correctAnswers / totalQuestions : null;
        setStats({
          testsCreated: createdTests.length,
          takesCount: takes.length,
          averageScore,
        });
      } catch (err) {
        if (!active) return;
        setStatsError(err instanceof Error ? err.message : 'Failed to load stats');
      }
    }
    void loadStats();
    return () => {
      active = false;
    };
  }, []);

  const memberSince = useMemo(() => formatMemberSince(user?.created_at), [user?.created_at]);
  const profileDirty =
    !!user &&
    (profileForm.username.trim() !== (user.username ?? '') ||
      profileForm.email.trim() !== (user.email ?? ''));

  const handleProfileSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!profileDirty || savingProfile) return;
    setSavingProfile(true);
    setProfileBanner(null);
    try {
      await usersApi.updateMe({
        username: profileForm.username.trim(),
        email: profileForm.email.trim(),
      });
      await refresh();
      setProfileBanner({ kind: 'success', text: 'Profile updated.' });
    } catch (err) {
      const detail = err instanceof ApiError ? err.message : 'Update failed';
      setProfileBanner({ kind: 'error', text: detail });
    } finally {
      setSavingProfile(false);
    }
  };

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (savingPassword) return;
    setPasswordBanner(null);
    if (passwordForm.next !== passwordForm.confirm) {
      setPasswordBanner({ kind: 'error', text: 'New password and confirmation do not match.' });
      return;
    }
    setSavingPassword(true);
    try {
      await authApi.changePassword(passwordForm.current, passwordForm.next);
      setPasswordForm({ current: '', next: '', confirm: '' });
      setPasswordBanner({ kind: 'success', text: 'Password updated.' });
    } catch (err) {
      const detail = err instanceof ApiError ? err.message : 'Password change failed';
      setPasswordBanner({ kind: 'error', text: detail });
    } finally {
      setSavingPassword(false);
    }
  };

  if (status === 'loading') {
    return <Loading message="Loading your profile..." submessage="Fetching account details" />;
  }
  if (!user) {
    return <ErrorState error="You must be signed in to view your profile." />;
  }

  const passwordsMatch = passwordForm.next.length > 0 && passwordForm.next === passwordForm.confirm;
  const passwordFormReady =
    passwordForm.current.length > 0 && passwordForm.next.length >= 8 && passwordsMatch;

  return (
    <AppShell title="Profile" subtitle="Manage your account and security" maxWidth="max-w-3xl">
      <div className="space-y-6">
        {/* Header card */}
        <section className="card p-8">
          <div className="flex items-start justify-between gap-6">
            <div className="flex items-center gap-5">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md shadow-blue-500/30 text-3xl font-semibold">
                {user.username.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h2 className="font-display text-3xl font-semibold text-slate-900">
                    {user.username}
                  </h2>
                  {user.is_admin && (
                    <span className="badge badge-accent">
                      <Shield className="w-2.5 h-2.5" />
                      Admin
                    </span>
                  )}
                </div>
                <p className="text-slate-500 flex items-center gap-2">
                  <Mail className="w-4 h-4" /> {user.email}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Member since <span className="tabular-nums">{memberSince}</span>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Activity stats */}
        <section className="card p-8">
          <h3 className="font-display text-xl font-semibold text-slate-900 mb-6 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-accent" />
            Activity
          </h3>
          {statsError ? (
            <p className="text-sm text-red-600">{statsError}</p>
          ) : !stats ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-[68px] bg-raised border border-line rounded animate-pulse"
                  aria-hidden="true"
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <StatCard
                icon={FileText}
                tint="blue"
                label="Tests created"
                value={stats.testsCreated.toString()}
              />
              <StatCard
                icon={Award}
                tint="emerald"
                label="Tests taken"
                value={stats.takesCount.toString()}
              />
              <StatCard
                icon={Target}
                tint="amber"
                label="Average score"
                value={
                  stats.averageScore == null ? '—' : `${Math.round(stats.averageScore * 100)}%`
                }
              />
            </div>
          )}
        </section>

        {/* Edit profile */}
        <section className="card p-8">
          <h3 className="font-display text-xl font-semibold text-slate-900 mb-6 flex items-center gap-2">
            <Settings className="w-5 h-5 text-accent" />
            Account details
          </h3>
          <form onSubmit={handleProfileSubmit} className="space-y-4 max-w-xl">
            <div>
              <label className="label">
                <UserCircle className="w-4 h-4 inline mr-2" />
                Username
              </label>
              <input
                type="text"
                value={profileForm.username}
                onChange={(e) => setProfileForm({ ...profileForm, username: e.target.value })}
                className="input px-4 py-2"
                required
              />
            </div>
            <div>
              <label className="label">
                <Mail className="w-4 h-4 inline mr-2" />
                Email
              </label>
              <input
                type="email"
                value={profileForm.email}
                onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                className="input px-4 py-2"
                required
              />
            </div>
            {profileBanner && <FormBanner banner={profileBanner} />}
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!profileDirty || savingProfile}
                className="btn-primary px-5 py-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {savingProfile ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Saving…</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </section>

        {/* Change password */}
        <section className="card p-8">
          <h3 className="font-display text-xl font-semibold text-slate-900 mb-6 flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-accent" />
            Change password
          </h3>
          <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-xl">
            <PasswordField
              label="Current password"
              value={passwordForm.current}
              onChange={(v) => setPasswordForm({ ...passwordForm, current: v })}
              autoComplete="current-password"
            />
            <PasswordField
              label="New password"
              value={passwordForm.next}
              onChange={(v) => setPasswordForm({ ...passwordForm, next: v })}
              autoComplete="new-password"
              help="At least 8 characters, with upper-case, lower-case, a digit, and one of -_@#!?"
            />
            <PasswordField
              label="Confirm new password"
              value={passwordForm.confirm}
              onChange={(v) => setPasswordForm({ ...passwordForm, confirm: v })}
              autoComplete="new-password"
              error={
                passwordForm.confirm.length > 0 && passwordForm.next !== passwordForm.confirm
                  ? 'Does not match the new password.'
                  : null
              }
            />
            {passwordBanner && <FormBanner banner={passwordBanner} />}
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!passwordFormReady || savingPassword}
                className="btn-primary px-5 py-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {savingPassword ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Updating…</span>
                  </>
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>Update password</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </section>
      </div>
    </AppShell>
  );
}

interface StatCardProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  tint?: 'blue' | 'emerald' | 'amber';
}

function StatCard({ icon: Icon, label, value, tint = 'blue' }: StatCardProps) {
  const tints = {
    blue: 'bg-blue-50 text-blue-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600',
  };
  return (
    <div className="bg-raised rounded-xl p-4 flex items-center gap-3.5">
      <div
        className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${tints[tint]}`}
      >
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <div className="text-2xl font-bold text-slate-900 leading-none tabular-nums">{value}</div>
        <div className="text-sm text-slate-500 mt-1">{label}</div>
      </div>
    </div>
  );
}

interface PasswordFieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  autoComplete?: string;
  help?: string;
  error?: string | null;
}

function PasswordField({ label, value, onChange, autoComplete, help, error }: PasswordFieldProps) {
  return (
    <div>
      <label className="label">
        <Lock className="w-4 h-4 inline mr-2" />
        {label}
      </label>
      <input
        type="password"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        className={`input px-4 py-2 ${error ? 'border-red-300 focus:ring-red-500' : ''}`}
        required
      />
      {help && <p className="mt-1 text-xs text-slate-500">{help}</p>}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

function FormBanner({ banner }: { banner: { kind: 'success' | 'error'; text: string } }) {
  const isSuccess = banner.kind === 'success';
  return (
    <div
      className={`rounded border p-3 text-sm flex items-center gap-2 ${
        isSuccess
          ? 'bg-emerald-50 border-emerald-100 text-emerald-600'
          : 'bg-red-50 border-red-100 text-red-600'
      }`}
      role="status"
    >
      {isSuccess && <CheckCircle className="w-4 h-4" />}
      <span>{banner.text}</span>
    </div>
  );
}
