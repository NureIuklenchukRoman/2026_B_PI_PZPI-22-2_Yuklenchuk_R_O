import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { testService } from '../services/testService';
import {
  BookOpen,
  ArrowLeft,
  Plus,
  X,
  Check,
  Trash2,
  Edit3,
  Save,
  Hash,
  AlertTriangle,
} from 'lucide-react';
import type { FormEvent } from 'react';
import type { Question, TestInfoForEdit } from '../lib/types';
import PageLayout from '../components/layout/PageLayout';
import Modal from '../components/ui/Modal';
import EmailListInput from '../components/ui/EmailListInput';
import { HashTagInput } from '../components/ui/TagInput';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';

type EditMode = 'test' | 'question';
type DeleteType = 'test' | 'question' | null;

/** New options the user adds in the form don't have an `id` until the
 *  backend round-trips. The wire payload accepts that (id optional);
 *  the local state mirrors. */
type DraftOption = { id?: string; text: string; correct: boolean };

export default function TestEdit() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [test, setTest] = useState<TestInfoForEdit | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeQuestion, setActiveQuestion] = useState<Question | null>(null);
  const [editMode, setEditMode] = useState<EditMode>('test');
  const [isNewQuestion, setIsNewQuestion] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteType, setDeleteType] = useState<DeleteType>(null);
  const [questionToDelete, setQuestionToDelete] = useState<Question | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questionText, setQuestionText] = useState('');
  const [options, setOptions] = useState<DraftOption[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [isPrivate, setIsPrivate] = useState(false);
  const [allowedEmails, setAllowedEmails] = useState<string[]>([]);

  useEffect(() => {
    if (!testId) return;
    const fetchTestInfo = async () => {
      try {
        setLoading(true);
        const data = await testService.getTestInfoForEdit(testId);
        setTest(data);
        setTitle(data.title);
        setDescription(data.description);
        setTags(data.tags);
        if (data.is_public !== undefined) {
          setIsPrivate(!data.is_public);
        } else {
          setIsPrivate(false);
        }
        setAllowedEmails(data.allowed_emails ?? []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load test');
      } finally {
        setLoading(false);
      }
    };

    fetchTestInfo();
  }, [testId]);

  const handleTestUpdate = async (e: FormEvent) => {
    e.preventDefault();
    if (!testId) return;
    try {
      await testService.editTest(testId, {
        title,
        description,
        is_public: !isPrivate,
        allowed_emails: allowedEmails,
      });
      const updatedTest = await testService.getTestInfoForEdit(testId);
      setTest(updatedTest);
      setTitle(updatedTest.title);
      setDescription(updatedTest.description);
      if (updatedTest.is_public !== undefined) {
        setIsPrivate(!updatedTest.is_public);
      }
      if (updatedTest.allowed_emails) {
        setAllowedEmails(updatedTest.allowed_emails);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update test');
    }
  };

  const handleQuestionUpdate = async (e: FormEvent) => {
    e.preventDefault();
    if (!testId) return;
    if (!activeQuestion && !isNewQuestion) return;
    try {
      if (isNewQuestion) {
        await testService.addTestQuestion(testId, {
          question: questionText,
          options,
          tags,
        });
      } else if (activeQuestion) {
        await testService.editTestQuestion(testId, activeQuestion.id, {
          question: questionText,
          options,
          tags,
        });
      }
      const updatedTest = await testService.getTestInfoForEdit(testId);
      setTest(updatedTest);
      setEditMode('test');
      setActiveQuestion(null);
      setIsNewQuestion(false);
      setQuestionText('');
      setOptions([]);
      setTags([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update question');
    }
  };

  const handleQuestionSelect = (question: Question) => {
    setActiveQuestion(question);
    setQuestionText(question.question);
    setOptions(question.options || []);
    setTags(question.tags || []);
    setEditMode('question');
  };

  const handleNewQuestion = () => {
    setIsNewQuestion(true);
    setActiveQuestion(null);
    setQuestionText('');
    setOptions([]);
    setTags([]);
    setEditMode('question');
  };

  const handleDeleteTest = () => {
    setDeleteType('test');
    setShowDeleteModal(true);
  };

  const handleDeleteQuestion = (question: Question) => {
    setDeleteType('question');
    setQuestionToDelete(question);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    if (!testId) return;
    setIsDeleting(true);
    try {
      if (deleteType === 'test') {
        await testService.deleteTest(testId);
        navigate('/home');
      } else if (deleteType === 'question' && questionToDelete) {
        await testService.deleteTestQuestion(testId, questionToDelete.id);
        const updatedTest = await testService.getTestInfoForEdit(testId);
        setTest(updatedTest);

        if (activeQuestion?.id === questionToDelete.id) {
          setEditMode('test');
          setActiveQuestion(null);
          setQuestionText('');
          setOptions([]);
          setTags([]);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete');
    } finally {
      setIsDeleting(false);
      setShowDeleteModal(false);
      setDeleteType(null);
      setQuestionToDelete(null);
    }
  };

  const cancelDelete = () => {
    setShowDeleteModal(false);
    setDeleteType(null);
    setQuestionToDelete(null);
  };

  if (loading)
    return <Loading message="Loading test editor..." submessage="Fetching test details" />;
  if (error) return <ErrorState error={error} />;

  if (!test)
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-raised border border-line rounded flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-8 h-8 text-slate-500" />
          </div>
          <p className="text-slate-500">Test not found</p>
        </div>
      </div>
    );

  const customHeader = (
    <header className="bg-surface border-b border-line sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm shadow-blue-500/30">
              <Edit3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-semibold text-slate-900">Edit test</h1>
              <p className="text-sm text-slate-500 mt-1">
                Customize your test content and questions
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleDeleteTest}
              className="btn-danger flex items-center space-x-2 px-6 py-3 font-medium"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete test</span>
            </button>
            <button
              onClick={() => navigate('/home')}
              className="btn-secondary flex items-center space-x-2 px-6 py-3 font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to tests</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );

  return (
    <PageLayout navbar={customHeader}>
      <Modal
        isOpen={showDeleteModal}
        onClose={cancelDelete}
        title={deleteType === 'test' ? 'Delete test' : 'Delete question'}
        blockBackdropClose={isDeleting}
      >
        <div className="p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-red-50 text-red-600 border border-red-100 rounded flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h3 className="font-display text-xl font-semibold text-slate-900 mb-2">
              {deleteType === 'test' ? 'Delete test' : 'Delete question'}
            </h3>
            <p className="text-slate-500 mb-6">
              {deleteType === 'test'
                ? 'Are you sure you want to delete this entire test? This action cannot be undone and will remove all questions and data associated with this test.'
                : 'Are you sure you want to delete this question? This action cannot be undone.'}
            </p>
            <div className="flex gap-3">
              <button
                onClick={cancelDelete}
                disabled={isDeleting}
                className="btn-secondary flex-1 px-6 py-3 font-medium disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                disabled={isDeleting}
                className="btn-danger flex-1 px-6 py-3 font-medium disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isDeleting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Left Sidebar - Questions List */}
          <div className="col-span-3">
            <div className="card p-6 sticky top-24">
              <div className="flex justify-between items-center mb-6">
                <h2 className="font-display text-xl font-semibold text-slate-900">Questions</h2>
                <button
                  onClick={handleNewQuestion}
                  className="btn-primary flex items-center space-x-2 px-4 py-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>New</span>
                </button>
              </div>
              <div className="space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto">
                {test.questions.map((question, index) => (
                  <button
                    key={question.id}
                    onClick={() => handleQuestionSelect(question)}
                    className={`w-full text-left p-4 rounded border transition-colors relative group ${
                      activeQuestion?.id === question.id
                        ? 'bg-accent/10 border-accent'
                        : 'border-line bg-surface hover:bg-raised hover:border-line-strong'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-slate-900">
                        <span className="tabular-nums">Question {index + 1}</span>
                      </span>
                      {question.tags?.length > 0 && (
                        <span className="tag-accent">{question.tags[0]}</span>
                      )}
                    </div>
                    <p className="text-sm text-slate-500 line-clamp-2">{question.question}</p>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteQuestion(question);
                      }}
                      className="btn-ghost absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="col-span-9">
            <div className="card p-8">
              {editMode === 'test' ? (
                <form onSubmit={handleTestUpdate} className="space-y-8">
                  <div className="text-center mb-8">
                    <h2 className="font-display text-2xl font-semibold text-slate-900 mb-2">
                      Test information
                    </h2>
                    <p className="text-slate-500">Configure your test details and settings</p>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="label">Test Title</label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="input px-4 py-3 text-lg"
                        placeholder="Enter an engaging test title"
                      />
                    </div>

                    <div>
                      <label className="inline-flex items-center gap-3 p-3 rounded border border-line bg-surface hover:bg-raised transition-colors cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={isPrivate}
                          onChange={(e) => setIsPrivate(e.target.checked)}
                          className="w-5 h-5 accent-accent rounded"
                        />
                        <span className="text-sm font-medium text-slate-700">
                          Make this test private
                        </span>
                      </label>
                    </div>

                    <div>
                      <label className="label">Description</label>
                      <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        rows={5}
                        className="input px-4 py-3 resize-none"
                        placeholder="Describe what your test covers and what participants can expect to learn"
                      />
                    </div>

                    {isPrivate && (
                      <div>
                        <label className="label">Allowed Emails</label>
                        <p className="text-xs text-slate-500 mb-2">
                          Only these emails will be able to access this test. Press Enter to add.
                        </p>
                        <EmailListInput value={allowedEmails} onChange={setAllowedEmails} />
                      </div>
                    )}

                    <div>
                      <label className="label">Tags</label>
                      <div className="flex flex-wrap gap-3 mb-4">
                        {tags.map((tag) => (
                          <span key={tag} className="tag-accent px-3 py-1.5">
                            <Hash className="w-3 h-3 mr-1" />
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="btn-primary w-full px-8 py-4 flex items-center justify-center space-x-2 text-lg font-semibold"
                  >
                    <Save className="w-5 h-5" />
                    <span>Save changes</span>
                  </button>
                </form>
              ) : (
                <form onSubmit={handleQuestionUpdate} className="space-y-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h2 className="font-display text-2xl font-semibold text-slate-900 mb-2">
                        {isNewQuestion ? 'Add new question' : 'Edit question'}
                      </h2>
                      <p className="text-slate-500">
                        {isNewQuestion
                          ? 'Create a new question for your test'
                          : 'Modify the selected question'}
                      </p>
                    </div>
                    <div className="flex items-center space-x-3">
                      {!isNewQuestion && activeQuestion && (
                        <button
                          type="button"
                          onClick={() => handleDeleteQuestion(activeQuestion)}
                          className="btn-ghost p-3 text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setEditMode('test');
                          setActiveQuestion(null);
                          setIsNewQuestion(false);
                        }}
                        className="btn-ghost p-3 text-slate-500 hover:text-slate-700"
                      >
                        <X className="w-6 h-6" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <label className="label">Question Text</label>
                      <textarea
                        value={questionText}
                        onChange={(e) => setQuestionText(e.target.value)}
                        rows={4}
                        className="input px-4 py-3 resize-none text-lg"
                        placeholder="Enter your question here..."
                      />
                    </div>

                    <div>
                      <label className="label">Answer Options</label>
                      <div className="space-y-4">
                        {options.map((option, index) => (
                          <div
                            key={index}
                            className="flex gap-3 items-center p-4 bg-raised rounded border border-line"
                          >
                            <input
                              type="text"
                              value={option.text}
                              onChange={(e) => {
                                const newOptions = [...options];
                                newOptions[index] = { ...option, text: e.target.value };
                                setOptions(newOptions);
                              }}
                              className="input flex-1 px-4 py-3"
                              placeholder={`Option ${index + 1}`}
                            />

                            <label className="flex items-center gap-2 text-sm font-medium text-slate-700 bg-surface px-3 py-2 rounded border border-line">
                              <input
                                type="checkbox"
                                checked={option.correct || false}
                                onChange={(e) => {
                                  const newOptions = [...options];
                                  newOptions[index] = { ...option, correct: e.target.checked };
                                  setOptions(newOptions);
                                }}
                                className="w-4 h-4 accent-accent rounded"
                              />
                              <Check className="w-4 h-4 text-emerald-600" />
                              <span>Correct</span>
                            </label>

                            <button
                              type="button"
                              onClick={() => {
                                setOptions(options.filter((_, i) => i !== index));
                              }}
                              className="btn-ghost p-2 text-red-600 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}

                        <button
                          type="button"
                          onClick={() => setOptions([...options, { text: '', correct: false }])}
                          className="w-full px-6 py-4 text-accent rounded border border-dashed border-line hover:border-accent transition-colors flex items-center justify-center space-x-2 font-medium"
                        >
                          <Plus className="w-5 h-5" />
                          <span>Add Option</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="label">Question Tags</label>
                      <HashTagInput
                        value={tags}
                        onChange={setTags}
                        placeholder="Add tags (press Enter)"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button
                      type="submit"
                      className="btn-primary flex-1 px-8 py-4 flex items-center justify-center space-x-2 text-lg font-semibold"
                    >
                      <Save className="w-5 h-5" />
                      <span>Save Question</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditMode('test');
                        setActiveQuestion(null);
                        setIsNewQuestion(false);
                      }}
                      className="btn-secondary px-8 py-4 flex items-center justify-center space-x-2 font-semibold"
                    >
                      <X className="w-5 h-5" />
                      <span>Cancel</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </main>
    </PageLayout>
  );
}
