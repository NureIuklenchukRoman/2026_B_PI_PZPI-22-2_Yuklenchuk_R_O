import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import type { ComponentType } from 'react';
import { Search, Edit3, Trash2, Upload, Plus, Award, Target, Library, ChevronRight } from 'lucide-react';

import { testService } from '../services/testService';
import type { TestSummary, TakeSummary } from '../lib/types';
import { useCurrentUser } from '../lib/auth/AuthContext';
import TestConfirmModal from '../components/TestConfirmModal';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';
import FilterBar from '../components/FilterBar';
import Badge, { scoreBadge } from '../components/ui/Badge';
import AppShell from '../components/layout/AppShell';
import type { TestSort } from '../lib/api/tests';

function Stat({
  icon: Icon,
  label,
  value,
  tint,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: string;
  tint: 'blue' | 'emerald' | 'amber';
}) {
  const tints = {
    blue: 'bg-blue-50 text-blue-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600',
  };
  return (
    <div className="card p-5 flex items-center gap-4">
      <div
        className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${tints[tint]}`}
      >
        <Icon className="w-[22px] h-[22px]" />
      </div>
      <div className="min-w-0">
        <div className="text-[26px] font-bold text-slate-900 leading-none tabular-nums">{value}</div>
        <div className="text-sm text-slate-500 mt-1.5">{label}</div>
      </div>
    </div>
  );
}

function Home() {
  const navigate = useNavigate();
  const user = useCurrentUser();
  const userName = user?.username ?? '';
  const isAdmin = user?.is_admin ?? false;

  // `rows` are the server-filtered results shown in the table; `totalTests`
  // is the full accessible catalog size (for the stat), fetched once.
  const [rows, setRows] = useState<TestSummary[]>([]);
  const [totalTests, setTotalTests] = useState(0);
  const [availableTags, setAvailableTags] = useState<string[]>([]);
  const [takes, setTakes] = useState<TakeSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refetching, setRefetching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filter state drives server requests (no client-side filtering).
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<TestSort>('newest');

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedTest, setSelectedTest] = useState<TestSummary | null>(null);
  const [deletingTestId, setDeletingTestId] = useState<string | null>(null);

  const toggleTag = (tag: string) =>
    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));

  // Initial load: full catalog (for the stat + tags) and the user's takes.
  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true);
        const [all, tags] = await Promise.all([
          testService.getTests({ pageSize: 100, sort: 'newest' }),
          testService.getTestTags().catch(() => [] as string[]),
        ]);
        setRows(all);
        setTotalTests(all.length);
        setAvailableTags(tags.length ? tags : Array.from(new Set(all.flatMap((t) => t.tags ?? []))));
        try {
          setTakes(await testService.getUserTakes());
        } catch {
          /* stats/status degrade gracefully */
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load tests');
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  // Re-query the backend whenever filters change (search is debounced).
  const initialLoad = loading;
  useEffect(() => {
    if (initialLoad) return;
    const handle = setTimeout(
      async () => {
        try {
          setRefetching(true);
          const data = await testService.getTests({
            q: searchTerm,
            tags: selectedTags,
            sort: sortBy,
            pageSize: 100,
          });
          setRows(data);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to load tests');
        } finally {
          setRefetching(false);
        }
      },
      searchTerm ? 300 : 0
    );
    return () => clearTimeout(handle);
  }, [searchTerm, selectedTags, sortBy, initialLoad]);

  const handleTestClick = (test: TestSummary) => {
    setSelectedTest(test);
    setShowConfirmModal(true);
  };

  const handleStartTest = () => {
    if (selectedTest) navigate(`/tests/${selectedTest.test_id}`);
    setShowConfirmModal(false);
    setSelectedTest(null);
  };

  const handleCancelTest = () => {
    setShowConfirmModal(false);
    setSelectedTest(null);
  };

  const handleAdminDelete = async (test: TestSummary) => {
    if (!isAdmin) return;
    const confirmed = window.confirm(
      `Delete "${test.title}"? This removes the test for every user and cannot be undone.`
    );
    if (!confirmed) return;
    setDeletingTestId(test.test_id);
    try {
      await testService.deleteTest(test.test_id);
      setRows((prev) => prev.filter((t) => t.test_id !== test.test_id));
      setTotalTests((n) => Math.max(0, n - 1));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete test');
    } finally {
      setDeletingTestId(null);
    }
  };

  if (loading) return <Loading message="Loading tests..." submessage="Fetching available tests" />;
  if (error) return <ErrorState error={error} />;

  // Best score per test from the user's history → the catalog status column.
  const bestByTest = new Map<string, number>();
  for (const t of takes) {
    if (!t.questions_amount) continue;
    const pct = Math.round((t.res_count / t.questions_amount) * 100);
    bestByTest.set(t.test_id, Math.max(bestByTest.get(t.test_id) ?? 0, pct));
  }

  const avgScore =
    takes.length > 0
      ? Math.round(
          takes.reduce(
            (sum, t) => sum + (t.questions_amount ? (t.res_count / t.questions_amount) * 100 : 0),
            0
          ) / takes.length
        )
      : null;

  const firstName = userName.split(' ')[0];

  return (
    <AppShell
      title={firstName ? `Welcome back, ${firstName}` : 'Browse tests'}
      subtitle={
        isAdmin
          ? 'Admin mode — every test in the system is listed below.'
          : 'Pick up where you left off, or start something new.'
      }
      maxWidth="max-w-7xl"
      actions={
        <>
          <button
            onClick={() => navigate('/create-test-manually')}
            className="btn-secondary px-3 py-1.5 text-sm"
          >
            <Plus className="w-4 h-4" />
            Create
          </button>
          <button
            onClick={() => navigate('/upload-new-test')}
            className="btn-primary px-3 py-1.5 text-sm"
          >
            <Upload className="w-4 h-4" />
            Upload material
          </button>
        </>
      }
    >
      <TestConfirmModal
        isOpen={showConfirmModal}
        test={selectedTest}
        onConfirm={handleStartTest}
        onCancel={handleCancelTest}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <Stat icon={Award} tint="blue" label="Tests taken" value={String(takes.length)} />
        <Stat
          icon={Target}
          tint="emerald"
          label="Average score"
          value={avgScore === null ? '—' : `${avgScore}%`}
        />
        <Stat icon={Library} tint="amber" label="Tests available" value={String(totalTests)} />
      </div>

      {/* Catalog */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base font-semibold text-slate-900">All tests</h2>
        <span className="text-sm text-slate-400">
          {rows.length} of {totalTests}
        </span>
      </div>

      <FilterBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        sortBy={sortBy}
        onSortChange={(v) => setSortBy(v as TestSort)}
        sortOptions={[
          { value: 'newest', label: 'Newest first' },
          { value: 'oldest', label: 'Oldest first' },
          { value: 'title', label: 'Title (A–Z)' },
          { value: 'questions', label: 'Most questions' },
        ]}
        availableTags={availableTags}
        selectedTags={selectedTags}
        onToggleTag={toggleTag}
      />

      {rows.length > 0 ? (
        <div className={`card overflow-hidden transition-opacity ${refetching ? 'opacity-60' : ''}`}>
          <div className="overflow-x-auto">
            <table className="data-table table-fixed">
              <thead>
                <tr>
                  <th className="w-[38%]">Test</th>
                  <th className="hidden lg:table-cell">Topics</th>
                  <th className="text-right w-24">Questions</th>
                  <th className="w-32">Your result</th>
                  {isAdmin && <th className="w-20 text-right">Actions</th>}
                  <th className="w-9" />
                </tr>
              </thead>
              <tbody>
                {rows.map((test) => {
                  const best = bestByTest.get(test.test_id);
                  const status = best === undefined ? null : scoreBadge(best);
                  return (
                    <tr key={test.test_id} onClick={() => handleTestClick(test)} className="group">
                      <td>
                        <div className="font-medium text-slate-900 truncate group-hover:text-accent transition-colors">
                          {test.title}
                        </div>
                        {test.description && (
                          <div className="text-xs text-slate-500 truncate mt-0.5">
                            {test.description}
                          </div>
                        )}
                      </td>
                      <td className="hidden lg:table-cell">
                        <div className="flex items-center gap-1 overflow-hidden whitespace-nowrap">
                          {test.tags?.slice(0, 2).map((tag) => (
                            <span key={tag} className="tag">
                              {tag}
                            </span>
                          ))}
                          {test.tags && test.tags.length > 2 && (
                            <span className="text-[11px] text-slate-500">
                              +{test.tags.length - 2}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="text-right text-slate-700 tabular-nums">
                        {test.question_amount}
                      </td>
                      <td>
                        {status ? (
                          <Badge tone={status.tone} label={`${status.label} · ${best}%`} />
                        ) : (
                          <Badge tone="idle" label="Not taken" />
                        )}
                      </td>
                      {isAdmin && (
                        <td>
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/tests/${test.test_id}/edit`);
                              }}
                              className="btn-ghost p-1.5"
                              title="Edit test"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                void handleAdminDelete(test);
                              }}
                              disabled={deletingTestId === test.test_id}
                              className="btn-ghost p-1.5 text-red-600 hover:bg-red-50 disabled:opacity-40"
                              title="Delete test"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      )}
                      <td>
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card py-16 px-6 text-center">
          <Search className="w-6 h-6 text-slate-500 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-slate-800 mb-1">No tests found</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Adjust your search or filters, or upload source material to generate a new test.
          </p>
        </div>
      )}
    </AppShell>
  );
}

export default Home;
