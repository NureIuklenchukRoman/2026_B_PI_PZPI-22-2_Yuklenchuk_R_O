import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Mail, Lock, UserPlus, LogIn, CheckCircle } from 'lucide-react';
import * as auth from '../lib/api/auth';
import { useAuth } from '../lib/auth/AuthContext';

function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { refresh } = useAuth();

  const handleSubmit = async () => {
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await auth.register(email, password);
      // Refresh AuthContext from /users/me with the new cookie before
      // navigating; otherwise RequireAuth still sees the pre-register
      // 'anonymous' status and bounces us back to '/'.
      await refresh();
      navigate('/home');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base">
      {/* Header */}
      <header className="bg-surface border-b border-line">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm shadow-blue-500/30">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <h1 className="font-display text-2xl font-semibold text-slate-900">Testify</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex items-center justify-center min-h-[calc(100vh-73px)] px-4 sm:px-6 lg:px-8 py-12">
        <div className="w-full max-w-md">
          {/* Welcome Section */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-accent/10 text-accent border border-accent/20 rounded flex items-center justify-center mx-auto mb-6">
              <UserPlus className="w-8 h-8" />
            </div>
            <h2 className="font-display text-3xl font-semibold text-slate-900 mb-2">Join Testify</h2>
            <p className="text-slate-500">Create your account and start learning today</p>
          </div>

          {/* Register Form */}
          <div className="card p-8">
            <div className="space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-100 text-red-600 rounded p-3">
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <div>
                <label className="label">
                  Email address
                </label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-4 top-1/2 z-10 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input pl-12 pr-4 py-3"
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <label className="label">Password</label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-4 top-1/2 z-10 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
                  <input
                    type="password"
                    placeholder="Create a strong password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input pl-12 pr-4 py-3"
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <label className="label">
                  Confirm password
                </label>
                <div className="relative">
                  <CheckCircle
                    className={`pointer-events-none absolute left-4 top-1/2 z-10 transform -translate-y-1/2 w-5 h-5 transition-colors duration-300 ${
                      confirmPassword && password === confirmPassword
                        ? 'text-emerald-600'
                        : 'text-slate-500'
                    }`}
                  />
                  <input
                    type="password"
                    placeholder="Confirm your password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`input pl-12 pr-4 py-3 ${
                      confirmPassword && password !== confirmPassword
                        ? 'border-red-300 focus:ring-red-500'
                        : confirmPassword && password === confirmPassword
                          ? 'border-emerald-300 focus:ring-emerald-500'
                          : ''
                    }`}
                    disabled={loading}
                  />
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-red-600 text-sm mt-2 flex items-center space-x-1">
                    <span>Passwords do not match</span>
                  </p>
                )}
                {confirmPassword && password === confirmPassword && (
                  <p className="text-emerald-600 text-sm mt-2 flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4" />
                    <span>Passwords match</span>
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading || !email || !password || password !== confirmPassword}
                className="btn-primary w-full py-3 px-6 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-base border-t-transparent rounded-full animate-spin"></div>
                    <span>Creating account...</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-5 h-5" />
                    <span>Create account</span>
                  </>
                )}
              </button>
            </div>

            {/* Login Link */}
            <div className="mt-8 pt-6 border-t border-line">
              <div className="text-center">
                <p className="text-slate-500 mb-4">Already have an account?</p>
                <a
                  href="/"
                  className="inline-flex items-center gap-2 text-accent hover:text-accent/80 font-medium transition-colors"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Sign in</span>
                </a>
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="text-center mt-8">
            <p className="text-xs text-slate-500">
              By creating an account, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default Register;
