import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { testService } from '../services/testService';
import type { TestSummary } from '../lib/types';
import { Search, Edit3, Plus, Upload, ChevronRight } from 'lucide-react';
import TestConfirmModal from '../components/TestConfirmModal';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';
import FilterBar from '../components/FilterBar';
import AppShell from '../components/layout/AppShell';
import useTestFiltering from '../hooks/useTestFiltering';

/** UserTests cards include an isPrivate flag the list endpoint
 *  doesn't return today; left as optional so the conditional UI
 *  compiles without a behavior change. */
type UserTest = TestSummary & { isPrivate?: boolean };

function UserTests() {
  const navigate = useNavigate();
  const [tests, setTests] = useState<UserTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedTest, setSelectedTest] = useState<UserTest | null>(null);

  const {
    searchTerm,
    setSearchTerm,
    selectedTags,
    sortBy,
    setSortBy,
    availableTags,
    filteredItems: filteredTests,
    toggleTag,
  } = useTestFiltering(tests);

  useEffect(() => {
    const fetchTests = async () => {
      try {
        setLoading(true);
        const data = await testService.getUserTests();
        setTests(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load tests');
      } finally {
        setLoading(false);
      }
    };

    fetchTests();
  }, []);

  const handleTestClick = (test: UserTest) => {
    setSelectedTest(test);
    setShowConfirmModal(true);
  };

  const handleStartTest = () => {
    if (selectedTest) {
      navigate(`/tests/${selectedTest.test_id}`);
    }
    setShowConfirmModal(false);
    setSelectedTest(null);
  };

  const handleCancelTest = () => {
    setShowConfirmModal(false);
    setSelectedTest(null);
  };

  if (loading)
    return <Loading message="Loading your tests..." submessage="Fetching your created tests" />;
  if (error) return <ErrorState error={error} />;

  return (
    <AppShell
      title="My tests"
      subtitle="Watch tests you created and edit them."
      maxWidth="max-w-7xl"
      actions={
        <>
          <button
            onClick={() => navigate('/create-test-manually')}
            className="btn-secondary px-3 py-1.5 text-sm"
          >
            <Plus className="w-4 h-4" />
            Create
          </button>
          <button
            onClick={() => navigate('/upload-new-test')}
            className="btn-primary px-3 py-1.5 text-sm"
          >
            <Upload className="w-4 h-4" />
            Upload material
          </button>
        </>
      }
    >
      <TestConfirmModal
        isOpen={showConfirmModal}
        test={selectedTest}
        onConfirm={handleStartTest}
        onCancel={handleCancelTest}
      />

      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-sm font-semibold text-slate-500">
          Your tests
        </h2>
        <span className="text-xs text-slate-500">
          {filteredTests.length}/{tests.length}
        </span>
      </div>

      <FilterBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        sortBy={sortBy}
        onSortChange={setSortBy}
        availableTags={availableTags}
        selectedTags={selectedTags}
        onToggleTag={toggleTag}
      />

      {filteredTests.length > 0 ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Test</th>
                  <th className="hidden md:table-cell">Tags</th>
                  <th className="text-right w-20">Qs</th>
                  <th className="w-20 text-right">Actions</th>
                  <th className="w-8" />
                </tr>
              </thead>
              <tbody>
                {filteredTests.map((test) => (
                  <tr key={test.test_id} onClick={() => handleTestClick(test)}>
                    <td>
                      <div className="font-medium text-slate-900">{test.title}</div>
                      {test.description && (
                        <div className="text-xs text-slate-500 truncate max-w-md mt-0.5">
                          {test.description}
                        </div>
                      )}
                    </td>
                    <td className="hidden md:table-cell">
                      <div className="flex flex-wrap gap-1">
                        {test.tags?.slice(0, 3).map((tag) => (
                          <span key={tag} className="tag">
                            {tag}
                          </span>
                        ))}
                        {test.tags && test.tags.length > 3 && (
                          <span className="text-xs text-slate-500">
                            +{test.tags.length - 3}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="text-right text-slate-700 tabular-nums">
                      {test.question_amount}
                    </td>
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/tests/${test.test_id}/edit`);
                          }}
                          className="btn-ghost p-1.5"
                          title="Edit test"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    <td>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card py-16 px-6 text-center">
          <Search className="w-6 h-6 text-slate-500 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-slate-800 mb-1">No tests found</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Adjust your search or filters to discover more tests, or create your own.
          </p>
        </div>
      )}
    </AppShell>
  );
}

export default UserTests;
