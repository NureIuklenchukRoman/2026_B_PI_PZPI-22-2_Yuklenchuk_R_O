import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  BookOpen,
  X,
  CheckCircle,
  Circle,
  ArrowRight,
  Home,
  Trophy,
  AlertTriangle,
} from 'lucide-react';

import { testService } from '../services/testService';
import type { Question } from '../lib/types';
import PageLayout from '../components/layout/PageLayout';
import Modal from '../components/ui/Modal';

export default function TestTaking() {
  const { testId } = useParams();
  const navigate = useNavigate();
  const [question, setQuestion] = useState<Question | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isTestComplete, setIsTestComplete] = useState(false);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [currentQuestionNumber, setCurrentQuestionNumber] = useState(1);
  const [showExitConfirmation, setShowExitConfirmation] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (!testId) return;
    let isMounted = true;

    const fetchTestData = async () => {
      try {
        setLoading(true);

        const [questionData, questionsAmount] = await Promise.all([
          testService.startTest(testId),
          testService.getTestQuestionsAmount(testId),
        ]);

        if (isMounted) {
          setQuestion(questionData);
          setTotalQuestions(questionsAmount);
          setCurrentQuestionNumber(1);
        }
      } catch (err) {
        console.error('Failed to fetch test data:', err);
        if (isMounted) setError('Failed to load test data');
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchTestData();

    return () => {
      isMounted = false;
    };
  }, [testId]);

  const handleAnswerSelect = (answerId: string) => {
    setSelectedAnswers((prev) =>
      prev.includes(answerId) ? prev.filter((id) => id !== answerId) : [...prev, answerId]
    );
  };

  const handleAnswerSubmit = async () => {
    if (!testId || !question || selectedAnswers.length === 0) return;

    try {
      const response = await testService.submitAnswer(testId, question.id, selectedAnswers);

      if (response.next_question === 'No more questions available') {
        setIsTestComplete(true);
      } else if (response.next_question) {
        setQuestion(response.next_question as Question);
        setSelectedAnswers([]);
        setCurrentQuestionNumber((prev) => prev + 1);
      } else {
        throw new Error('Unexpected response format');
      }
    } catch (err) {
      console.error('Failed to submit answer:', err);
      setError('Failed to submit answer');
    }
  };

  const handleExitTest = () => {
    setShowExitConfirmation(true);
  };

  const confirmExitTest = async () => {
    if (!testId) return;
    try {
      setIsExiting(true);
      await testService.endTest(testId);
      navigate('/home');
    } catch (err) {
      console.error('Failed to end test:', err);
      setError('Failed to end test');
      setIsExiting(false);
    }
  };

  const cancelExitTest = () => {
    setShowExitConfirmation(false);
  };

  if (loading)
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="text-center relative">
          <div className="relative mb-8">
            <div className="w-20 h-20 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-line"></div>
              <div className="absolute inset-0 rounded-full border-4 border-accent border-t-transparent animate-spin"></div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="h-6 bg-raised rounded w-64 mx-auto animate-pulse"></div>
            <div className="h-4 bg-raised rounded w-48 mx-auto animate-pulse"></div>
            <div className="h-4 bg-raised rounded w-32 mx-auto animate-pulse"></div>
          </div>
          <p className="text-lg text-slate-500 mt-6 font-medium">Loading your test...</p>
        </div>
      </div>
    );

  if (error)
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="card p-10 max-w-md mx-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-amber-50 text-amber-700 border border-amber-100 rounded flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-slate-900 mb-3">
              Something went wrong
            </h3>
            <p className="text-slate-500 mb-6">{error}</p>
            <button
              onClick={() => navigate('/home')}
              className="btn-primary px-8 py-3 font-semibold"
            >
              Back to home
            </button>
          </div>
        </div>
      </div>
    );

  if (!question)
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="card p-10 max-w-md mx-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-raised border border-line rounded flex items-center justify-center mx-auto mb-6">
              <BookOpen className="w-8 h-8 text-slate-500" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-slate-900 mb-3">
              Test not found
            </h3>
            <p className="text-slate-500 mb-6">
              The test you're looking for doesn't exist or has been removed.
            </p>
            <button
              onClick={() => navigate('/home')}
              className="btn-primary px-8 py-3 font-semibold"
            >
              Back to home
            </button>
          </div>
        </div>
      </div>
    );

  if (isTestComplete) {
    return (
      <div className="min-h-screen bg-base">
        {/* Header */}
        <header className="bg-surface border-b border-line">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm shadow-blue-500/30">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <h1 className="font-display text-3xl font-semibold text-slate-900">
                  Test complete
                </h1>
              </div>
            </div>
          </div>
        </header>

        <div className="flex items-center justify-center min-h-[calc(100vh-88px)] px-4">
          <div className="card p-12 max-w-2xl mx-auto text-center">
            <div className="w-24 h-24 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8">
              <Trophy className="w-12 h-12" />
            </div>

            <h1 className="font-display text-5xl font-semibold mb-6 text-slate-900">
              Congratulations!
            </h1>

            <p className="text-xl text-slate-500 mb-8 leading-relaxed">
              You have successfully completed all questions in this test. Great job on finishing the
              challenge!
            </p>

            <div className="bg-raised border border-line rounded p-6 mb-8 text-left">
              <h3 className="text-lg font-semibold text-slate-800 mb-2">What's next?</h3>
              <p className="text-slate-500">
                Ready to take on more challenges? Head back to explore other tests and continue your
                learning journey.
              </p>
            </div>

            <button
              onClick={() => navigate('/home')}
              className="btn-primary inline-flex items-center space-x-3 px-10 py-4 font-semibold text-lg"
            >
              <Home className="w-6 h-6" />
              <span>Back to tests</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const progressPct =
    totalQuestions > 0 ? ((currentQuestionNumber - 1) / totalQuestions) * 100 : 0;

  const customHeader = (
    <header className="bg-surface border-b border-line sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm shadow-blue-500/30">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <h1 className="font-display text-2xl font-semibold text-slate-900">Test in progress</h1>
          </div>
          <button
            onClick={handleExitTest}
            className="btn-secondary flex items-center space-x-2 px-4 py-2 font-medium"
          >
            <X className="w-4 h-4" />
            <span>Exit Test</span>
          </button>
        </div>
      </div>
    </header>
  );

  return (
    <PageLayout navbar={customHeader}>
      <Modal
        isOpen={showExitConfirmation}
        onClose={cancelExitTest}
        title="Exit test?"
        blockBackdropClose={isExiting}
      >
        <div className="p-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-amber-50 text-amber-700 border border-amber-100 rounded flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <h3 className="font-display text-2xl font-semibold text-slate-900 mb-3">Exit test?</h3>
            <p className="text-slate-500 mb-8 leading-relaxed">
              Are you sure you want to end the test now? Your progress will be lost and you'll be
              redirected to the home page.
            </p>

            <div className="flex space-x-4">
              <button
                onClick={cancelExitTest}
                disabled={isExiting}
                className="btn-secondary flex-1 px-6 py-3 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={confirmExitTest}
                disabled={isExiting}
                className="btn-danger flex-1 px-6 py-3 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isExiting ? 'Exiting...' : 'Yes, Exit'}
              </button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="card overflow-hidden">
          {/* Question Header */}
          <div className="bg-accent px-8 py-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">
                  Question {currentQuestionNumber}
                  {totalQuestions > 0 && <span className="text-white/70"> of {totalQuestions}</span>}
                </h2>
                <p className="text-white/70 text-sm">Choose the best answer(s)</p>
              </div>
              {totalQuestions > 0 && (
                <div className="text-right">
                  <div className="tabular-nums text-white text-sm font-medium mb-1">
                    {Math.round(progressPct)}% Complete
                  </div>
                  <div className="w-24 h-2 bg-black/20 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-base rounded-full transition-all duration-500 ease-out"
                      style={{ width: `${progressPct}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-base/60 rounded-full"></div>
              <div className="flex-1 h-1 bg-black/20 rounded-full">
                <div
                  className="h-full bg-base rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${progressPct}%` }}
                ></div>
              </div>
              <span className="text-white/80 text-sm font-medium">In Progress</span>
            </div>
          </div>

          {/* Question Content */}
          <div className="p-8">
            <h3 className="text-3xl font-bold text-slate-900 mb-8 leading-relaxed">
              {question.question}
            </h3>

            <div className="space-y-4 mb-8">
              {question.options.map((option) => {
                const isSelected = selectedAnswers.includes(option.id);
                return (
                  <label
                    key={option.id}
                    className={`group block p-6 rounded border cursor-pointer transition-colors ${
                      isSelected
                        ? 'border-accent bg-accent/10'
                        : 'border-line bg-surface hover:border-line-strong hover:bg-raised'
                    }`}
                  >
                    <div className="flex items-start space-x-4">
                      {isSelected ? (
                        <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-6 h-6 text-slate-500 flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <span
                          className={`text-lg font-medium leading-relaxed ${
                            isSelected ? 'text-slate-900' : 'text-slate-700 group-hover:text-slate-900'
                          }`}
                        >
                          {option.text}
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleAnswerSelect(option.id)}
                        className="sr-only"
                      />
                    </div>
                  </label>
                );
              })}
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-6 border-t border-line">
              <button
                onClick={handleAnswerSubmit}
                disabled={selectedAnswers.length === 0}
                className="btn-primary inline-flex items-center space-x-3 px-8 py-4 font-semibold text-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span>Submit Answer</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-surface rounded px-6 py-3 border border-line">
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-slate-700">
              {selectedAnswers.length > 0
                ? `${selectedAnswers.length} answer${selectedAnswers.length > 1 ? 's' : ''} selected`
                : 'Select your answer(s) to continue'}
              {totalQuestions > 0 && (
                <span className="ml-2 tabular-nums text-slate-500">
                  • Question {currentQuestionNumber} of {totalQuestions}
                </span>
              )}
            </span>
          </div>
        </div>
      </main>
    </PageLayout>
  );
}
