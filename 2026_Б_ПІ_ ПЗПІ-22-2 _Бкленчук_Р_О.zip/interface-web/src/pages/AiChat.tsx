import { useState, useRef, useEffect } from 'react';
import type { ChangeEvent, KeyboardEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Bot,
  ChevronDown,
  ChevronUp,
  Database,
  FileText,
  Loader2,
  Send,
  Shield,
  Upload,
  User,
  Video,
} from 'lucide-react';
import AppShell from '../components/layout/AppShell';
import Badge, { jobStatusBadge } from '../components/ui/Badge';
import * as knowledgeApi from '../lib/api/knowledge';
import type { ParseJob } from '../lib/api/knowledge';
import { ApiError } from '../lib/api/client';
import { useCurrentUser } from '../lib/auth/AuthContext';
import { testService } from '../services/testService';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

type UploadBanner = { kind: 'success' | 'error'; text: string } | null;
type UploadMode = 'text' | 'media';

const TERMINAL_JOB_STATUSES = new Set<ParseJob['status']>(['completed', 'failed', 'canceled']);

const TEXT_FILE_EXTS = ['.txt', '.md', '.markdown'];

async function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error ?? new Error('Failed to read file'));
    reader.onload = () => resolve(String(reader.result ?? ''));
    reader.readAsText(file);
  });
}

function AiChat() {
  const [searchParams] = useSearchParams();
  const knowledgeId = searchParams.get('knowledgeId');
  const currentUser = useCurrentUser();
  const showAdminUpload = !!currentUser?.is_admin && !knowledgeId;
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Load the saved thread for this chat (per user, per knowledge context).
  useEffect(() => {
    let cancelled = false;
    setHistoryLoading(true);
    testService
      .getConversation(knowledgeId)
      .then((history) => {
        if (!cancelled) setMessages(history.map((m) => ({ role: m.role, content: m.content })));
      })
      .catch(() => {
        if (!cancelled) setMessages([]);
      })
      .finally(() => {
        if (!cancelled) setHistoryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [knowledgeId]);

  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadMode, setUploadMode] = useState<UploadMode>('text');
  const [uploadText, setUploadText] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadBanner, setUploadBanner] = useState<UploadBanner>(null);
  const [activeJob, setActiveJob] = useState<ParseJob | null>(null);

  // Poll the most recent global-upload job until it reaches a terminal
  // state. The 1s/8s cadence matches UploadNewTest so users see fresh
  // progress without burning requests once the job has settled.
  useEffect(() => {
    if (!activeJob) return;
    if (TERMINAL_JOB_STATUSES.has(activeJob.status)) return;
    let active = true;
    const interval = window.setInterval(async () => {
      try {
        const next = await knowledgeApi.getParseJob(activeJob.job_id);
        if (!active) return;
        setActiveJob(next);
      } catch {
        // Transient failures: keep the last good state and try again.
      }
    }, 1500);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [activeJob]);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    setUploadFile(e.target.files?.[0] ?? null);
    setUploadBanner(null);
  };

  const handleGlobalUpload = async () => {
    if (uploading) return;
    setUploadBanner(null);

    try {
      if (uploadMode === 'text') {
        const trimmed = uploadText.trim();
        if (!trimmed) {
          setUploadBanner({ kind: 'error', text: 'Please paste some text first.' });
          return;
        }
        setUploading(true);
        const job = await knowledgeApi.createGlobalTextJob(trimmed);
        setUploadText('');
        setActiveJob(job);
        setUploadBanner({ kind: 'success', text: 'Text queued for global ingest.' });
        return;
      }

      // Media tab: .txt/.md are read client-side and submitted as text
      // so they skip the speech-service round-trip and complete fast.
      const file = uploadFile;
      if (!file) {
        setUploadBanner({ kind: 'error', text: 'Please choose a file to upload.' });
        return;
      }
      setUploading(true);
      const lowerName = file.name.toLowerCase();
      const isTextFile = TEXT_FILE_EXTS.some((ext) => lowerName.endsWith(ext));
      if (isTextFile) {
        const text = (await readFileAsText(file)).trim();
        if (!text) {
          setUploadBanner({ kind: 'error', text: 'Document is empty.' });
          return;
        }
        const job = await knowledgeApi.createGlobalTextJob(text);
        setActiveJob(job);
        setUploadBanner({ kind: 'success', text: 'Document queued for global ingest.' });
      } else {
        const job = await knowledgeApi.createGlobalMediaJob(file);
        setActiveJob(job);
        setUploadBanner({
          kind: 'success',
          text: 'Media queued — transcribing before ingest.',
        });
      }
      setUploadFile(null);
    } catch (err) {
      const detail =
        err instanceof ApiError || err instanceof Error ? err.message : 'Upload failed';
      setUploadBanner({ kind: 'error', text: detail });
    } finally {
      setUploading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const userMessage: ChatMessage = { role: 'user', content: trimmed };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const data = await testService.askKnowledge(trimmed, knowledgeId);
      setMessages((prev) => [...prev, { role: 'assistant', content: data.answer }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: 'Sorry, something went wrong. Please try again.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <AppShell
      title="Assistant"
      subtitle="Ask anything about your tests and knowledge base."
      backTo={{ to: '/home', label: 'Browse tests' }}
      maxWidth="max-w-4xl"
    >
      {showAdminUpload && (
        <section className="card mb-4">
          <button
            type="button"
            onClick={() => setUploadOpen((open) => !open)}
            className="w-full flex items-center justify-between px-5 py-3 text-left"
            aria-expanded={uploadOpen}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded bg-accent/10 text-accent border border-accent/20 flex items-center justify-center flex-shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <Database className="w-4 h-4 text-accent" />
                  Upload to global knowledge base
                </div>
                <div className="text-xs text-slate-500">
                  Visible to every user from this general chat. Admin only.
                </div>
              </div>
            </div>
            {uploadOpen ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {uploadOpen && (
            <div className="px-5 pb-5 pt-2 border-t border-line space-y-3">
              <div className="inline-flex rounded border border-line bg-surface p-0.5">
                <button
                  type="button"
                  onClick={() => setUploadMode('text')}
                  className={`inline-flex items-center gap-2 px-3 py-1.5 text-sm rounded font-medium transition-colors ${
                    uploadMode === 'text' ? 'bg-accent text-white' : 'text-slate-500 hover:bg-raised'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  Text
                </button>
                <button
                  type="button"
                  onClick={() => setUploadMode('media')}
                  className={`inline-flex items-center gap-2 px-3 py-1.5 text-sm rounded font-medium transition-colors ${
                    uploadMode === 'media' ? 'bg-accent text-white' : 'text-slate-500 hover:bg-raised'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  Document / Video
                </button>
              </div>

              {uploadMode === 'text' ? (
                <textarea
                  value={uploadText}
                  onChange={(e) => setUploadText(e.target.value)}
                  placeholder="Paste the source text to ingest into the global knowledge base..."
                  rows={6}
                  className="input w-full px-4 py-3 text-sm"
                  disabled={uploading}
                />
              ) : (
                <div className="space-y-2">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    accept=".txt,.md,.markdown,audio/*,video/*"
                    className="block w-full text-sm text-slate-500 file:mr-3 file:rounded file:border-0 file:bg-accent/10 file:text-accent file:px-3 file:py-2 file:font-medium hover:file:bg-accent/20"
                    disabled={uploading}
                  />
                  <p className="text-xs text-slate-500">
                    Plain-text files (.txt, .md) are read in-browser and submitted as text.
                    Audio/video files are routed through speech-to-text before ingestion.
                  </p>
                  {uploadFile && (
                    <p className="text-xs text-slate-700">
                      Selected: <span className="font-medium">{uploadFile.name}</span>
                    </p>
                  )}
                </div>
              )}

              {uploadBanner && (
                <div
                  role="status"
                  className={`rounded border p-3 text-sm ${
                    uploadBanner.kind === 'success'
                      ? 'bg-emerald-50 border-emerald-100 text-emerald-600'
                      : 'bg-red-50 border-red-100 text-red-600'
                  }`}
                >
                  {uploadBanner.text}
                </div>
              )}

              {activeJob && (
                <div className="rounded border border-line bg-raised p-3 text-sm text-slate-800">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium">
                      {activeJob.source_type === 'media' ? 'Media job' : 'Text job'}
                    </span>
                    <Badge {...jobStatusBadge(activeJob.status)} dot />
                  </div>
                  <div className="text-xs text-slate-500">
                    {activeJob.message ?? activeJob.stage}
                    {activeJob.total_chunks > 0 && (
                      <>
                        {' • '}
                        <span className="tabular-nums">
                          {activeJob.completed_chunks}/{activeJob.total_chunks} chunks
                        </span>
                      </>
                    )}
                  </div>
                  {activeJob.error_message && (
                    <div className="mt-1 text-xs text-red-600">
                      {activeJob.error_message}
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={handleGlobalUpload}
                  disabled={
                    uploading ||
                    (uploadMode === 'text' && !uploadText.trim()) ||
                    (uploadMode === 'media' && !uploadFile)
                  }
                  className="btn-primary px-5 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Uploading…</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      <span>Upload</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Conversation panel */}
      <div className="card p-4 sm:p-5 h-[calc(100vh-22rem)] min-h-[320px] overflow-y-auto space-y-4">
        {messages.length === 0 && !historyLoading && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-12 h-12 rounded bg-accent/10 text-accent border border-accent/20 flex items-center justify-center mb-4">
              <Bot className="w-6 h-6" />
            </div>
            <h2 className="font-display text-lg font-semibold text-slate-900 mb-1">
              Knowledge base assistant
            </h2>
            <p className="text-sm text-slate-500 max-w-md">
              {knowledgeId
                ? "Ask me anything about this test's knowledge base."
                : 'Ask me anything about your tests and knowledge base.'}
            </p>
          </div>
        )}

        {messages.map((msg, index) => (
          <div
            key={index}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`flex items-start gap-3 max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded flex items-center justify-center flex-shrink-0 ${
                  msg.role === 'user' ? 'bg-accent/15 text-accent' : 'bg-raised text-slate-500'
                }`}
              >
                {msg.role === 'user' ? (
                  <User className="w-4 h-4" />
                ) : (
                  <Bot className="w-4 h-4" />
                )}
              </div>
              <div
                className={`px-4 py-3 rounded ${
                  msg.role === 'user'
                    ? 'bg-accent text-white'
                    : 'bg-raised border border-line text-slate-800'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="flex items-start gap-3 max-w-[80%]">
              <div className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0 bg-raised text-slate-500">
                <Bot className="w-4 h-4" />
              </div>
              <div className="px-4 py-3 rounded bg-raised border border-line">
                <Loader2 className="w-5 h-5 animate-spin text-accent" />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <div className="card mt-4 p-3 flex items-center gap-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          className="flex-1 bg-transparent outline-none text-slate-800 placeholder-slate-500 text-sm px-2"
          disabled={loading}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || loading}
          className="btn-primary w-10 h-10 p-0 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </AppShell>
  );
}

export default AiChat;
