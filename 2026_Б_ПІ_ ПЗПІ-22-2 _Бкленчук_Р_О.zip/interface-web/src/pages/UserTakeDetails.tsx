import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { testService } from '../services/testService';
import {
  BookOpen,
  CheckCircle,
  XCircle,
  AlertCircle,
  Hash,
} from 'lucide-react';

import type { TakeDetails, TakeQuestion } from '../lib/types';
import AppShell from '../components/layout/AppShell';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';
import Badge, { scoreBadge } from '../components/ui/Badge';

function UserTakeDetails() {
  const [takeDetails, setTakeDetails] = useState<TakeDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { takeId } = useParams();

  useEffect(() => {
    if (!takeId) return;
    const fetchTakeDetails = async () => {
      try {
        setLoading(true);
        const data = await testService.getUserTakeDetails(takeId);
        setTakeDetails(data);
      } catch (err) {
        console.error('Failed to fetch take details:', err);
        setError(err instanceof Error ? err.message : 'Failed to load take');
      } finally {
        setLoading(false);
      }
    };
    fetchTakeDetails();
  }, [takeId]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const isCorrectAnswer = (question: TakeQuestion, selectedAnswers: string[]) => {
    const correctAnswers =
      question.options?.filter((option) => option.correct).map((option) => option.id) || [];
    if (correctAnswers.length !== selectedAnswers.length) return false;
    return correctAnswers.every((id) => selectedAnswers.includes(id));
  };

  const getAnswerStatus = (question: TakeQuestion, selectedAnswers: string[]) => {
    if (selectedAnswers.length === 0) return 'skipped';
    return isCorrectAnswer(question, selectedAnswers) ? 'correct' : 'incorrect';
  };

  if (loading)
    return <Loading message="Loading take..." submessage="Fetching your results" />;

  if (error) return <ErrorState error={error} />;

  if (!takeDetails) return null;

  const score = Math.round((takeDetails.res_count / takeDetails.questions_amount) * 100);
  const correctAnswers = takeDetails.res_count;
  const incorrectAnswers =
    takeDetails.questions?.filter((q) => {
      const status = getAnswerStatus(q, q.selected_answers || []);
      return status === 'incorrect';
    }).length || 0;
  const skippedAnswers =
    takeDetails.questions?.filter((q) => {
      const status = getAnswerStatus(q, q.selected_answers || []);
      return status === 'skipped';
    }).length || 0;

  return (
    <AppShell
      title={takeDetails.title}
      subtitle={`Completed on ${formatDate(takeDetails.completed_at)}`}
      backTo={{ to: '/my-takes', label: 'My takes' }}
      maxWidth="max-w-4xl"
    >
      {/* Test Overview */}
      <div className="card p-6 sm:p-8 mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex-1">
            {takeDetails.description && (
              <p className="text-slate-500 mb-4">{takeDetails.description}</p>
            )}

            {/* Tags */}
            {takeDetails.tags && takeDetails.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {takeDetails.tags.map((tag) => (
                  <span key={tag} className="tag">
                    <Hash className="w-3 h-3 mr-1" />
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-center w-32 h-32 rounded bg-emerald-50 border border-emerald-100 text-center flex-shrink-0">
            <div>
              <div className="font-display text-4xl font-semibold text-emerald-600 tabular-nums">
                {score}%
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Final score
              </div>
              <div className="mt-2 flex justify-center">
                <Badge tone={scoreBadge(score).tone}>{scoreBadge(score).label}</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-8">
          <StatTile
            icon={BookOpen}
            tone="accent"
            value={takeDetails.questions_amount}
            label="Total questions"
          />
          <StatTile
            icon={CheckCircle}
            tone="emerald"
            value={correctAnswers}
            label="Correct"
          />
          <StatTile icon={XCircle} tone="red" value={incorrectAnswers} label="Incorrect" />
          <StatTile icon={AlertCircle} tone="slate" value={skippedAnswers} label="Skipped" />
        </div>
      </div>

      {/* Questions Review */}
      <div className="space-y-5">
        <h2 className="font-display text-sm font-semibold text-slate-500">
          Question review
        </h2>

        {takeDetails.questions?.map((question, index) => {
          const status = getAnswerStatus(question, question.selected_answers || []);

          return (
            <div key={question.id} className="card p-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded flex items-center justify-center text-sm font-semibold tabular-nums ${
                      status === 'correct'
                        ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                        : status === 'incorrect'
                          ? 'bg-red-50 text-red-600 border border-red-100'
                          : 'bg-raised text-slate-500 border border-line'
                    }`}
                  >
                    {index + 1}
                  </div>
                  <h3 className="font-display text-lg font-semibold text-slate-900">
                    Question {index + 1}
                  </h3>
                </div>

                {status === 'correct' && <Badge tone="pass">Correct</Badge>}
                {status === 'incorrect' && <Badge tone="fail">Incorrect</Badge>}
                {status === 'skipped' && <Badge tone="idle">Skipped</Badge>}
              </div>

              <div className="mb-6">
                <p className="text-slate-800 text-lg leading-relaxed">{question.question}</p>
              </div>

              <div className="space-y-3">
                {question.options?.map((option) => {
                  const isSelected = question.selected_answers?.includes(option.id);
                  const isCorrect = option.correct;

                  let optionClasses = 'p-4 rounded border transition-colors duration-200 ';
                  if (isSelected && isCorrect) {
                    optionClasses += 'bg-emerald-50 border-emerald-100 text-emerald-600';
                  } else if (isSelected && !isCorrect) {
                    optionClasses += 'bg-red-50 border-red-100 text-red-600';
                  } else if (!isSelected && isCorrect) {
                    optionClasses += 'bg-emerald-50 border-emerald-100 text-emerald-600';
                  } else {
                    optionClasses += 'bg-raised border-line text-slate-700';
                  }

                  return (
                    <div key={option.id} className={optionClasses}>
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                              isSelected ? 'border-current' : 'border-line-strong'
                            }`}
                          >
                            {isSelected && (
                              <div className="w-2.5 h-2.5 rounded-full bg-current"></div>
                            )}
                          </div>
                          <span className="font-medium">{option.text}</span>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          {isSelected && (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded border border-current/30 bg-current/10">
                              Your answer
                            </span>
                          )}
                          {isCorrect && (
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-600 border border-emerald-100">
                              Correct
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </AppShell>
  );
}

interface StatTileProps {
  icon: React.ComponentType<{ className?: string }>;
  tone: 'accent' | 'emerald' | 'red' | 'slate';
  value: number;
  label: string;
}

const TILE_TONE: Record<StatTileProps['tone'], string> = {
  accent: 'bg-accent/10 border-accent/20 text-accent',
  emerald: 'bg-emerald-50 border-emerald-100 text-emerald-600',
  red: 'bg-red-50 border-red-100 text-red-600',
  slate: 'bg-raised border-line text-slate-500',
};

function StatTile({ icon: Icon, tone, value, label }: StatTileProps) {
  return (
    <div className="bg-raised border border-line rounded p-4 text-center">
      <div
        className={`w-8 h-8 rounded-full border flex items-center justify-center mx-auto mb-2 ${TILE_TONE[tone]}`}
      >
        <Icon className="w-4 h-4" />
      </div>
      <div className="text-2xl font-semibold text-slate-900 tabular-nums">{value}</div>
      <div className="text-[11px] text-slate-500 mt-1">{label}</div>
    </div>
  );
}

export default UserTakeDetails;
