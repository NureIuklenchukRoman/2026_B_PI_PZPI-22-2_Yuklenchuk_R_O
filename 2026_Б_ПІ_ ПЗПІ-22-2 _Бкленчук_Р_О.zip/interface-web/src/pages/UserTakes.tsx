import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import type { ComponentType } from 'react';
import { testService } from '../services/testService';
import type { TakeSummary } from '../lib/types';
import { BookOpen, Trophy, CheckCircle, Star, ChevronRight } from 'lucide-react';
import Loading from '../components/Loading';
import ErrorState from '../components/ErrorState';
import FilterBar from '../components/FilterBar';
import Badge, { scoreBadge } from '../components/ui/Badge';
import AppShell from '../components/layout/AppShell';
import useTestFiltering from '../hooks/useTestFiltering';

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="card p-4 flex items-center gap-3">
      <div className="w-9 h-9 rounded-md bg-accent/10 border border-accent/20 text-accent flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4" />
      </div>
      <div className="min-w-0">
        <div className="text-xl font-semibold text-slate-900 leading-none tabular-nums">
          {value}
        </div>
        <div className="text-[11px] text-slate-500 mt-1">{label}</div>
      </div>
    </div>
  );
}

function UserTakes() {
  const navigate = useNavigate();
  const [userTakes, setUserTakes] = useState<TakeSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const {
    searchTerm,
    setSearchTerm,
    selectedTags,
    sortBy,
    setSortBy,
    availableTags,
    filteredItems: filteredTakes,
    toggleTag,
  } = useTestFiltering(userTakes, { defaultSort: 'newest' });

  useEffect(() => {
    const fetchUserTakes = async () => {
      try {
        setLoading(true);
        const data = await testService.getUserTakes();
        setUserTakes(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load takes');
      } finally {
        setLoading(false);
      }
    };

    fetchUserTakes();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleTakeClick = (takeId: string) => {
    navigate(`/my-takes/${takeId}`);
  };

  if (loading)
    return (
      <Loading message="Loading your test history..." submessage="Fetching your performance data" />
    );
  if (error) return <ErrorState error={error} />;

  const avgScore =
    userTakes.length > 0
      ? Math.round(
          userTakes.reduce(
            (acc, take) => acc + (take.res_count / take.questions_amount) * 100,
            0
          ) / userTakes.length
        )
      : null;
  const totalQuestions = userTakes.reduce((acc, take) => acc + take.questions_amount, 0);

  return (
    <AppShell
      title="My results"
      subtitle="Track your progress and review your performance."
      maxWidth="max-w-7xl"
    >
      {/* Stats */}
      {userTakes.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-8">
          <Stat icon={BookOpen} label="Tests taken" value={String(userTakes.length)} />
          <Stat
            icon={Star}
            label="Average score"
            value={avgScore === null ? '—' : `${avgScore}%`}
          />
          <Stat icon={CheckCircle} label="Total questions" value={String(totalQuestions)} />
        </div>
      )}

      {/* History */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-sm font-semibold text-slate-500">
          Your results
        </h2>
        <span className="text-xs text-slate-500">
          {filteredTakes.length}/{userTakes.length}
        </span>
      </div>

      <FilterBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        sortBy={sortBy}
        onSortChange={setSortBy}
        sortOptions={[
          { value: 'newest', label: 'Sort by Newest' },
          { value: 'oldest', label: 'Sort by Oldest' },
          { value: 'title', label: 'Sort by Title' },
        ]}
        availableTags={availableTags}
        selectedTags={selectedTags}
        onToggleTag={toggleTag}
        searchPlaceholder="Search your test history..."
      />

      {filteredTakes.length > 0 ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Test</th>
                  <th className="text-right w-24">Score</th>
                  <th className="w-28">Status</th>
                  <th className="hidden md:table-cell w-48">Completed</th>
                  <th className="w-8" />
                </tr>
              </thead>
              <tbody>
                {filteredTakes.map((take) => {
                  const pct = Math.round((take.res_count / take.questions_amount) * 100);
                  const status = scoreBadge(pct);
                  return (
                    <tr key={take.id} onClick={() => handleTakeClick(take.id)}>
                      <td>
                        <div className="font-medium text-slate-900">{take.title}</div>
                        {take.tags && take.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {take.tags.slice(0, 3).map((tag) => (
                              <span key={tag} className="tag">
                                {tag}
                              </span>
                            ))}
                            {take.tags.length > 3 && (
                              <span className="text-xs text-slate-500">
                                +{take.tags.length - 3}
                              </span>
                            )}
                          </div>
                        )}
                      </td>
                      <td className="text-right text-slate-700 tabular-nums">
                        <div>
                          {take.res_count}/{take.questions_amount}
                        </div>
                        <div className="text-xs text-slate-500">{pct}%</div>
                      </td>
                      <td>
                        <Badge {...status} />
                      </td>
                      <td className="hidden md:table-cell text-slate-500 tabular-nums text-xs">
                        {formatDate(take.completed_at)}
                      </td>
                      <td>
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card py-16 px-6 text-center">
          <Trophy className="w-6 h-6 text-slate-500 mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-slate-800 mb-1">
            {userTakes.length === 0 ? 'No tests taken yet' : 'No tests found'}
          </h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            {userTakes.length === 0
              ? 'Start taking some tests to see your history here.'
              : 'Adjust your search or filters to find specific tests.'}
          </p>
          {userTakes.length === 0 && (
            <button
              onClick={() => navigate('/home')}
              className="btn-primary mt-6 inline-flex items-center gap-2 px-4 py-2"
            >
              <BookOpen className="w-4 h-4" />
              <span>Browse tests</span>
            </button>
          )}
        </div>
      )}
    </AppShell>
  );
}

export default UserTakes;
