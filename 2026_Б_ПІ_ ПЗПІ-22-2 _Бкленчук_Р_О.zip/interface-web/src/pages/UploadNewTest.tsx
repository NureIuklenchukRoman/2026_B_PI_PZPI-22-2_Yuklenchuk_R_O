import { useEffect, useMemo, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { Database, FileText, Settings2, Upload, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import AppShell from '../components/layout/AppShell';
import EmailListInput from '../components/ui/EmailListInput';
import Badge, { jobStatusBadge } from '../components/ui/Badge';
import * as knowledge from '../lib/api/knowledge';
import type { ParseJob } from '../lib/api/knowledge';

const terminalStatuses = new Set(['completed', 'failed', 'canceled']);

export default function UploadNewTest() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'text' | 'media'>('text');
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [text, setText] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [allowedEmails, setAllowedEmails] = useState<string[]>([]);
  const [augmentData, setAugmentData] = useState(false);
  const [createTests, setCreateTests] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [jobs, setJobs] = useState<ParseJob[]>([]);

  const hasActiveJobs = useMemo(
    () => jobs.some((job) => !terminalStatuses.has(job.status)),
    [jobs]
  );

  useEffect(() => {
    let active = true;

    async function refreshJobs() {
      try {
        const nextJobs = await knowledge.listParseJobs();
        if (active) setJobs(nextJobs);
      } catch (err) {
        console.error('Failed to refresh parse jobs:', err);
      }
    }

    refreshJobs();
    const interval = window.setInterval(refreshJobs, hasActiveJobs ? 1000 : 8000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [hasActiveJobs]);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
    setMessage('');
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!title.trim()) {
      setMessage('Please add a title.');
      return;
    }
    if (isPrivate && allowedEmails.length === 0) {
      setMessage('For private tests, please add at least one allowed email.');
      return;
    }
    if (mode === 'text' && !text.trim()) {
      setMessage('Please paste text to process.');
      return;
    }
    if (mode === 'media' && !file) {
      setMessage('Please select a media file.');
      return;
    }
    if (!createTests && !augmentData) {
      setMessage('Please select at least one processing option (Create Test or Knowledge Base).');
      return;
    }

    setSubmitting(true);
    setMessage('');
    try {
      const common = {
        title: title.trim(),
        description,
        is_public: !isPrivate,
        allowed_emails: allowedEmails,
        augment_data: augmentData,
        create_tests: createTests,
      };
      const job =
        mode === 'text'
          ? await knowledge.createTextParseJob({ ...common, text })
          : await knowledge.createMediaParseJob({ ...common, file: file as File });
      setJobs((current) => [job, ...current.filter((item) => item.job_id !== job.job_id)]);
      setMessage('Processing started.');
      setText('');
      setFile(null);
    } catch (err) {
      console.error('Failed to create parse job:', err);
      setMessage(err instanceof Error ? err.message : 'Failed to start processing.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppShell
      title="Upload material"
      subtitle="Generate a test or knowledge base from text or media."
      backTo={{ to: '/home', label: 'Browse tests' }}
      maxWidth="max-w-3xl"
    >
      <section className="mb-8">
        <div className="flex items-center justify-between gap-4 mb-3">
          <h2 className="font-display text-sm font-semibold text-slate-500">
            Source material
          </h2>
          <div className="inline-flex rounded border border-line bg-surface p-0.5">
            <button
              type="button"
              onClick={() => setMode('text')}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded text-sm font-medium transition-colors ${
                mode === 'text' ? 'bg-accent text-white' : 'text-slate-500 hover:bg-raised'
              }`}
            >
              <FileText className="w-4 h-4" />
              Text
            </button>
            <button
              type="button"
              onClick={() => setMode('media')}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded text-sm font-medium transition-colors ${
                mode === 'media' ? 'bg-accent text-white' : 'text-slate-500 hover:bg-raised'
              }`}
            >
              <Video className="w-4 h-4" />
              Media
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="card p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
            <label className="block">
              <span className="label mb-2">Title</span>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="input w-full p-3"
              />
            </label>
            <label className="flex items-end">
              <span className="inline-flex items-center gap-3 p-3 rounded border border-line bg-raised cursor-pointer w-full lg:w-auto">
                <input
                  type="checkbox"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded"
                />
                <span className="text-sm font-medium text-slate-800">Make this test private</span>
              </span>
            </label>
          </div>

          <label className="block mb-5">
            <span className="label mb-2">Description</span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="input w-full h-24 p-3 resize-y"
            />
          </label>

          {isPrivate && (
            <div className="mb-5">
              <label className="label mb-2">Allowed Emails</label>
              <EmailListInput value={allowedEmails} onChange={setAllowedEmails} />
            </div>
          )}

          <div className="mb-8 p-4 bg-raised border border-line rounded">
            <h3 className="text-sm font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-accent" />
              Processing Options
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 p-3 bg-surface border border-line rounded cursor-pointer hover:bg-raised transition-colors">
                <input
                  type="checkbox"
                  checked={createTests}
                  onChange={(e) => setCreateTests(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded"
                />
                <div>
                  <span className="block text-sm font-medium text-slate-800">Create Test</span>
                  <span className="block text-xs text-slate-500">Generate questions from source</span>
                </div>
              </label>
              <label className="flex items-center gap-3 p-3 bg-surface border border-line rounded cursor-pointer hover:bg-raised transition-colors">
                <input
                  type="checkbox"
                  checked={augmentData}
                  onChange={(e) => setAugmentData(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded"
                />
                <div>
                  <span className="flex items-center gap-1.5 text-sm font-medium text-slate-800">
                    <Database className="w-3.5 h-3.5 text-accent" />
                    Knowledge Base
                  </span>
                  <span className="block text-xs text-slate-500">Enable AI-powered Q&amp;A</span>
                </div>
              </label>
            </div>
            {!createTests && !augmentData && (
              <p className="mt-3 text-sm text-red-600 font-medium">
                Please select at least one processing option.
              </p>
            )}
          </div>

          {mode === 'text' ? (
            <label className="block mb-5">
              <span className="label mb-2">Source Text</span>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="input w-full min-h-80 p-4 text-sm resize-y"
              />
            </label>
          ) : (
            <label className="block mb-5">
              <span className="label mb-2">Media File</span>
              <input
                type="file"
                accept="audio/*,video/*"
                onChange={handleFileChange}
                className="input w-full p-3"
              />
            </label>
          )}

          <button
            type="submit"
            disabled={submitting || (!createTests && !augmentData)}
            className={`btn-primary px-6 py-3 ${
              submitting || (!createTests && !augmentData)
                ? 'opacity-50 cursor-not-allowed'
                : ''
            }`}
          >
            <Upload className="w-4 h-4" />
            {submitting ? 'Starting…' : 'Start processing'}
          </button>
        </form>
      </section>

      {jobs.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display text-sm font-semibold text-slate-500">
              Processing queue
            </h2>
            <span className="text-xs text-slate-500 tabular-nums">{jobs.length}</span>
          </div>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead>
                  <tr>
                    <th className="w-28">Source</th>
                    <th>Stage / Message</th>
                    <th className="w-48">Progress</th>
                    <th className="w-32">Status</th>
                    <th className="w-28" />
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((job) => {
                    const percent =
                      job.total_chunks > 0
                        ? Math.min(100, Math.round((job.completed_chunks / job.total_chunks) * 100))
                        : job.status === 'completed'
                          ? 100
                          : 8;

                    const badge = jobStatusBadge(job.status);

                    return (
                      <tr key={job.job_id}>
                        <td>
                          <span className="text-xs text-slate-700">
                            {job.source_type.charAt(0).toUpperCase() + job.source_type.slice(1).replace('_', ' ')}
                          </span>
                        </td>
                        <td>
                          <div className="text-sm text-slate-800">{job.message || job.stage}</div>
                          <div className="text-xs text-slate-500 mt-0.5">
                            Stage: <span className="font-mono">{job.stage}</span>
                          </div>
                          {job.error_message && (
                            <div className="text-xs text-red-600 mt-1">
                              {job.error_message}
                            </div>
                          )}
                        </td>
                        <td>
                          <div className="text-xs tabular-nums text-slate-500 mb-1.5">
                            {job.total_chunks > 0
                              ? `${job.completed_chunks}/${job.total_chunks} chunks${
                                  job.failed_chunks ? ` · ${job.failed_chunks} failed` : ''
                                }`
                              : `${percent}%`}
                          </div>
                          <div className="h-1 bg-raised rounded-full overflow-hidden">
                            <div
                              className="h-full bg-accent"
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </td>
                        <td>
                          <Badge {...badge} dot />
                        </td>
                        <td className="text-right">
                          {/* Only the test-generation job opens a test; knowledge-base
                              jobs carry a test_id too but produce no test to open. */}
                          {job.status === 'completed' &&
                            job.test_id &&
                            job.source_type !== 'knowledge_base' && (
                              <button
                                type="button"
                                onClick={() => navigate(`/tests/${job.test_id}/edit`)}
                                className="btn-secondary px-3 py-1.5 text-sm"
                              >
                                Open test
                              </button>
                            )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {message && (
        <div className="fixed top-20 right-4 z-50">
          <div
            className={`p-3 rounded border text-sm font-medium ${
              message.includes('started')
                ? 'bg-emerald-50 border-emerald-100 text-emerald-600'
                : 'bg-red-50 border-red-100 text-red-600'
            }`}
          >
            {message}
          </div>
        </div>
      )}
    </AppShell>
  );
}
