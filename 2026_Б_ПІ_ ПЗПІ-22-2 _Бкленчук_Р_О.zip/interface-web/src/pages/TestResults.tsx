import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, XCircle, Clock } from 'lucide-react';
import { testService } from '../services/testService';
import AppShell from '../components/layout/AppShell';
import Badge from '../components/ui/Badge';

/** Shape this page renders. The backend doesn't expose a results
 * endpoint matching this shape (audit C10) — the testService.getTestResults
 * method doesn't exist and the call below throws every time. We keep the
 * type for future when the endpoint lands; for now the page surfaces
 * "Error: testService.getTestResults is not a function". */
interface TestResultsData {
  score: number;
  correct_answers: number;
  incorrect_answers: number;
  time_taken: string;
  question_breakdown: Array<{
    question_id: string;
    question: string;
    user_answer: string;
    correct_answer: string;
    is_correct: boolean;
    time_taken: number;
  }>;
}

/** Circular score gauge. Amber arc on a dark track, score in the centre. */
function ScoreRing({ score }: { score: number }) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(Math.max(score, 0), 100) / 100) * circumference;
  return (
    <div className="relative w-32 h-32 flex-shrink-0">
      <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r={radius} fill="none" stroke="#e6e8ec" strokeWidth="10" />
        <circle
          cx="60"
          cy="60"
          r={radius}
          fill="none"
          stroke="#2563eb"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display tabular-nums text-3xl font-semibold text-slate-900">
          {score}%
        </span>
        <span className="text-xs text-slate-500">score</span>
      </div>
    </div>
  );
}

export default function TestResults() {
  const { testId } = useParams();
  const [results, setResults] = useState<TestResultsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchResults = async () => {
      try {
        setLoading(true);
        // testService.getTestResults doesn't exist (audit C10); cast
        // until a real endpoint lands.
        const svc = testService as unknown as {
          getTestResults: (id: string | undefined) => Promise<TestResultsData>;
        };
        const data = await svc.getTestResults(testId);
        setResults(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load results');
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [testId]);

  if (loading)
    return (
      <div className="min-h-screen bg-base flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-line border-t-accent"></div>
      </div>
    );

  if (error)
    return (
      <AppShell title="Test results" backTo={{ to: '/home', label: 'Browse tests' }}>
        <div className="card p-8 text-center">
          <div className="w-12 h-12 bg-red-50 border border-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-6 h-6 text-red-600" />
          </div>
          <h3 className="font-display text-xl font-semibold text-slate-900 mb-1">
            Couldn’t load results
          </h3>
          <p className="text-sm text-slate-500">{error}</p>
        </div>
      </AppShell>
    );

  if (!results) return null;

  const total = results.correct_answers + results.incorrect_answers;

  return (
    <AppShell
      title="Test results"
      subtitle="Here’s how you did — review every question below."
      backTo={{ to: '/home', label: 'Browse tests' }}
      maxWidth="max-w-4xl"
    >
      {/* Summary */}
      <div className="card p-6 sm:p-8 mb-6">
        <div className="flex flex-col sm:flex-row items-center gap-8">
          <ScoreRing score={results.score} />
          <div className="grid grid-cols-3 gap-4 flex-1 w-full">
            <div className="text-center sm:text-left">
              <div className="flex items-center gap-1.5 text-emerald-600 mb-1">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-sm font-medium">Correct</span>
              </div>
              <div className="font-display tabular-nums text-2xl font-semibold text-slate-900">
                {results.correct_answers}
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="flex items-center gap-1.5 text-red-600 mb-1">
                <XCircle className="w-4 h-4" />
                <span className="text-sm font-medium">Incorrect</span>
              </div>
              <div className="font-display tabular-nums text-2xl font-semibold text-slate-900">
                {results.incorrect_answers}
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="flex items-center gap-1.5 text-slate-500 mb-1">
                <Clock className="w-4 h-4" />
                <span className="text-sm font-medium">Time</span>
              </div>
              <div className="font-display tabular-nums text-2xl font-semibold text-slate-900">
                {results.time_taken}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Question breakdown */}
      <h2 className="font-display text-xl font-semibold text-slate-900 mb-4">Question breakdown</h2>
      <div className="space-y-4">
        {results.question_breakdown.map((item, index) => (
          <div key={item.question_id} className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {item.is_correct ? (
                  <Badge tone="pass">Correct</Badge>
                ) : (
                  <Badge tone="fail">Incorrect</Badge>
                )}
                <span className="text-sm font-medium text-slate-500">
                  <span className="tabular-nums">
                    Question {index + 1} of {total}
                  </span>
                </span>
              </div>
              <span className="text-xs text-slate-500 tabular-nums">
                {item.time_taken}s
              </span>
            </div>
            <p className="text-slate-800 font-medium mb-4">{item.question}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="rounded bg-raised px-3 py-2">
                <div className="text-xs text-slate-500 mb-0.5">Your answer</div>
                <div
                  className={`text-sm font-medium ${
                    item.is_correct ? 'text-emerald-600' : 'text-red-600'
                  }`}
                >
                  {item.user_answer}
                </div>
              </div>
              {!item.is_correct && (
                <div className="rounded bg-emerald-50 border border-emerald-100 px-3 py-2">
                  <div className="text-xs text-slate-500 mb-0.5">Correct answer</div>
                  <div className="text-sm font-medium text-emerald-600">{item.correct_answer}</div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
