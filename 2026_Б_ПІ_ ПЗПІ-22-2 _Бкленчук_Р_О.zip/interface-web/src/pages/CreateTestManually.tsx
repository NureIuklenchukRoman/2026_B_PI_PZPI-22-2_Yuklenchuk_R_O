import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, Save, BookOpen, HelpCircle, CheckCircle, Lock, Unlock } from 'lucide-react';
import AppShell from '../components/layout/AppShell';
import EmailListInput from '../components/ui/EmailListInput';
import TagInput from '../components/ui/TagInput';
import { testService } from '../services/testService';

interface DraftOption {
  text: string;
  correct: boolean;
}
interface DraftQuestion {
  question: string;
  options: DraftOption[];
  tags: string[];
}
interface DraftTest {
  title: string;
  description: string;
  is_public: boolean;
  allowed_emails: string[];
  tags: string[];
  questions: DraftQuestion[];
}
type Message = { type: '' | 'success' | 'error'; text: string };

export default function CreateTestManually() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<Message>({ type: '', text: '' });

  const [testData, setTestData] = useState<DraftTest>({
    title: '',
    description: '',
    is_public: true,
    allowed_emails: [],
    tags: [],
    questions: [
      {
        question: '',
        options: [
          { text: '', correct: false },
          { text: '', correct: false },
        ],
        tags: [],
      },
    ],
  });

  const handleAddQuestion = () => {
    setTestData({
      ...testData,
      questions: [
        ...testData.questions,
        {
          question: '',
          options: [
            { text: '', correct: false },
            { text: '', correct: false },
          ],
          tags: [],
        },
      ],
    });
  };

  const handleRemoveQuestion = (index: number) => {
    const newQuestions = testData.questions.filter((_, i) => i !== index);
    setTestData({ ...testData, questions: newQuestions });
  };

  const handleQuestionChange = (index: number, value: string) => {
    const newQuestions = [...testData.questions];
    newQuestions[index].question = value;
    setTestData({ ...testData, questions: newQuestions });
  };

  const handleAddOption = (questionIndex: number) => {
    const newQuestions = [...testData.questions];
    newQuestions[questionIndex].options.push({ text: '', correct: false });
    setTestData({ ...testData, questions: newQuestions });
  };

  const handleRemoveOption = (questionIndex: number, optionIndex: number) => {
    const newQuestions = [...testData.questions];
    newQuestions[questionIndex].options = newQuestions[questionIndex].options.filter(
      (_, i) => i !== optionIndex
    );
    setTestData({ ...testData, questions: newQuestions });
  };

  const handleOptionChange = <K extends keyof DraftOption>(
    questionIndex: number,
    optionIndex: number,
    field: K,
    value: DraftOption[K]
  ) => {
    const newQuestions = [...testData.questions];
    newQuestions[questionIndex].options[optionIndex][field] = value;
    setTestData({ ...testData, questions: newQuestions });
  };

  const setTestTags = (tags: string[]) => setTestData({ ...testData, tags });

  const setQuestionTags = (questionIndex: number, tags: string[]) => {
    const newQuestions = [...testData.questions];
    newQuestions[questionIndex] = { ...newQuestions[questionIndex], tags };
    setTestData({ ...testData, questions: newQuestions });
  };

  const validateForm = () => {
    if (!testData.title.trim()) {
      setMessage({ type: 'error', text: 'Please enter a test title' });
      return false;
    }

    if (testData.questions.length === 0) {
      setMessage({ type: 'error', text: 'Please add at least one question' });
      return false;
    }

    for (let i = 0; i < testData.questions.length; i++) {
      const q = testData.questions[i];

      if (!q.question.trim()) {
        setMessage({ type: 'error', text: `Question ${i + 1} is empty` });
        return false;
      }

      if (q.options.length < 2) {
        setMessage({ type: 'error', text: `Question ${i + 1} needs at least 2 options` });
        return false;
      }

      const hasEmptyOption = q.options.some((opt) => !opt.text.trim());
      if (hasEmptyOption) {
        setMessage({ type: 'error', text: `Question ${i + 1} has empty options` });
        return false;
      }

      const hasCorrectAnswer = q.options.some((opt) => opt.correct);
      if (!hasCorrectAnswer) {
        setMessage({ type: 'error', text: `Question ${i + 1} needs a correct answer` });
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      await testService.createTestManually(testData);
      setMessage({ type: 'success', text: 'Test created successfully!' });

      // Redirect after success
      setTimeout(() => {
        navigate('/home');
      }, 2000);
    } catch (error) {
      const detail = error instanceof Error ? error.message : 'Failed to create test';
      setMessage({ type: 'error', text: detail });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppShell
      title="Create a test"
      subtitle="Build a test by hand, question by question."
      backTo={{ to: '/home', label: 'Browse tests' }}
      maxWidth="max-w-3xl"
    >
      {/* Test Info */}
      <div className="card p-6 sm:p-8 mb-6">
        <h2 className="font-display text-xl font-semibold text-slate-900 mb-6 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-accent" />
          Test information
        </h2>

          <div className="space-y-4">
            <div>
              <label className="label mb-2">
                Test Title <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={testData.title}
                onChange={(e) => setTestData({ ...testData, title: e.target.value })}
                placeholder="Enter test title..."
                className="input w-full p-3"
              />
            </div>

            <div>
              <label className="label mb-2">Description</label>
              <textarea
                value={testData.description}
                onChange={(e) => setTestData({ ...testData, description: e.target.value })}
                placeholder="Enter test description..."
                rows={3}
                className="input w-full p-3"
              />
            </div>

            <div className="flex items-center gap-3 p-4 rounded bg-raised border border-line">
              {testData.is_public ? (
                <Unlock className="w-5 h-5 text-emerald-600 flex-shrink-0" />
              ) : (
                <Lock className="w-5 h-5 text-accent flex-shrink-0" />
              )}
              <input
                type="checkbox"
                id="is_public"
                checked={!testData.is_public}
                onChange={(e) => setTestData({ ...testData, is_public: !e.target.checked })}
                className="w-5 h-5 accent-accent rounded"
              />
              <label
                htmlFor="is_public"
                className="flex-1 text-sm font-medium text-slate-700 cursor-pointer select-none"
              >
                {testData.is_public
                  ? '🌐 Public test (anyone can view and take it)'
                  : '🔒 Private test (only you can view and take it)'}
              </label>
            </div>

            {!testData.is_public && (
              <div>
                <label className="label mb-2">
                  Allowed Emails
                </label>
                <p className="text-xs text-slate-500 mb-2">
                  Only these emails will be able to access this test. Press Enter to add.
                </p>
                <EmailListInput
                  value={testData.allowed_emails}
                  onChange={(allowed_emails) => setTestData({ ...testData, allowed_emails })}
                />
              </div>
            )}

            <div>
              <label className="label mb-2">Tags</label>
              <TagInput
                value={testData.tags}
                onChange={setTestTags}
                placeholder="Add tag..."
                showAddButton
              />
            </div>
          </div>
        </div>

        {/* Questions */}
        {testData.questions.map((question, qIndex) => (
          <div
            key={qIndex}
            className="card p-6 sm:p-8 mb-6"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-display text-xl font-semibold text-slate-900 flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-accent" />
                Question {qIndex + 1}
              </h2>
              {testData.questions.length > 1 && (
                <button
                  onClick={() => handleRemoveQuestion(qIndex)}
                  className="btn-ghost p-2 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label className="label mb-2">
                  Question Text <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  value={question.question}
                  onChange={(e) => handleQuestionChange(qIndex, e.target.value)}
                  placeholder="Enter your question..."
                  className="input w-full p-3"
                />
              </div>

              <div>
                <label className="label mb-2">
                  Question Tags
                </label>
                <TagInput
                  value={question.tags}
                  onChange={(tags) => setQuestionTags(qIndex, tags)}
                  placeholder="Add tag..."
                  showAddButton
                />
              </div>

              <div>
                <label className="label mb-2">
                  Options <span className="text-red-600">*</span>
                </label>
                <div className="space-y-2">
                  {question.options.map((option, oIndex) => (
                    <div key={oIndex} className="flex gap-2 items-center">
                      <input
                        type="checkbox"
                        checked={option.correct}
                        onChange={(e) =>
                          handleOptionChange(qIndex, oIndex, 'correct', e.target.checked)
                        }
                        className="w-5 h-5 accent-emerald-500 rounded flex-shrink-0"
                      />
                      <input
                        type="text"
                        value={option.text}
                        onChange={(e) => handleOptionChange(qIndex, oIndex, 'text', e.target.value)}
                        placeholder={`Option ${oIndex + 1}...`}
                        className="input flex-1 p-3"
                      />
                      {question.options.length > 2 && (
                        <button
                          onClick={() => handleRemoveOption(qIndex, oIndex)}
                          className="btn-ghost p-2 text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                      {option.correct && (
                        <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => handleAddOption(qIndex)}
                  className="mt-2 px-4 py-2 text-sm text-accent border border-dashed border-line hover:border-accent rounded transition-colors"
                >
                  + Add option
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Add Question Button */}
        <button
          onClick={handleAddQuestion}
          className="w-full mb-6 px-6 py-4 rounded text-accent font-medium border border-dashed border-line hover:border-accent transition-colors flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add another question
        </button>

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={loading}
          className={`btn-primary w-full px-6 py-4 ${
            loading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          {loading ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-5 h-5 border-2 border-base border-t-transparent rounded-full animate-spin"></div>
              <span>Creating test...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-2">
              <Save className="w-5 h-5" />
              <span>Create test</span>
            </div>
          )}
        </button>

        {/* Message Display */}
        {message.text && (
          <div
            className={`mt-6 p-4 rounded border text-sm ${
              message.type === 'success'
                ? 'bg-emerald-50 text-emerald-600 border-emerald-100'
                : 'bg-red-50 text-red-600 border-red-100'
            }`}
          >
            {message.text}
          </div>
        )}
    </AppShell>
  );
}
