import { useState } from 'react';
import type { FormEvent } from 'react';
import { BookOpen, Mail, Lock, LogIn, UserPlus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import * as auth from '../lib/api/auth';
import { useAuth } from '../lib/auth/AuthContext';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { refresh } = useAuth();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      await auth.login(email, password);
      // Auth state lives in the httponly access_token cookie set by the
      // backend; refresh AuthContext from /users/me before navigating
      // so RequireAuth doesn't bounce us back to '/' on the stale
      // pre-login 'anonymous' status.
      await refresh();
      navigate('/home');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base">
      {/* Header */}
      <header className="bg-surface border-b border-line">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm shadow-blue-500/30">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <h1 className="font-display text-2xl font-semibold text-slate-900">Testify</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex items-center justify-center min-h-[calc(100vh-73px)] px-4 sm:px-6 lg:px-8 py-12">
        <div className="w-full max-w-md">
          {/* Welcome Section */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-accent/10 text-accent border border-accent/20 rounded flex items-center justify-center mx-auto mb-6">
              <LogIn className="w-8 h-8" />
            </div>
            <h2 className="font-display text-3xl font-semibold text-slate-900 mb-2">Welcome back</h2>
            <p className="text-slate-500">Sign in to continue your learning journey</p>
          </div>

          {/* Login Form */}
          <div className="card p-8">
            <div className="space-y-6">
              {error && (
                <div className="bg-red-50 border border-red-100 text-red-600 rounded p-3">
                  <p className="text-sm">{error}</p>
                </div>
              )}

              <div>
                <label className="label">
                  Email address
                </label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-4 top-1/2 z-10 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input pl-12 pr-4 py-3"
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <label className="label">Password</label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-4 top-1/2 z-10 transform -translate-y-1/2 text-slate-500 w-5 h-5" />
                  <input
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input pl-12 pr-4 py-3"
                    disabled={loading}
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="btn-primary w-full py-3 px-6 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-base border-t-transparent rounded-full animate-spin"></div>
                    <span>Signing in...</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5" />
                    <span>Sign in</span>
                  </>
                )}
              </button>
            </div>

            {/* Register Link */}
            <div className="mt-8 pt-6 border-t border-line">
              <div className="text-center">
                <p className="text-slate-500 mb-4">Don't have an account?</p>
                <a
                  href="/register"
                  className="inline-flex items-center gap-2 text-accent hover:text-accent/80 font-medium transition-colors"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Create account</span>
                </a>
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="text-center mt-8">
            <p className="text-xs text-slate-500">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}

export default Login;
