import { BrowserRouter, Routes, Route } from 'react-router-dom';
import type { ReactNode } from 'react';

import { AuthProvider } from './lib/auth/AuthContext';
import RequireAuth from './lib/auth/RequireAuth';
import Login from './pages/Login';
import Register from './pages/Register';
import Home from './pages/Home';
import TestEdit from './pages/TestEdit';
import TestTaking from './pages/TestTaking';
import TestResults from './pages/TestResults';
import UserTakes from './pages/UserTakes';
import UserTakeDetails from './pages/UserTakeDetails';
import UserTests from './pages/UserTests';
import UploadNewTest from './pages/UploadNewTest';
import CreateTestManually from './pages/CreateTestManually';
import AiChat from './pages/AiChat';
import Profile from './pages/Profile';

const protect = (element: ReactNode) => <RequireAuth>{element}</RequireAuth>;

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/home" element={protect(<Home />)} />
          <Route path="/tests/:testId/edit" element={protect(<TestEdit />)} />
          <Route path="/tests/:testId" element={protect(<TestTaking />)} />
          <Route path="/results" element={protect(<TestResults />)} />
          <Route path="/my-takes" element={protect(<UserTakes />)} />
          <Route path="/my-takes/:takeId" element={protect(<UserTakeDetails />)} />
          <Route path="/my-tests/" element={protect(<UserTests />)} />
          <Route path="/upload-new-test" element={protect(<UploadNewTest />)} />
          <Route path="/create-test-manually" element={protect(<CreateTestManually />)} />
          <Route path="/chat" element={protect(<AiChat />)} />
          <Route path="/profile" element={protect(<Profile />)} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
