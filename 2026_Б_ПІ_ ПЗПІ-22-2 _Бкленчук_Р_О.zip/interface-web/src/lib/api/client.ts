/** Thin wrapper around fetch that:
 *   - prepends API_BASE_URL
 *   - sends credentials so the auth cookie travels
 *   - parses JSON / handles 204 / surfaces FastAPI's {detail} on error
 *   - silently rotates the access cookie via /auth/refresh on a single
 *     401 and replays the request once
 *
 * The backend reads the access_token httponly cookie automatically;
 * the only "auth logic" here is the refresh-and-retry on 401.
 */

import { API_BASE_URL } from '../../config';

export class ApiError extends Error {
  status: number;
  constructor(status: number, detail: string) {
    super(detail);
    this.status = status;
    this.name = 'ApiError';
  }
}

interface ApiFetchOptions extends Omit<RequestInit, 'body'> {
  body?: BodyInit | null;
}

/** Module-level so concurrent requests share a single refresh attempt
 * instead of each firing their own /auth/refresh. */
let inflightRefresh: Promise<boolean> | null = null;

function attemptRefresh(): Promise<boolean> {
  if (!inflightRefresh) {
    inflightRefresh = fetch(`${API_BASE_URL}/auth/refresh`, {
      method: 'POST',
      credentials: 'include',
    })
      .then((r) => r.ok)
      .catch(() => false)
      .finally(() => {
        inflightRefresh = null;
      });
  }
  return inflightRefresh;
}

async function rawFetch(path: string, options: ApiFetchOptions): Promise<Response> {
  const { headers, ...rest } = options;
  return fetch(`${API_BASE_URL}${path}`, {
    credentials: 'include',
    ...rest,
    headers: {
      ...(headers as Record<string, string> | undefined),
    },
  });
}

export async function apiFetch<T = unknown>(
  path: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  let response = await rawFetch(path, options);

  // 401 from any non-auth endpoint means the access cookie likely
  // expired. Try to mint a new one from the refresh cookie and replay
  // the request once. Auth endpoints (/auth/refresh, /auth/login, …)
  // are excluded so we don't loop and don't pretend a bad password is
  // a session-expiry issue.
  if (response.status === 401 && !path.startsWith('/auth/')) {
    const refreshed = await attemptRefresh();
    if (refreshed) {
      response = await rawFetch(path, options);
    }
  }

  if (!response.ok) {
    let detail = `Request failed: ${response.status}`;
    try {
      const errorBody = (await response.json()) as { detail?: string };
      if (errorBody?.detail) detail = errorBody.detail;
    } catch {
      /* response body wasn't JSON; keep the generic detail */
    }
    throw new ApiError(response.status, detail);
  }

  if (response.status === 204 || response.headers.get('content-length') === '0') {
    return undefined as T;
  }
  return (await response.json()) as T;
}

/** Helper for JSON POST/PUT bodies. */
export async function apiJson<T = unknown>(
  path: string,
  method: 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  body: unknown
): Promise<T> {
  return apiFetch<T>(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}
