import { apiFetch, apiJson } from './client';

interface AskKnowledgeResponse {
  answer: string;
}

export async function askKnowledge(
  message: string,
  knowledgeId?: string | null
): Promise<AskKnowledgeResponse> {
  const body: { message: string; knowledge_id?: string } = { message };
  if (knowledgeId) body.knowledge_id = knowledgeId;
  return apiJson<AskKnowledgeResponse>('/ask-knowledge', 'POST', body);
}

export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
  created_at?: string | null;
}

interface ConversationResponse {
  knowledge_id: string;
  messages: ConversationMessage[];
}

/** Load the saved chat history for a knowledge context (per user, per chat). */
export async function getConversation(
  knowledgeId?: string | null
): Promise<ConversationMessage[]> {
  const params = new URLSearchParams();
  if (knowledgeId) params.set('knowledge_id', knowledgeId);
  const qs = params.toString();
  const res = await apiFetch<ConversationResponse>(`/conversations${qs ? `?${qs}` : ''}`);
  return res.messages ?? [];
}

interface ProcessKnowledgeBaseResult {
  message?: string;
  knowledge_id?: string;
}

export async function processTestKnowledgeBase(
  testId: string,
  text: string,
  augmentData = true
): Promise<ProcessKnowledgeBaseResult> {
  return apiJson<ProcessKnowledgeBaseResult>('/process', 'POST', {
    test_id: String(testId),
    text,
    augment_data: augmentData,
    create_tests: false,
    window: 5,
    model: 'poolside/laguna-xs.2:free',
  });
}

/** Admin-only: enqueue a text job into the global knowledge pool.
 *  Returns the durable parse-job so the caller can poll its status. */
export async function createGlobalTextJob(text: string): Promise<ParseJob> {
  return apiJson<ParseJob>('/parse-jobs/admin/global/text', 'POST', { text });
}

/** Admin-only: upload an audio/video file for global ingest. Returns
 *  the durable parse-job so the caller can poll its status. */
export async function createGlobalMediaJob(file: File): Promise<ParseJob> {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch('/parse-jobs/admin/global/media', {
    method: 'POST',
    body: formData,
    credentials: 'include',
  });
  if (!res.ok) {
    const errorBody = (await res.json().catch(() => ({}))) as { detail?: string };
    throw new Error(errorBody.detail ?? `Global media job failed (${res.status})`);
  }
  return (await res.json()) as ParseJob;
}

export interface ParseJob {
  job_id: string;
  source_type: string;
  status: 'queued' | 'uploading' | 'processing' | 'completed' | 'failed' | 'canceled';
  stage: string;
  total_chunks: number;
  completed_chunks: number;
  failed_chunks: number;
  message?: string | null;
  error_message?: string | null;
  test_id?: string | null;
  created_at: string;
  updated_at: string;
}

export async function createTextParseJob(payload: {
  title: string;
  description?: string;
  text: string;
  is_public: boolean;
  allowed_emails: string[];
  augment_data?: boolean;
  create_tests?: boolean;
}): Promise<ParseJob> {
  return apiJson<ParseJob>('/parse-jobs/text', 'POST', {
    title: payload.title,
    description: payload.description ?? '',
    text: payload.text,
    is_public: payload.is_public,
    allowed_emails: payload.allowed_emails,
    augment_data: payload.augment_data ?? false,
    create_tests: payload.create_tests ?? true,
    window: 5,
    model: 'poolside/laguna-xs.2:free',
  });
}

export async function createMediaParseJob(payload: {
  title: string;
  description?: string;
  file: File;
  is_public: boolean;
  allowed_emails: string[];
  augment_data?: boolean;
  create_tests?: boolean;
}): Promise<ParseJob> {
  const formData = new FormData();
  formData.append('title', payload.title);
  formData.append('description', payload.description ?? '');
  formData.append('is_public', String(payload.is_public));
  formData.append('allowed_emails', JSON.stringify(payload.allowed_emails));
  formData.append('augment_data', String(payload.augment_data ?? false));
  formData.append('create_tests', String(payload.create_tests ?? true));
  formData.append('file', payload.file);
  const res = await fetch('/parse-jobs/media', {
    method: 'POST',
    body: formData,
    credentials: 'include',
  });
  if (!res.ok) {
    const errorBody = (await res.json().catch(() => ({}))) as { detail?: string };
    throw new Error(errorBody.detail ?? `Media job failed (${res.status})`);
  }
  return (await res.json()) as ParseJob;
}

export async function listParseJobs(): Promise<ParseJob[]> {
  return apiFetch<ParseJob[]>('/parse-jobs/');
}

export async function getParseJob(jobId: string): Promise<ParseJob> {
  return apiFetch<ParseJob>(`/parse-jobs/${jobId}`);
}
