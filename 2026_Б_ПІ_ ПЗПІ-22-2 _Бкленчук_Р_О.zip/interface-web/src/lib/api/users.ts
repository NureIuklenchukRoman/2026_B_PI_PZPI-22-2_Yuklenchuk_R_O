import type { AuthUser, TakeDetails, TakeSummary, TestSummary } from '../types';
import { apiFetch, apiJson } from './client';

export interface UpdateMePayload {
  email: string;
  username: string;
}

export async function getMe(): Promise<AuthUser> {
  return apiFetch<AuthUser>('/users/me');
}

export async function updateMe(payload: UpdateMePayload): Promise<AuthUser> {
  return apiJson<AuthUser>('/users/me', 'PUT', payload);
}

export async function getMyTakes(): Promise<TakeSummary[]> {
  return apiFetch<TakeSummary[]>('/users/my-takes');
}

export async function getMyTakeDetails(takeId: string): Promise<TakeDetails> {
  return apiFetch<TakeDetails>(`/users/my-takes/${takeId}`);
}

export async function getMyTests(): Promise<TestSummary[]> {
  return apiFetch<TestSummary[]>('/users/my-tests');
}
