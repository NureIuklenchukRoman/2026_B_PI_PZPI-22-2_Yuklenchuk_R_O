import type {
  CreateTestManuallyPayload,
  EditTestPayload,
  Question,
  QuestionPayload,
  SubmitAnswerResult,
  TestInfo,
  TestInfoForEdit,
  TestSummary,
} from '../types';
import { apiFetch, apiJson } from './client';

export type TestSort = 'title' | 'questions' | 'newest' | 'oldest';

export interface TestListParams {
  page?: number;
  pageSize?: number;
  tags?: string[];
  /** Free-text search; matched server-side against title/description/tags. */
  q?: string;
  /** Server-side ordering. */
  sort?: TestSort;
}

export async function listTests({
  page = 1,
  pageSize = 10,
  tags = [],
  q = '',
  sort,
}: TestListParams = {}): Promise<TestSummary[]> {
  const params = new URLSearchParams({
    page: String(page),
    page_size: String(pageSize),
  });
  if (tags.length) params.set('tags', tags.join(','));
  if (q.trim()) params.set('q', q.trim());
  if (sort) params.set('sort', sort);
  return apiFetch<TestSummary[]>(`/tests?${params}`);
}

/** Distinct tags across the accessible catalog (powers the filter chips). */
export async function listTestTags(): Promise<string[]> {
  return apiFetch<string[]>(`/tests/tags`);
}

export async function getTestInfo(testId: string): Promise<TestInfo> {
  return apiFetch<TestInfo>(`/tests/${testId}`);
}

export async function getTestForEdit(testId: string): Promise<TestInfoForEdit> {
  return apiFetch<TestInfoForEdit>(`/tests/tests/edit/${testId}`);
}

export async function getTestQuestionsAmount(testId: string): Promise<number> {
  return apiFetch<number>(`/tests/${testId}/questions-amount`);
}

export async function startTest(testId: string): Promise<Question> {
  return apiFetch<Question>(`/tests/start-test/${testId}`);
}

export async function endTest(testId: string): Promise<unknown> {
  return apiFetch(`/tests/finish-test/${testId}`);
}

export async function submitAnswer(
  testId: string,
  questionId: string,
  answers: string[]
): Promise<SubmitAnswerResult> {
  return apiJson<SubmitAnswerResult>(`/tests/${testId}/submit-answer/${questionId}`, 'POST', {
    answers,
  });
}

export async function editTest(testId: string, data: EditTestPayload): Promise<unknown> {
  return apiJson(`/tests/edit/${testId}`, 'PUT', data);
}

export async function editTestQuestion(
  testId: string,
  questionId: string,
  data: QuestionPayload
): Promise<unknown> {
  return apiJson(`/tests/edit-question/${testId}/${questionId}`, 'PUT', data);
}

export async function addTestQuestion(
  testId: string,
  data: QuestionPayload
): Promise<{ id: string }> {
  return apiJson<{ id: string }>(`/tests/create-question/${testId}`, 'POST', data);
}

export async function deleteTest(testId: string): Promise<void> {
  await apiFetch(`/tests/delete/${testId}`, { method: 'DELETE' });
}

export async function deleteTestQuestion(testId: string, questionId: string): Promise<void> {
  await apiFetch(`/tests/delete/${testId}/${questionId}`, { method: 'DELETE' });
}

export async function createTestManually(
  payload: CreateTestManuallyPayload
): Promise<{ test_id: string; title: string; description: string; question_count: number }> {
  return apiJson(`/tests/create-manually`, 'POST', payload);
}
