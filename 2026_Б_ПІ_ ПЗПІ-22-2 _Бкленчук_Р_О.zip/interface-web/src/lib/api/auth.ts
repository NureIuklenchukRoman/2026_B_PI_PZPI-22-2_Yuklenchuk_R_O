import type { AuthToken } from '../types';
import { apiFetch, apiJson } from './client';

export async function login(email: string, password: string): Promise<AuthToken> {
  const formData = new URLSearchParams({ username: email, password });
  return apiFetch<AuthToken>('/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: formData.toString(),
  });
}

export async function register(email: string, password: string): Promise<AuthToken> {
  return apiJson<AuthToken>('/auth/register', 'POST', { email, password });
}

export async function logout(): Promise<void> {
  await apiFetch('/auth/logout');
}

export async function changePassword(
  currentPassword: string,
  newPassword: string
): Promise<{ message: string }> {
  return apiJson<{ message: string }>('/auth/change-password', 'POST', {
    current_password: currentPassword,
    new_password: newPassword,
  });
}
