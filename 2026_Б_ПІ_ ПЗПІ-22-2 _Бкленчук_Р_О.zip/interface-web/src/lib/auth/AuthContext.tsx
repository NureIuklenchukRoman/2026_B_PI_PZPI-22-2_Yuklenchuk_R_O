/** Single source of truth for the authenticated user.
 *
 * Mounts once at the top of the tree (App.tsx), fetches /users/me on
 * mount, and exposes:
 *   - user:    AuthUser | null
 *   - status:  'loading' | 'authenticated' | 'anonymous'
 *   - refresh: () => Promise<void>  — re-fetch after login/logout/profile-update
 *
 * Children render against `status`; they never call /users/me themselves.
 */

import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { ReactNode } from 'react';

import * as authApi from '../api/auth';
import { ApiError } from '../api/client';
import * as usersApi from '../api/users';
import type { AuthUser } from '../types';

export type AuthStatus = 'loading' | 'authenticated' | 'anonymous';

interface AuthContextValue {
  user: AuthUser | null;
  status: AuthStatus;
  refresh: () => Promise<void>;
  setUser: (user: AuthUser | null) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [status, setStatus] = useState<AuthStatus>('loading');

  const refresh = useCallback(async () => {
    try {
      const me = await usersApi.getMe();
      setUser(me);
      setStatus('authenticated');
    } catch (err) {
      // Anything that's not "I'm authenticated" lands here. The route
      // guard treats this as anonymous; non-401 failures still get
      // surfaced via the error state if the calling page wants them.
      if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
        setUser(null);
        setStatus('anonymous');
      } else {
        setUser(null);
        setStatus('anonymous');
      }
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch {
      /* server-side failure is non-fatal; we still clear local state */
    }
    setUser(null);
    setStatus('anonymous');
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return (
    <AuthContext.Provider value={{ user, status, refresh, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}

/** Convenience hook for components that just need the current user. */
export function useCurrentUser(): AuthUser | null {
  return useAuth().user;
}
