/** Route guard: gates a subtree on AuthContext.status. */

import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';

import Loading from '../../components/Loading';
import { useAuth } from './AuthContext';

interface RequireAuthProps {
  children: ReactNode;
}

export default function RequireAuth({ children }: RequireAuthProps) {
  const { status } = useAuth();
  const location = useLocation();

  if (status === 'loading') {
    return <Loading message="Checking your session…" submessage="One moment" />;
  }
  if (status === 'anonymous') {
    return <Navigate to="/" replace state={{ from: location }} />;
  }
  return <>{children}</>;
}
