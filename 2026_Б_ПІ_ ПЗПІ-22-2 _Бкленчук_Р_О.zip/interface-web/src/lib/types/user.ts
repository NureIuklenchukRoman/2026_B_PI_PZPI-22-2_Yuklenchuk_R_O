/** Mirrors backend api/users/schema.py and api/deps.AuthUser. */

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  is_admin?: boolean;
  /** ISO-8601 UTC string from the backend; absent on legacy rows. */
  created_at?: string | null;
}
