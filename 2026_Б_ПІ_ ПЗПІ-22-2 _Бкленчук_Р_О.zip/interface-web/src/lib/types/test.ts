/** Mirrors backend api/tests/schema.py + response_schema.py. */

export interface Option {
  id: string;
  text: string;
  correct: boolean;
}

export interface Question {
  id: string;
  question: string;
  tags: string[];
  options: Option[];
}

/** Row in GET /tests/ list. */
export interface TestSummary {
  test_id: string;
  title: string;
  description: string;
  question_amount: number;
  /** ISO-8601 string from backend, may be absent on legacy rows. */
  created_at?: string | null;
  tags: string[];
}

/** Detail view from GET /tests/{id}. */
export interface TestInfo {
  id: string;
  title: string;
  description: string;
  question_amount: number;
  is_public?: boolean;
  tags: string[];
}

/** Edit view from GET /tests/tests/edit/{id}. */
export interface TestInfoForEdit extends TestInfo {
  is_public: boolean;
  allowed_emails: string[];
  questions: Question[];
}

export interface EditTestPayload {
  title: string;
  description?: string | null;
  is_public?: boolean | null;
  allowed_emails?: string[] | null;
}

export interface QuestionPayload {
  question: string;
  options: Array<{ id?: string; text: string; correct?: boolean }>;
  tags?: string[];
}

export interface CreateTestManuallyPayload {
  title: string;
  description?: string | null;
  is_public: boolean;
  allowed_emails: string[];
  tags: string[];
  questions: QuestionPayload[];
}

export interface SubmitAnswerResult {
  /** Either the next question's serialized dict, or the literal sentinel. */
  next_question: Question | 'No more questions available';
}
