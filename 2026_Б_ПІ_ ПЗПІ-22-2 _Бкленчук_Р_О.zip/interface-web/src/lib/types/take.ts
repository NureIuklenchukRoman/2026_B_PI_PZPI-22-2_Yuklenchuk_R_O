/** Mirrors backend api/users/schema.py UserTakesResponseSchema +
 * UserTakeDetailsResponseSchema and the related UserService output. */

import type { Question } from './test';

export interface TakeSummary {
  id: string;
  test_id: string;
  completed_at: string;
  title: string;
  description: string;
  questions_amount: number;
  tags: string[];
  res_count: number;
}

export interface TakeQuestion extends Question {
  selected_answers: string[];
}

export interface TakeDetails extends TakeSummary {
  questions: TakeQuestion[];
}

export interface AuthToken {
  access_token: string;
  refresh_token: string;
  token_type: string;
}
