import { useMemo, useState } from 'react';

/** Minimal shape that the filtering hook needs from each item. */
export interface FilterableItem {
  title?: string;
  description?: string;
  tags?: string[];
  question_amount?: number;
  /** Tests use created_at; takes use completed_at. */
  created_at?: string | null;
  completed_at?: string | null;
}

interface UseTestFilteringOptions {
  defaultSort?: string;
}

const timeOf = (item: FilterableItem): number =>
  new Date(item.created_at || item.completed_at || 0).getTime();

export default function useTestFiltering<T extends FilterableItem>(
  items: T[],
  { defaultSort = 'title' }: UseTestFilteringOptions = {}
) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState(defaultSort);

  const availableTags = useMemo(() => {
    const tags = new Set<string>();
    items.forEach((item) => {
      item.tags?.forEach((tag) => tags.add(tag));
    });
    return Array.from(tags);
  }, [items]);

  const filteredItems = useMemo(() => {
    return items
      .filter((item) => {
        const matchesSearch =
          (item.title ?? '').toLowerCase().includes(searchTerm.toLowerCase()) ||
          (item.description ?? '').toLowerCase().includes(searchTerm.toLowerCase());
        const matchesTags =
          selectedTags.length === 0 || selectedTags.every((tag) => item.tags?.includes(tag));
        return matchesSearch && matchesTags;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'questions':
            return (b.question_amount || 0) - (a.question_amount || 0);
          case 'newest':
            return timeOf(b) - timeOf(a);
          case 'oldest':
            return timeOf(a) - timeOf(b);
          case 'title':
            return (a.title || '').localeCompare(b.title || '');
          default:
            return 0;
        }
      });
  }, [items, searchTerm, selectedTags, sortBy]);

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return {
    searchTerm,
    setSearchTerm,
    selectedTags,
    sortBy,
    setSortBy,
    availableTags,
    filteredItems,
    toggleTag,
  };
}
