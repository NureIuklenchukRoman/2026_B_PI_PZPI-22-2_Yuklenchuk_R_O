/**
 * Dev-only mock backend. Gated behind `VITE_MOCK=1` (see main.tsx); it is
 * never bundled into a normal `vite build` run because the import is guarded
 * by `import.meta.env.VITE_MOCK`. It monkeypatches `window.fetch` so every
 * backend path the app calls resolves to canned data, letting all pages
 * render without the Kubernetes stack running.
 *
 * Remove this file (and its guard in main.tsx) once a real dev backend is
 * wired up — nothing in production code depends on it.
 */

import { testService } from '../services/testService';
import type {
  AuthUser,
  TakeDetails,
  TakeSummary,
  TestInfoForEdit,
  TestSummary,
  Question,
} from '../lib/types';
import type { ParseJob } from '../lib/api/knowledge';

const USER: AuthUser = {
  id: '1',
  email: 'maria.kovalenko@university.edu',
  username: 'maria.kovalenko',
  is_admin: true,
  created_at: '2025-09-14T08:30:00Z',
};

const TESTS: TestSummary[] = [
  {
    test_id: '1',
    title: 'Data Structures & Algorithms',
    description:
      'Core complexity analysis, sorting, trees, and graph traversal. Built from the CS-201 lecture series.',
    question_amount: 18,
    created_at: '2026-05-21T10:00:00Z',
    tags: ['algorithms', 'trees', 'complexity'],
  },
  {
    test_id: '2',
    title: 'Relational Databases',
    description: 'Normalization, indexing, transactions, and query planning in PostgreSQL.',
    question_amount: 24,
    created_at: '2026-05-18T15:30:00Z',
    tags: ['databases', 'sql', 'indexing'],
  },
  {
    test_id: '3',
    title: 'Computer Networks',
    description: 'The TCP/IP stack from physical framing up to HTTP, with a focus on congestion control.',
    question_amount: 20,
    created_at: '2026-05-11T09:15:00Z',
    tags: ['networks', 'tcp', 'routing'],
  },
  {
    test_id: '4',
    title: 'Operating Systems',
    description: 'Scheduling, virtual memory, concurrency primitives, and file system design.',
    question_amount: 30,
    created_at: '2026-05-04T14:45:00Z',
    tags: ['operating-systems', 'concurrency', 'memory'],
  },
  {
    test_id: '5',
    title: 'Applied Cryptography',
    description: 'Symmetric and public-key schemes, hashing, and the handshake behind TLS.',
    question_amount: 16,
    created_at: '2026-04-28T11:20:00Z',
    tags: ['security', 'cryptography'],
  },
  {
    test_id: '6',
    title: 'Discrete Mathematics',
    description: 'Logic, set theory, combinatorics, and proof techniques for computer science.',
    question_amount: 22,
    created_at: '2026-04-20T16:00:00Z',
    tags: ['mathematics', 'logic', 'proofs'],
  },
];

function makeQuestion(n: number): Question {
  return {
    id: `q${n}`,
    question:
      n === 1
        ? 'What is the average-case time complexity of a balanced binary search tree lookup?'
        : n === 2
          ? 'Which data structure gives amortized O(1) insertion at both ends?'
          : 'A hash table degrades to which complexity when every key collides?',
    tags: ['algorithms', 'complexity'],
    options: [
      { id: `q${n}-a`, text: 'O(log n)', correct: n === 1 },
      { id: `q${n}-b`, text: 'O(1)', correct: n === 2 },
      { id: `q${n}-c`, text: 'O(n)', correct: n === 3 },
      { id: `q${n}-d`, text: 'O(n log n)', correct: false },
    ],
  };
}

const TEST_FOR_EDIT: TestInfoForEdit = {
  id: '1',
  title: 'Data Structures & Algorithms',
  description: 'Core complexity analysis, sorting, trees, and graph traversal.',
  question_amount: 3,
  is_public: true,
  allowed_emails: ['ta.group@university.edu'],
  tags: ['algorithms', 'trees', 'complexity'],
  questions: [makeQuestion(1), makeQuestion(2), makeQuestion(3)],
};

const TAKES: TakeSummary[] = [
  {
    id: 't1',
    test_id: '1',
    completed_at: '2026-05-30T12:40:00Z',
    title: 'Data Structures & Algorithms',
    description: 'Core complexity analysis, sorting, trees, and graph traversal.',
    questions_amount: 18,
    tags: ['algorithms', 'trees'],
    res_count: 15,
  },
  {
    id: 't2',
    test_id: '3',
    completed_at: '2026-05-26T18:05:00Z',
    title: 'Computer Networks',
    description: 'The TCP/IP stack from physical framing up to HTTP.',
    questions_amount: 20,
    tags: ['networks', 'tcp'],
    res_count: 12,
  },
  {
    id: 't3',
    test_id: '5',
    completed_at: '2026-05-19T09:50:00Z',
    title: 'Applied Cryptography',
    description: 'Symmetric and public-key schemes, hashing, and TLS.',
    questions_amount: 16,
    tags: ['security'],
    res_count: 16,
  },
];

const TAKE_DETAILS: TakeDetails = {
  ...TAKES[0],
  questions: [makeQuestion(1), makeQuestion(2), makeQuestion(3)].map((q, i) => ({
    ...q,
    selected_answers: i === 2 ? [q.options[0].id] : [q.options.find((o) => o.correct)?.id ?? ''],
  })),
};

const PARSE_JOBS: ParseJob[] = [
  {
    job_id: 'j1',
    source_type: 'test_gen',
    status: 'completed',
    stage: 'completed',
    total_chunks: 5,
    completed_chunks: 5,
    failed_chunks: 0,
    message: 'Completed with 5 chunks',
    test_id: '1',
    created_at: '2026-05-21T09:40:00Z',
    updated_at: '2026-05-21T10:00:00Z',
  },
  {
    job_id: 'j1b',
    source_type: 'knowledge_base',
    status: 'completed',
    stage: 'completed',
    total_chunks: 6,
    completed_chunks: 6,
    failed_chunks: 0,
    message: 'Completed with 5 chunks',
    test_id: '1',
    created_at: '2026-05-21T09:40:00Z',
    updated_at: '2026-05-21T10:00:00Z',
  },
  {
    job_id: 'j2',
    source_type: 'media',
    status: 'processing',
    stage: 'segmenting transcript',
    total_chunks: 20,
    completed_chunks: 8,
    failed_chunks: 0,
    message: null,
    test_id: null,
    created_at: '2026-06-03T08:10:00Z',
    updated_at: '2026-06-03T08:14:00Z',
  },
  {
    job_id: 'j3',
    source_type: 'text',
    status: 'failed',
    stage: 'embedding',
    total_chunks: 6,
    completed_chunks: 2,
    failed_chunks: 4,
    message: null,
    error_message: 'Embedding service timed out after 3 retries.',
    test_id: null,
    created_at: '2026-06-01T17:20:00Z',
    updated_at: '2026-06-01T17:26:00Z',
  },
];

const TEST_RESULTS = {
  score: 83,
  correct_answers: 15,
  incorrect_answers: 3,
  time_taken: '22:14',
  question_breakdown: [
    {
      question_id: 'q1',
      question: 'What is the average-case time complexity of a balanced BST lookup?',
      user_answer: 'O(log n)',
      correct_answer: 'O(log n)',
      is_correct: true,
      time_taken: 41,
    },
    {
      question_id: 'q2',
      question: 'Which data structure gives amortized O(1) insertion at both ends?',
      user_answer: 'O(1)',
      correct_answer: 'O(1)',
      is_correct: true,
      time_taken: 33,
    },
    {
      question_id: 'q3',
      question: 'A hash table degrades to which complexity when every key collides?',
      user_answer: 'O(log n)',
      correct_answer: 'O(n)',
      is_correct: false,
      time_taken: 58,
    },
  ],
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

// Advances the test-taking flow: serve two questions then signal completion.
let submitCount = 0;

// In-memory chat persistence, keyed by knowledge_id ('-1' = global). Mirrors
// the real backend's per-user-per-chat conversations within a session.
type StoredMessage = { role: string; content: string; created_at: string };
const CONVERSATIONS: Record<string, StoredMessage[]> = {};
const MOCK_ANSWER =
  'A balanced binary search tree keeps its height at O(log n), so lookups, ' +
  'insertions, and deletions all run in logarithmic time. Red-black trees and ' +
  'AVL trees are the two classic ways to maintain that balance after every mutation.';

function route(method: string, path: string): Response {
  // --- auth ---
  if (path.startsWith('/auth/')) return json({ token_type: 'bearer' });

  // --- current user ---
  if (path === '/users/me') {
    return json(USER);
  }

  // --- user-scoped lists ---
  if (path === '/users/my-takes') return json(TAKES);
  if (path.startsWith('/users/my-takes/')) return json(TAKE_DETAILS);
  if (path === '/users/my-tests') return json(TESTS.slice(0, 3));

  // --- test taking ---
  if (path.startsWith('/tests/start-test/')) {
    submitCount = 0;
    return json(makeQuestion(1));
  }
  if (path.startsWith('/tests/finish-test/')) return json({});
  if (path.includes('/submit-answer/')) {
    submitCount += 1;
    if (submitCount >= 3) return json({ next_question: 'No more questions available' });
    return json({ next_question: makeQuestion(submitCount + 1) });
  }
  if (/\/tests\/[^/]+\/questions-amount$/.test(path)) return json(3);
  if (path.startsWith('/tests/tests/edit/')) return json(TEST_FOR_EDIT);

  // Distinct tags across the catalog (powers the filter chips).
  if (path === '/tests/tags') {
    return json([...new Set(TESTS.flatMap((t) => t.tags ?? []))].sort());
  }

  // --- test catalog (server-side search / tag filter / sort) ---
  if (path.startsWith('/tests?') || path === '/tests' || path === '/tests/') {
    const params = new URLSearchParams(path.split('?')[1] ?? '');
    const q = (params.get('q') ?? '').trim().toLowerCase();
    const tagFilter = (params.get('tags') ?? '')
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const sort = params.get('sort') ?? 'newest';

    let out = TESTS.filter((t) => {
      if (tagFilter.length && !tagFilter.every((tag) => (t.tags ?? []).includes(tag))) return false;
      if (q) {
        const hay = `${t.title} ${t.description} ${(t.tags ?? []).join(' ')}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    const time = (t: TestSummary) => new Date(t.created_at ?? 0).getTime();
    out = [...out].sort((a, b) => {
      if (sort === 'title') return a.title.localeCompare(b.title);
      if (sort === 'questions') return b.question_amount - a.question_amount;
      if (sort === 'oldest') return time(a) - time(b);
      return time(b) - time(a); // newest
    });
    return json(out);
  }
  if (/^\/tests\/[^/]+$/.test(path)) {
    const t = TESTS[0];
    return json({ ...t, id: t.test_id, is_public: true });
  }
  if (path.startsWith('/tests/')) return json({});

  // --- knowledge / parse jobs ---
  if (path === '/ask-knowledge') {
    return json({
      answer:
        'A balanced binary search tree keeps its height at O(log n), so lookups, insertions, and deletions all run in logarithmic time. Red-black trees and AVL trees are the two classic ways to maintain that balance after every mutation.',
    });
  }
  if (path === '/process') return json({ message: 'queued', knowledge_id: 'k1' });
  if (path === '/parse-jobs/' || path === '/parse-jobs') return json(PARSE_JOBS);
  if (path.startsWith('/parse-jobs/admin/global')) return json(PARSE_JOBS[1]);
  if (path === '/parse-jobs/text' || path === '/parse-jobs/media') return json(PARSE_JOBS[1]);
  if (path.startsWith('/parse-jobs/')) return json(PARSE_JOBS[0]);

  // --- mutations that just need to succeed ---
  if (method !== 'GET') return json({ ok: true });

  return json({ detail: `No mock for ${method} ${path}` }, 404);
}

export function installMockServer(): void {
  const realFetch = window.fetch.bind(window);

  window.fetch = (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const method = (init?.method ?? 'GET').toUpperCase();

    let path = url;
    try {
      // Strip the origin so same-origin and absolute URLs both match.
      path = new URL(url, window.location.origin).pathname + new URL(url, window.location.origin).search;
    } catch {
      /* leave path as-is */
    }

    // Only intercept the backend paths the app uses; let everything else
    // (Vite HMR, assets) hit the network normally.
    const handled = /^\/(auth|users|tests|ask-knowledge|process|parse-jobs|conversations)/.test(
      path
    );
    if (!handled) return realFetch(input, init);

    const pathNoQuery = path.split('?')[0];
    const search = new URLSearchParams(path.split('?')[1] ?? '');

    // --- conversation persistence (needs the request body, so handled here) ---
    if (pathNoQuery === '/conversations' && method === 'GET') {
      const kid = search.get('knowledge_id') || '-1';
      return Promise.resolve(json({ knowledge_id: kid, messages: CONVERSATIONS[kid] ?? [] }));
    }
    if (pathNoQuery === '/ask-knowledge' && method === 'POST') {
      let body: { message?: string; knowledge_id?: string } = {};
      try {
        body = JSON.parse(String(init?.body ?? '{}'));
      } catch {
        /* ignore */
      }
      const kid = body.knowledge_id || '-1';
      const now = new Date().toISOString();
      const thread = (CONVERSATIONS[kid] ??= []);
      thread.push({ role: 'user', content: body.message ?? '', created_at: now });
      thread.push({ role: 'assistant', content: MOCK_ANSWER, created_at: now });
      return Promise.resolve(json({ answer: MOCK_ANSWER }));
    }

    const matchPath = path.startsWith('/tests?') ? path : pathNoQuery;
    return Promise.resolve(route(method, matchPath));
  };

  // TestResults calls testService.getTestResults, which has never existed on
  // the shim (documented in the page). Provide it here so the page renders.
  (testService as unknown as { getTestResults: () => Promise<typeof TEST_RESULTS> }).getTestResults =
    () => Promise.resolve(TEST_RESULTS);

  // eslint-disable-next-line no-console
  console.info('[mock] dev mock backend installed');
}
