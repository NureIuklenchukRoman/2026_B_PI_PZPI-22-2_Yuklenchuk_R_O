# Credential Store: API Key Registry

Credential Store manages internal LLM/API credentials for Testify. It stores one API key per Kubernetes Secret, exposes a service for registering and selecting keys, and runs an operator that validates key readiness and usage.

## Role in Testify

`assessment-generator` and `knowledge-engine` use this service when they need external model credentials. The registry keeps raw key material in Secrets, mirrors key status into `APIKey` custom resources, and selects ready keys by usage.

Kubernetes role:

```text
namespace: testify-credentials
workloads: credential-store, credential-operator
service: credential-store
custom resource: APIKey.llm.testify.io
```

## Technology

- Go HTTP service for key registration and selection
- Go Kubernetes operator
- Kubernetes Secrets for credential storage
- CustomResourceDefinition for key status
- Helm chart with RBAC and CRDs
- Docker images for store and operator

## Installation

```bash
cd credential-store
task server:tidy
task operator:tidy
```

## Usage

Run tests:

```bash
task test
```

Build binaries:

```bash
task build
```

Build, push, and deploy:

```bash
task docker:push
task helm:deploy
```

Primary endpoints:

```text
POST /RegisterKey
POST /RemoveKey
GET  /GetLeastUsedKey
GET  /GetKey
```

## License

Not specified.
