package controller

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"

	corev1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"

	llmv1alpha1 "key-operator/api/v1alpha1"
)

const (
	usesAnnotation          = "llm.testify.io/uses"
	openRouterKeyURL        = "https://openrouter.ai/api/v1/key"
	defaultSecretNamePrefix = "llmkey-openrouter-"
	defaultSecretDataKey    = "apiKey"
)

// +kubebuilder:rbac:groups=llm.testify.io,resources=apikeys,verbs=get;list;watch;create;update;patch;delete
// +kubebuilder:rbac:groups=llm.testify.io,resources=apikeys/status,verbs=get;update;patch
// +kubebuilder:rbac:groups="",resources=secrets,verbs=get;list;watch
type APIKeyReconciler struct {
	client.Client
	Scheme *runtime.Scheme
}

func (r *APIKeyReconciler) Reconcile(ctx context.Context, req ctrl.Request) (ctrl.Result, error) {
	var sec corev1.Secret
	if err := r.Get(ctx, req.NamespacedName, &sec); err != nil {
		if !apierrors.IsNotFound(err) {
			return ctrl.Result{}, err
		}
		var apiKey llmv1alpha1.APIKey
		if getErr := r.Get(ctx, req.NamespacedName, &apiKey); apierrors.IsNotFound(getErr) {
			return ctrl.Result{}, nil
		} else if getErr != nil {
			return ctrl.Result{}, getErr
		}
		if delErr := r.Delete(ctx, &apiKey); delErr != nil && !apierrors.IsNotFound(delErr) {
			return ctrl.Result{}, delErr
		}
		return ctrl.Result{}, nil
	}

	if !strings.HasPrefix(sec.Name, defaultSecretNamePrefix) {
		return ctrl.Result{}, nil
	}

	key := client.ObjectKey{Namespace: sec.Namespace, Name: sec.Name}
	var apiKey llmv1alpha1.APIKey
	err := r.Get(ctx, key, &apiKey)
	if err != nil && !apierrors.IsNotFound(err) {
		return ctrl.Result{}, err
	}
	if apierrors.IsNotFound(err) {
		apiKey = llmv1alpha1.APIKey{
			ObjectMeta: metav1.ObjectMeta{
				Name:      sec.Name,
				Namespace: sec.Namespace,
			},
			Spec: llmv1alpha1.APIKeySpec{
				SecretName: sec.Name,
				SecretKey:  defaultSecretDataKey,
			},
		}
		if createErr := r.Create(ctx, &apiKey); createErr != nil {
			return ctrl.Result{}, createErr
		}
	}

	now := metav1.Now()
	status := llmv1alpha1.APIKeyStatus{
		Ready:         false,
		TimesUsed:     parseInt64(sec.Annotations[usesAnnotation]),
		LastValidated: now,
	}
	token, ok := sec.Data[defaultSecretDataKey]
	if !ok || len(token) == 0 {
		status.LastError = "missing token data key"
	} else {
		httpClient := &http.Client{Timeout: 10 * time.Second}
		okKey, vErr := validateOpenRouterKey(ctx, httpClient, string(token))
		if vErr != nil {
			status.LastError = vErr.Error()
		} else {
			status.Ready = okKey
			status.LastError = ""
		}
	}

	base := apiKey.DeepCopy()
	apiKey.Spec.SecretName = sec.Name
	apiKey.Spec.SecretKey = defaultSecretDataKey
	if err := r.Patch(ctx, &apiKey, client.MergeFrom(base)); err != nil {
		return ctrl.Result{}, err
	}

	statusBase := apiKey.DeepCopy()
	apiKey.Status = status
	if err := r.Status().Patch(ctx, &apiKey, client.MergeFrom(statusBase)); err != nil {
		return ctrl.Result{}, err
	}

	return ctrl.Result{RequeueAfter: 15 * time.Minute}, nil
}

func (r *APIKeyReconciler) SetupWithManager(mgr ctrl.Manager) error {
	return ctrl.NewControllerManagedBy(mgr).
		For(&corev1.Secret{}).
		Complete(r)
}

func validateOpenRouterKey(ctx context.Context, httpClient *http.Client, token string) (bool, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, openRouterKeyURL, nil)
	if err != nil {
		return false, err
	}
	req.Header.Set("Authorization", "Bearer "+token)

	resp, err := httpClient.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	switch resp.StatusCode {
	case http.StatusOK:
		return true, nil
	case http.StatusUnauthorized, http.StatusForbidden:
		return false, errors.New("unauthorized")
	default:
		return false, errors.New("validation failed: " + resp.Status)
	}
}

func parseInt64(s string) int64 {
	var n int64
	for _, ch := range s {
		if ch < '0' || ch > '9' {
			return 0
		}
		n = n*10 + int64(ch-'0')
	}
	return n
}
