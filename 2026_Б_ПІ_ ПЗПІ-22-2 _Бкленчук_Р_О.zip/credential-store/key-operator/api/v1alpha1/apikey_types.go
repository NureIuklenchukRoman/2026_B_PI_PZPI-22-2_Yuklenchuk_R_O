package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
)

type APIKeySpec struct {
	SecretName string `json:"secretName"`
	SecretKey  string `json:"secretKey"`
}

type APIKeyStatus struct {
	Ready         bool        `json:"ready"`
	TimesUsed     int64       `json:"timesUsed"`
	LastValidated metav1.Time `json:"lastValidated"`
	// +optional
	LastError string `json:"lastError,omitempty"`
}

// +kubebuilder:object:root=true
// +kubebuilder:subresource:status
// +kubebuilder:resource:path=apikeys,scope=Namespaced,singular=apikey
// +kubebuilder:printcolumn:name="TimesUsed",type=integer,JSONPath=`.status.timesUsed`
// +kubebuilder:printcolumn:name="Ready",type=boolean,JSONPath=`.status.ready`
// +kubebuilder:printcolumn:name="LastValidated",type=date,JSONPath=`.status.lastValidated`
type APIKey struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   APIKeySpec   `json:"spec,omitempty"`
	Status APIKeyStatus `json:"status,omitempty"`
}

// +kubebuilder:object:root=true
type APIKeyList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []APIKey `json:"items"`
}

func (in *APIKey) DeepCopy() *APIKey {
	if in == nil {
		return nil
	}
	out := new(APIKey)
	*out = *in
	out.ObjectMeta = *in.ObjectMeta.DeepCopy()
	return out
}

func (in *APIKey) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	return in.DeepCopy()
}

func (in *APIKeyList) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	out := new(APIKeyList)
	*out = *in
	out.ListMeta = in.ListMeta
	if in.Items != nil {
		out.Items = make([]APIKey, len(in.Items))
		copy(out.Items, in.Items)
	}
	return out
}

func init() {
	SchemeBuilder.Register(&APIKey{}, &APIKeyList{})
}
