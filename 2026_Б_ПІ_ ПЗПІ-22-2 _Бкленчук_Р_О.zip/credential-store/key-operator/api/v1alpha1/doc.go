// Package v1alpha1 contains API Schema definitions for the llm v1alpha1 API group
//
// +kubebuilder:object:generate=true
// +groupName=llm.testify.io
package v1alpha1
