module key-server

go 1.24.0

toolchain go1.24.2

require (
	github.com/google/uuid v1.6.0
	k8s.io/api v0.33.0
	k8s.io/apimachinery v0.33.0
	k8s.io/client-go v0.33.0
)

