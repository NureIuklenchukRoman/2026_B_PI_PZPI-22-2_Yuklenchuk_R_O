package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/google/uuid"
	corev1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/util/retry"
)

const usesAnnotation = "llm.testify.io/uses"

type server struct {
	client        kubernetes.Interface
	dynamicClient dynamic.Interface
	namespace     string
	secretPrefix  string
	secretDataKey string
}

type apiKeyCandidate struct {
	secretName string
	secretKey  string
	timesUsed  int64
}

type registerKeyRequest struct {
	ID    string `json:"id,omitempty"`
	Token string `json:"token"`
}

type removeKeyRequest struct {
	ID string `json:"id"`
}

type keyValueResponse struct {
	Key string `json:"key"`
}

func main() {
	port := flag.String("port", "8080", "HTTP server port")
	namespace := flag.String("namespace", "", "Kubernetes namespace (default: POD_NAMESPACE env var)")
	secretPrefix := flag.String("secret-prefix", "llmkey-openrouter-", "Managed Secret name prefix")
	secretDataKey := flag.String("secret-key", "apiKey", "Secret data key that stores token")
	flag.Parse()

	ns := strings.TrimSpace(*namespace)
	if ns == "" {
		ns = strings.TrimSpace(os.Getenv("POD_NAMESPACE"))
	}
	if ns == "" {
		log.Fatal("namespace must be set via --namespace or POD_NAMESPACE")
	}

	cfg, err := rest.InClusterConfig()
	if err != nil {
		log.Fatalf("Failed to create in-cluster config: %v", err)
	}
	client, err := kubernetes.NewForConfig(cfg)
	if err != nil {
		log.Fatalf("Failed to create Kubernetes client: %v", err)
	}
	dyn, err := dynamic.NewForConfig(cfg)
	if err != nil {
		log.Fatalf("Failed to create dynamic client: %v", err)
	}

	s := &server{
		client:        client,
		dynamicClient: dyn,
		namespace:     ns,
		secretPrefix:  *secretPrefix,
		secretDataKey: *secretDataKey,
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/RegisterKey", s.handleRegisterKey)
	mux.HandleFunc("/registerkey", s.handleRegisterKey)
	mux.HandleFunc("/RemoveKey", s.handleRemoveKey)
	mux.HandleFunc("/removekey", s.handleRemoveKey)
	mux.HandleFunc("/GetLeastUsedKey", s.handleGetLeastUsedKey)
	mux.HandleFunc("/GetKey", s.handleGetLeastUsedKey)
	mux.HandleFunc("/getkey", s.handleGetLeastUsedKey)
	httpServer := &http.Server{
		Addr:              ":" + *port,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	go func() {
		log.Printf("key-server listening on :%s", *port)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_ = httpServer.Shutdown(ctx)
}

func (s *server) handleRegisterKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req registerKeyRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	if strings.TrimSpace(req.Token) == "" {
		http.Error(w, "token is required", http.StatusBadRequest)
		return
	}

	id := strings.TrimSpace(req.ID)
	if id == "" {
		id = uuid.NewString()
	}
	name := s.secretPrefix + id

	sec := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      name,
			Namespace: s.namespace,
			Annotations: map[string]string{
				usesAnnotation: "0",
			},
		},
		Type: corev1.SecretTypeOpaque,
		Data: map[string][]byte{
			s.secretDataKey: []byte(req.Token),
		},
	}

	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	_, err := s.client.CoreV1().Secrets(s.namespace).Create(ctx, sec, metav1.CreateOptions{})
	if apierrors.IsAlreadyExists(err) {
		http.Error(w, "key already exists", http.StatusConflict)
		return
	}
	if err != nil {
		http.Error(w, "failed to create secret", http.StatusInternalServerError)
		return
	}

	_ = json.NewEncoder(w).Encode(map[string]string{"id": id})
}

func (s *server) handleRemoveKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req removeKeyRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid json", http.StatusBadRequest)
		return
	}
	id := strings.TrimSpace(req.ID)
	if id == "" {
		http.Error(w, "id is required", http.StatusBadRequest)
		return
	}
	name := s.secretPrefix + id

	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Second)
	defer cancel()

	err := s.client.CoreV1().Secrets(s.namespace).Delete(ctx, name, metav1.DeleteOptions{})
	if apierrors.IsNotFound(err) {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	if err != nil {
		http.Error(w, "failed to delete secret", http.StatusInternalServerError)
		return
	}

	_ = json.NewEncoder(w).Encode(map[string]string{"status": "deleted"})
}

func (s *server) handleGetLeastUsedKey(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	ctx, cancel := context.WithTimeout(r.Context(), 15*time.Second)
	defer cancel()

	chosenRef, err := s.getLeastUsedFromAPIKeys(ctx)
	if err != nil {
		http.Error(w, "failed to list apikeys", http.StatusInternalServerError)
		return
	}
	if chosenRef == nil {
		http.Error(w, "no keys registered", http.StatusNotFound)
		return
	}

	var chosenToken string
	_ = retry.RetryOnConflict(retry.DefaultRetry, func() error {
		latest, err := s.client.CoreV1().Secrets(s.namespace).Get(ctx, chosenRef.secretName, metav1.GetOptions{})
		if err != nil {
			return err
		}
		tokenBytes, ok := latest.Data[chosenRef.secretKey]
		if !ok || len(tokenBytes) == 0 {
			return errors.New("chosen key has empty token")
		}
		chosenToken = string(tokenBytes)
		if latest.Annotations == nil {
			latest.Annotations = map[string]string{}
		}
		uses := parseInt64(latest.Annotations[usesAnnotation])
		latest.Annotations[usesAnnotation] = formatInt64(uses + 1)
		_, err = s.client.CoreV1().Secrets(s.namespace).Update(ctx, latest, metav1.UpdateOptions{})
		return err
	})

	if strings.TrimSpace(chosenToken) == "" {
		http.Error(w, "failed to get key", http.StatusInternalServerError)
		return
	}

	_ = json.NewEncoder(w).Encode(keyValueResponse{
		Key: chosenToken,
	})
}

func (s *server) getLeastUsedFromAPIKeys(ctx context.Context) (*apiKeyCandidate, error) {
	gvr := schema.GroupVersionResource{
		Group:    "llm.testify.io",
		Version:  "v1alpha1",
		Resource: "apikeys",
	}
	list, err := s.dynamicClient.Resource(gvr).Namespace(s.namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	var chosen *apiKeyCandidate
	for i := range list.Items {
		item := &list.Items[i]
		ready, _, _ := unstructured.NestedBool(item.Object, "status", "ready")
		if !ready {
			continue
		}
		secretName, _, _ := unstructured.NestedString(item.Object, "spec", "secretName")
		secretKey, _, _ := unstructured.NestedString(item.Object, "spec", "secretKey")
		if secretName == "" {
			continue
		}
		if secretKey == "" {
			secretKey = s.secretDataKey
		}
		timesUsed, _, _ := unstructured.NestedInt64(item.Object, "status", "timesUsed")
		candidate := apiKeyCandidate{
			secretName: secretName,
			secretKey:  secretKey,
			timesUsed:  timesUsed,
		}
		if chosen == nil || candidate.timesUsed < chosen.timesUsed {
			chosen = &candidate
		}
	}
	return chosen, nil
}

func parseInt64(s string) int64 {
	var n int64
	for _, ch := range s {
		if ch < '0' || ch > '9' {
			return 0
		}
		n = n*10 + int64(ch-'0')
	}
	return n
}

func formatInt64(n int64) string {
	if n <= 0 {
		return "0"
	}
	var b [32]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + (n % 10))
		n /= 10
	}
	return string(b[i:])
}
