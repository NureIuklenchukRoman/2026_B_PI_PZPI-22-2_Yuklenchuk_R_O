package database

import (
	"context"
	"fmt"

	"question-builder/internal/question"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type PostgresStore struct {
	pool *pgxpool.Pool
}

func NewPostgresStore(ctx context.Context, databaseURL string) (*PostgresStore, error) {
	pool, err := pgxpool.New(ctx, databaseURL)
	if err != nil {
		return nil, err
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, err
	}
	return &PostgresStore{pool: pool}, nil
}

func (s *PostgresStore) Close() {
	s.pool.Close()
}

func (s *PostgresStore) SaveQuestions(ctx context.Context, testID string, generated []question.GeneratedQuestion) error {
	tx, err := s.pool.BeginTx(ctx, pgx.TxOptions{})
	if err != nil {
		return fmt.Errorf("begin transaction: %w", err)
	}
	defer tx.Rollback(ctx)

	for _, item := range generated {
		questionID := uuid.NewString()
		if _, err := tx.Exec(ctx,
			`insert into questions (id, test_id, question, tags) values ($1, $2, $3, $4)`,
			questionID,
			testID,
			item.QuestionText,
			item.Tags,
		); err != nil {
			return fmt.Errorf("insert question: %w", err)
		}

		for idx, option := range item.Options {
			if _, err := tx.Exec(ctx,
				`insert into options (id, question_id, text, correct) values ($1, $2, $3, $4)`,
				uuid.NewString(),
				questionID,
				option,
				idx == item.CorrectAnswerIndex,
			); err != nil {
				return fmt.Errorf("insert option: %w", err)
			}
		}
	}

	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit transaction: %w", err)
	}
	return nil
}
