package llm

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"question-builder/internal/question"
)

type OpenRouterClient struct {
	keyStoreURL  string
	defaultModel string
	httpClient   *http.Client
}

func NewOpenRouterClient(keyStoreURL, defaultModel string, timeout time.Duration) *OpenRouterClient {
	return &OpenRouterClient{
		keyStoreURL:  strings.TrimRight(keyStoreURL, "/"),
		defaultModel: defaultModel,
		httpClient:   &http.Client{Timeout: timeout},
	}
}

func (c *OpenRouterClient) GenerateQuestion(ctx context.Context, chunk string, model string) (question.GeneratedQuestion, error) {
	if strings.TrimSpace(model) == "" {
		model = c.defaultModel
	}

	apiKey, err := c.getAPIKey(ctx)
	if err != nil {
		return question.GeneratedQuestion{}, err
	}

	payload := map[string]interface{}{
		"model": model,
		"messages": []map[string]string{
			{"role": "system", "content": "You generate assessment questions as strict JSON only. Never include markdown."},
			{"role": "user", "content": buildPrompt(chunk)},
		},
		"response_format": map[string]string{"type": "json_object"},
	}

	body, err := json.Marshal(payload)
	if err != nil {
		return question.GeneratedQuestion{}, err
	}

	var lastErr error
	for attempt := 0; attempt < 3; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return question.GeneratedQuestion{}, ctx.Err()
			case <-time.After(time.Duration(attempt) * time.Second):
			}
		}

		generated, err := c.callOpenRouter(ctx, apiKey, body)
		if err == nil {
			return generated, nil
		}
		lastErr = err
	}

	return question.GeneratedQuestion{}, lastErr
}

func (c *OpenRouterClient) callOpenRouter(ctx context.Context, apiKey string, body []byte) (question.GeneratedQuestion, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://openrouter.ai/api/v1/chat/completions", bytes.NewReader(body))
	if err != nil {
		return question.GeneratedQuestion{}, err
	}
	req.Header.Set("Authorization", "Bearer "+apiKey)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("HTTP-Referer", "http://question-builder")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return question.GeneratedQuestion{}, err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		respBody, _ := io.ReadAll(resp.Body)
		return question.GeneratedQuestion{}, fmt.Errorf("openrouter status %d: %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return question.GeneratedQuestion{}, err
	}
	if len(result.Choices) == 0 {
		return question.GeneratedQuestion{}, fmt.Errorf("openrouter returned no choices")
	}

	var generated question.GeneratedQuestion
	if err := json.Unmarshal([]byte(stripCodeFence(result.Choices[0].Message.Content)), &generated); err != nil {
		return question.GeneratedQuestion{}, fmt.Errorf("decode generated question: %w", err)
	}

	if generated.DifficultyLevel == "" {
		generated.DifficultyLevel = "medium"
	}
	if len(generated.Tags) == 0 {
		generated.Tags = []string{"general"}
	}
	return generated, nil
}

func (c *OpenRouterClient) getAPIKey(ctx context.Context) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.keyStoreURL+"/getkey", nil)
	if err != nil {
		return "", err
	}

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("fetch key: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("key store status %d", resp.StatusCode)
	}

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var jsonResp map[string]string
	if err := json.Unmarshal(bodyBytes, &jsonResp); err == nil {
		for key, value := range jsonResp {
			lower := strings.ToLower(key)
			if strings.Contains(lower, "key") || strings.Contains(lower, "token") {
				return cleanKey(value), nil
			}
		}
	}

	key := cleanKey(string(bodyBytes))
	if key == "" {
		return "", fmt.Errorf("key store returned an empty key")
	}
	return key, nil
}

func buildPrompt(chunk string) string {
	return fmt.Sprintf(`Create one multiple-choice question from this educational content.
Return exactly this JSON shape:
{
  "question_text": "string",
  "options": ["string", "string", "string", "string"],
  "correct_answer_index": 0,
  "difficulty_level": "easy|medium|hard",
  "tags": ["short-topic-tag"]
}

Rules:
- Use only the supplied content.
- Make exactly four answer options.
- Make one and only one option correct.
- Keep tags short and useful for adaptive routing.

Content:
%s`, chunk)
}

func cleanKey(value string) string {
	value = strings.TrimSpace(value)
	value = strings.ReplaceAll(value, "\n", "")
	value = strings.ReplaceAll(value, "\r", "")
	value = strings.Trim(value, "\"'")
	return value
}

func stripCodeFence(value string) string {
	value = strings.TrimSpace(value)
	value = strings.TrimPrefix(value, "```json")
	value = strings.TrimPrefix(value, "```")
	value = strings.TrimSuffix(value, "```")
	return strings.TrimSpace(value)
}
