package question

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func BuildHandler(service *Service) gin.HandlerFunc {
	return func(c *gin.Context) {
		var req BuildRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid request", "details": err.Error()})
			return
		}

		result, err := service.Build(c.Request.Context(), req)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "question generation failed", "details": err.Error()})
			return
		}

		c.JSON(http.StatusAccepted, result)
	}
}
