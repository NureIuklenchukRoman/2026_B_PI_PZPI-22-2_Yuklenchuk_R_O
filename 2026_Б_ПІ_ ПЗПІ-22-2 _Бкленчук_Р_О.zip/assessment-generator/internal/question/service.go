package question

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
)

type GeneratedQuestion struct {
	QuestionText       string   `json:"question_text"`
	Options            []string `json:"options"`
	CorrectAnswerIndex int      `json:"correct_answer_index"`
	DifficultyLevel    string   `json:"difficulty_level"`
	Tags               []string `json:"tags"`
}

type Generator interface {
	GenerateQuestion(ctx context.Context, chunk string, model string) (GeneratedQuestion, error)
}

type Store interface {
	SaveQuestions(ctx context.Context, testID string, generated []GeneratedQuestion) error
}

type Service struct {
	generator      Generator
	store          Store
	maxConcurrency int
}

func NewService(generator Generator, store Store, maxConcurrency int) *Service {
	if maxConcurrency <= 0 {
		maxConcurrency = 1
	}
	return &Service{
		generator:      generator,
		store:          store,
		maxConcurrency: maxConcurrency,
	}
}

type BuildRequest struct {
	TestID   string   `json:"test_id" binding:"required"`
	Chunks   []string `json:"chunks" binding:"required,gt=0"`
	Model    string   `json:"model"`
	SourceID string   `json:"source_id,omitempty"`
}

type BuildResult struct {
	TestID        string `json:"test_id"`
	QuestionsMade int    `json:"questions_created"`
	ChunksRead    int    `json:"chunks_read"`
}

func (s *Service) Build(ctx context.Context, req BuildRequest) (BuildResult, error) {
	if strings.TrimSpace(req.TestID) == "" {
		return BuildResult{}, errors.New("test_id is required")
	}

	chunks := compactChunks(req.Chunks)
	if len(chunks) == 0 {
		return BuildResult{}, errors.New("at least one non-empty chunk is required")
	}

	generated := make([]GeneratedQuestion, len(chunks))
	errCh := make(chan error, len(chunks))
	var wg sync.WaitGroup
	sem := make(chan struct{}, s.maxConcurrency)

	for idx, chunk := range chunks {
		wg.Add(1)
		go func(i int, text string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			question, err := s.generator.GenerateQuestion(ctx, text, req.Model)
			if err != nil {
				errCh <- fmt.Errorf("chunk %d: %w", i, err)
				return
			}

			if err := validateQuestion(&question); err != nil {
				errCh <- fmt.Errorf("chunk %d: %w", i, err)
				return
			}
			generated[i] = question
		}(idx, chunk)
	}

	wg.Wait()
	close(errCh)

	var errs []error
	for err := range errCh {
		errs = append(errs, err)
	}
	if len(errs) > 0 {
		return BuildResult{}, errors.Join(errs...)
	}

	if err := s.store.SaveQuestions(ctx, req.TestID, generated); err != nil {
		return BuildResult{}, err
	}

	return BuildResult{
		TestID:        req.TestID,
		QuestionsMade: len(generated),
		ChunksRead:    len(chunks),
	}, nil
}

func compactChunks(chunks []string) []string {
	result := make([]string, 0, len(chunks))
	for _, chunk := range chunks {
		chunk = strings.TrimSpace(chunk)
		if chunk != "" {
			result = append(result, chunk)
		}
	}
	return result
}

func validateQuestion(q *GeneratedQuestion) error {
	if strings.TrimSpace(q.QuestionText) == "" {
		return errors.New("question_text is required")
	}
	if len(q.Options) < 2 {
		return errors.New("at least two options are required")
	}
	if q.CorrectAnswerIndex < 0 || q.CorrectAnswerIndex >= len(q.Options) {
		return errors.New("correct_answer_index is out of range")
	}
	for _, option := range q.Options {
		if strings.TrimSpace(option) == "" {
			return errors.New("options cannot contain blank text")
		}
	}
	if len(q.Tags) == 0 {
		q.Tags = []string{"general"}
	}
	return nil
}
