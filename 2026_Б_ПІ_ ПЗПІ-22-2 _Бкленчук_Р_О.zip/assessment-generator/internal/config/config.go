package config

import (
	"fmt"
	"os"
	"strconv"
	"time"
)

type Config struct {
	ListenAddress            string
	DatabaseURL              string
	KeyStoreURL              string
	DefaultModel             string
	MaxConcurrentGenerations int
	RequestTimeout           time.Duration
}

func Load() Config {
	return Config{
		ListenAddress:            getEnv("LISTEN_ADDRESS", ":8080"),
		DatabaseURL:              databaseURL(),
		KeyStoreURL:              getEnv("KEY_STORE_URL", "http://credential-store.testify-credentials.svc.cluster.local:80"),
		DefaultModel:             getEnv("OPENROUTER_MODEL", "poolside/laguna-xs.2:free"),		MaxConcurrentGenerations: getEnvInt("MAX_CONCURRENT_GENERATIONS", 4),
		RequestTimeout:           time.Duration(getEnvInt("REQUEST_TIMEOUT_SECONDS", 90)) * time.Second,
	}
}

func databaseURL() string {
	if value := os.Getenv("DATABASE_URL"); value != "" {
		return value
	}

	user := getEnv("POSTGRES_USER", "admin")
	password := getEnv("POSTGRES_PASSWORD", "admin")
	host := getEnv("POSTGRES_HOST", "core-postgres.testify-core.svc.cluster.local")
	port := getEnv("POSTGRES_PORT", "5432")
	db := getEnv("POSTGRES_DB", "testify")

	return fmt.Sprintf("postgres://%s:%s@%s:%s/%s", user, password, host, port, db)
}

func getEnv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func getEnvInt(key string, fallback int) int {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(value)
	if err != nil || parsed <= 0 {
		return fallback
	}
	return parsed
}
