# Assessment Generator: Question Creation Service

Assessment Generator creates multiple-choice questions from segmented educational content and stores them in the Testify test schema.

## Role in Testify

`content-segmenter` sends text chunks to this service when uploaded content should become a test. Assessment Generator uses model credentials from `credential-store`, generates question and option data, and writes the result into the `core-api` Postgres schema.

Kubernetes role:

```text
namespace: testify-assessment
workload: assessment-generator
service: assessment-generator
```

## Technology

- Go HTTP service
- Postgres writes using the Testify core schema
- LLM-backed question generation
- Docker image and Helm chart deployment

## Installation

```bash
cd assessment-generator
go mod tidy
```

## Usage

Run locally:

```bash
task run
```

Run tests:

```bash
task test
```

Build and deploy:

```bash
task docker-build
task helm-upgrade
```

Main endpoint:

```text
POST /api/v1/questions/build
```

## License

Not specified.
