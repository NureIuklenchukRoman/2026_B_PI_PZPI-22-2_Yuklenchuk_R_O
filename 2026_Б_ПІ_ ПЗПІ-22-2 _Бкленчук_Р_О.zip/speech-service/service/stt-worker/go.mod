module stt-worker

go 1.23.0

require github.com/redis/go-redis/v9 v9.7.0
