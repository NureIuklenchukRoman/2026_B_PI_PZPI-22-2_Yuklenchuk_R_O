#!/usr/bin/env python3
import argparse
import json
import sys

from faster_whisper import WhisperModel


def parse_bool(value: str) -> bool:
    return value.lower() in {"1", "true", "yes", "y", "on"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Transcribe audio with faster-whisper.")
    parser.add_argument("--audio", required=True, help="Path to the audio file to transcribe.")
    parser.add_argument("--model", required=True, help="Model name or local model path.")
    parser.add_argument("--compute_type", default="int8", help="CTranslate2 compute type.")
    parser.add_argument("--output_format", default="json", choices=["json"])
    parser.add_argument("--word_timestamps", default="false")
    args = parser.parse_args()

    model = WhisperModel(args.model, device="cpu", compute_type=args.compute_type)
    segments, _ = model.transcribe(
        args.audio,
        word_timestamps=parse_bool(args.word_timestamps),
    )

    payload = {"segments": []}
    for segment in segments:
        item = {
            "text": segment.text,
            "start": segment.start,
            "end": segment.end,
        }
        if segment.words:
            item["words"] = [
                {
                    "word": word.word,
                    "start": word.start,
                    "end": word.end,
                }
                for word in segment.words
            ]
        payload["segments"].append(item)

    json.dump(payload, sys.stdout)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
