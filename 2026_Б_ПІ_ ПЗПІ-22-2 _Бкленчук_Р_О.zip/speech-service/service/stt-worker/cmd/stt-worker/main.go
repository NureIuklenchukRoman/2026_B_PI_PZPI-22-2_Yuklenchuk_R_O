package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"

	"stt-worker/internal/db"
	"stt-worker/internal/queue"
	"stt-worker/internal/whisper"
	"stt-worker/internal/worker"
	"stt-worker/pkg/config"
	"stt-worker/pkg/logging"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load config: %v", err)
	}
	logger := logging.New("stt-worker")

	client := redis.NewClient(&redis.Options{
		Addr:     cfg.RedisAddr,
		Password: cfg.RedisPassword,
		DB:       cfg.RedisDB,
	})
	pingCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	if err := client.Ping(pingCtx).Err(); err != nil {
		cancel()
		log.Fatalf("redis ping failed: %v", err)
	}
	cancel()

	processor := worker.NewProcessor(
		logger,
		queue.NewRedisQueue(client, cfg.MainQueue, cfg.ProcessingQueue, cfg.DeadLetterQueue),
		whisper.NewExecutor(cfg.WhisperBinaryPath, cfg.WhisperModelName, 20*time.Minute),
		db.NewMockRepo(cfg.ResultDir),
		cfg.MaxTaskRetries,
	)

	runCtx, runCancel := context.WithCancel(context.Background())
	doneCh := make(chan struct{})
	go func() {
		processor.RunConsumers(runCtx, cfg.Concurrency)
		close(doneCh)
	}()
	logger.Info("stt-worker started", "concurrency", cfg.Concurrency)

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh
	logger.Info("shutdown signal received")
	runCancel()

	select {
	case <-doneCh:
		logger.Info("all worker consumers stopped")
	case <-time.After(25 * time.Second):
		logger.Warn("worker shutdown timed out")
	}

	if err := client.Close(); err != nil {
		logger.Error("redis close failed", "error", err)
	}
	logger.Info("stt-worker stopped")
}
