package config

import (
	"errors"
	"os"
	"strconv"
)

type Config struct {
	RedisAddr     string
	RedisPassword string
	RedisDB       int

	MainQueue       string
	ProcessingQueue string
	DeadLetterQueue string

	WhisperBinaryPath string
	WhisperModelName  string
	ResultDir         string
	MaxTaskRetries    int
	Concurrency       int
}

func Load() (Config, error) {
	cfg := Config{
		RedisAddr:         getEnv("REDIS_ADDR", "redis:6379"),
		RedisPassword:     getEnv("REDIS_PASSWORD", ""),
		RedisDB:           getEnvAsInt("REDIS_DB", 0),
		MainQueue:         getEnv("REDIS_MAIN_QUEUE", "stt:queue:main"),
		ProcessingQueue:   getEnv("REDIS_PROCESSING_QUEUE", "stt:queue:processing"),
		DeadLetterQueue:   getEnv("REDIS_DEAD_LETTER_QUEUE", "stt:queue:dead"),
		WhisperBinaryPath: getEnv("WHISPER_BINARY_PATH", "/app/bin/faster-whisper"),
		WhisperModelName:  getEnv("WHISPER_MODEL_NAME", "large-v3"),
		ResultDir:         getEnv("RESULT_DIR", "/data/results"),
		MaxTaskRetries:    getEnvAsInt("MAX_TASK_RETRIES", 3),
		Concurrency:       getEnvAsInt("WORKER_CONCURRENCY", 2),
	}
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func (c Config) Validate() error {
	if c.RedisAddr == "" {
		return errors.New("REDIS_ADDR must not be empty")
	}
	if c.Concurrency < 1 {
		return errors.New("WORKER_CONCURRENCY must be >= 1")
	}
	if c.MaxTaskRetries < 0 {
		return errors.New("MAX_TASK_RETRIES must be >= 0")
	}
	return nil
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getEnvAsInt(key string, fallback int) int {
	raw := os.Getenv(key)
	if raw == "" {
		return fallback
	}
	v, err := strconv.Atoi(raw)
	if err != nil {
		return fallback
	}
	return v
}
