package types

import "time"

type EnqueueTask struct {
	JobID                 string  `json:"job_id"`
	ChunkID               string  `json:"chunk_id"`
	ChunkIndex            int     `json:"chunk_index"`
	TotalChunks           int     `json:"total_chunks"`
	FilePath              string  `json:"file_path"`
	GlobalStartTimeOffset float64 `json:"global_start_time_offset"`
	CallbackURL           string  `json:"callback_url,omitempty"`
	CallbackToken         string  `json:"callback_token,omitempty"`
	RetryCount            int     `json:"retry_count,omitempty"`
}

type WordTimestamp struct {
	Word  string  `json:"word"`
	Start float64 `json:"start"`
	End   float64 `json:"end"`
}

type Segment struct {
	Text  string          `json:"text"`
	Start float64         `json:"start"`
	End   float64         `json:"end"`
	Words []WordTimestamp `json:"words,omitempty"`
}

type TranscriptionOutput struct {
	ChunkID      string    `json:"chunk_id"`
	AudioPath    string    `json:"audio_path"`
	Segments     []Segment `json:"segments"`
	ProcessedAt  time.Time `json:"processed_at"`
	SourceOffset float64   `json:"source_offset"`
}
