package worker

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"sync"
	"time"

	"stt-worker/internal/alignment"
	"stt-worker/internal/db"
	"stt-worker/internal/queue"
	"stt-worker/internal/types"
	"stt-worker/internal/whisper"
)

type Processor struct {
	logger     *slog.Logger
	queue      *queue.RedisQueue
	whisper    *whisper.Executor
	repo       *db.MockRepo
	maxRetries int
}

func NewProcessor(
	logger *slog.Logger,
	q *queue.RedisQueue,
	whisperExec *whisper.Executor,
	repo *db.MockRepo,
	maxRetries int,
) *Processor {
	return &Processor{
		logger:     logger,
		queue:      q,
		whisper:    whisperExec,
		repo:       repo,
		maxRetries: maxRetries,
	}
}

func (p *Processor) RunConsumers(ctx context.Context, consumers int) {
	if consumers < 1 {
		consumers = 1
	}
	var wg sync.WaitGroup
	for i := 0; i < consumers; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			p.consumeLoop(ctx, id)
		}(i + 1)
	}
	wg.Wait()
}

func (p *Processor) consumeLoop(ctx context.Context, consumerID int) {
	log := p.logger.With("consumer_id", consumerID)
	for {
		select {
		case <-ctx.Done():
			log.Info("consumer stopping due to context cancellation")
			return
		default:
		}

		task, raw, err := p.queue.Claim(ctx, 5*time.Second)
		if err != nil {
			log.Error("failed to claim task", "error", err)
			time.Sleep(2 * time.Second)
			continue
		}
		if raw == "" {
			continue
		}
		if err := p.processTask(ctx, task, raw); err != nil {
			log.Error("task processing failed", "chunk_id", task.ChunkID, "retry_count", task.RetryCount, "error", err)
			if callbackErr := postChunkCallback(ctx, task, err); callbackErr != nil {
				log.Warn("chunk failure callback failed", "chunk_id", task.ChunkID, "error", callbackErr)
			}
			if requeueErr := p.queue.RequeueOrDeadLetter(ctx, raw, task, p.maxRetries); requeueErr != nil {
				log.Error("failed to requeue/dead-letter task", "chunk_id", task.ChunkID, "error", requeueErr)
			}
		}
	}
}

func (p *Processor) processTask(ctx context.Context, task types.EnqueueTask, raw string) error {
	segments, err := p.whisper.Transcribe(ctx, task.FilePath)
	if err != nil {
		return err
	}

	aligned := alignment.ShiftSegments(segments, task.GlobalStartTimeOffset)
	output := types.TranscriptionOutput{
		ChunkID:      task.ChunkID,
		AudioPath:    task.FilePath,
		Segments:     aligned,
		SourceOffset: task.GlobalStartTimeOffset,
	}
	if err := p.repo.SaveTranscription(ctx, output); err != nil {
		return err
	}
	if err := postChunkCallback(ctx, task, nil); err != nil {
		p.logger.Warn("chunk callback failed", "chunk_id", task.ChunkID, "error", err)
	}
	if err := p.queue.Ack(ctx, raw); err != nil {
		return err
	}
	p.logger.Info("task processed successfully", "chunk_id", task.ChunkID)
	return nil
}

func postChunkCallback(ctx context.Context, task types.EnqueueTask, taskErr error) error {
	if task.CallbackURL == "" {
		return nil
	}
	completed := task.ChunkIndex + 1
	failed := 0
	status := "processing"
	message := "Audio chunk transcribed"
	errMessage := ""
	if taskErr != nil {
		failed = 1
		completed = task.ChunkIndex
		message = "Audio chunk failed"
		errMessage = taskErr.Error()
	}
	payload := map[string]interface{}{
		"job_id":           task.JobID,
		"status":           status,
		"stage":            "transcribing",
		"message":          message,
		"total_chunks":     task.TotalChunks,
		"completed_chunks": completed,
		"failed_chunks":    failed,
	}
	if errMessage != "" {
		payload["error_message"] = errMessage
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, task.CallbackURL, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	if task.CallbackToken != "" {
		req.Header.Set("X-Internal-Token", task.CallbackToken)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		raw, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("callback status %d: %s", resp.StatusCode, string(raw))
	}
	return nil
}
