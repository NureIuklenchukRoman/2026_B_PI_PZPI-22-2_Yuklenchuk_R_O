package whisper

import (
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"time"

	"stt-worker/internal/types"
)

type Executor struct {
	binaryPath string
	modelName  string
	timeout    time.Duration
}

func NewExecutor(binaryPath, modelName string, timeout time.Duration) *Executor {
	return &Executor{binaryPath: binaryPath, modelName: modelName, timeout: timeout}
}

type cliResponse struct {
	Segments []types.Segment `json:"segments"`
}

func (e *Executor) Transcribe(ctx context.Context, audioPath string) ([]types.Segment, error) {
	cmdCtx, cancel := context.WithTimeout(ctx, e.timeout)
	defer cancel()

	cmd := exec.CommandContext(
		cmdCtx,
		e.binaryPath,
		"--audio", audioPath,
		"--model", e.modelName,
		"--compute_type", "int8",
		"--output_format", "json",
		"--word_timestamps", "true",
	)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("faster-whisper command failed: %w (output=%s)", err, string(output))
	}

	var payload cliResponse
	if err := json.Unmarshal(output, &payload); err != nil {
		return nil, fmt.Errorf("parse whisper json output: %w", err)
	}
	return payload.Segments, nil
}
