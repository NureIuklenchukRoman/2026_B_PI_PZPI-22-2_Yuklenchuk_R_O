package db

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"stt-worker/internal/types"
)

type MockRepo struct {
	resultDir string
}

func NewMockRepo(resultDir string) *MockRepo {
	return &MockRepo{resultDir: resultDir}
}

func (r *MockRepo) SaveTranscription(_ context.Context, output types.TranscriptionOutput) error {
	if err := os.MkdirAll(r.resultDir, 0o755); err != nil {
		return fmt.Errorf("create result dir: %w", err)
	}
	output.ProcessedAt = time.Now().UTC()
	filePath := filepath.Join(r.resultDir, output.ChunkID+".json")
	raw, err := json.MarshalIndent(output, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal output json: %w", err)
	}
	if err := os.WriteFile(filePath, raw, 0o644); err != nil {
		return fmt.Errorf("write output file: %w", err)
	}
	return nil
}
