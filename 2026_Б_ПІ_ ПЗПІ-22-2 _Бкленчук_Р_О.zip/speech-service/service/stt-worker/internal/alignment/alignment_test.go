package alignment

import (
	"testing"

	"stt-worker/internal/types"
)

func TestShiftSegments(t *testing.T) {
	in := []types.Segment{
		{
			Text:  "hello",
			Start: 1.0,
			End:   2.0,
			Words: []types.WordTimestamp{{Word: "hello", Start: 1.1, End: 1.9}},
		},
	}
	got := ShiftSegments(in, 10.0)
	if got[0].Start != 11.0 || got[0].End != 12.0 {
		t.Fatalf("unexpected shifted segment bounds: %+v", got[0])
	}
	if got[0].Words[0].Start != 11.1 || got[0].Words[0].End != 11.9 {
		t.Fatalf("unexpected shifted word bounds: %+v", got[0].Words[0])
	}
}
