package alignment

import "stt-worker/internal/types"

func ShiftSegments(segments []types.Segment, globalOffset float64) []types.Segment {
	out := make([]types.Segment, 0, len(segments))
	for _, s := range segments {
		copied := s
		copied.Start = s.Start + globalOffset
		copied.End = s.End + globalOffset
		if len(s.Words) > 0 {
			copied.Words = make([]types.WordTimestamp, 0, len(s.Words))
			for _, w := range s.Words {
				copied.Words = append(copied.Words, types.WordTimestamp{
					Word:  w.Word,
					Start: w.Start + globalOffset,
					End:   w.End + globalOffset,
				})
			}
		}
		out = append(out, copied)
	}
	return out
}
