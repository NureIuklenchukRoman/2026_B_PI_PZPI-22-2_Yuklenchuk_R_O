package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	"stt-worker/internal/types"
)

type RedisQueue struct {
	client          *redis.Client
	mainQueue       string
	processingQueue string
	deadLetterQueue string
}

func NewRedisQueue(client *redis.Client, main, processing, dead string) *RedisQueue {
	return &RedisQueue{
		client:          client,
		mainQueue:       main,
		processingQueue: processing,
		deadLetterQueue: dead,
	}
}

func (q *RedisQueue) Claim(ctx context.Context, blockFor time.Duration) (types.EnqueueTask, string, error) {
	raw, err := q.client.BRPopLPush(ctx, q.mainQueue, q.processingQueue, blockFor).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return types.EnqueueTask{}, "", nil
		}
		return types.EnqueueTask{}, "", fmt.Errorf("claim task via BRPOPLPUSH: %w", err)
	}
	if raw == "" {
		return types.EnqueueTask{}, "", nil
	}
	var task types.EnqueueTask
	if err := json.Unmarshal([]byte(raw), &task); err != nil {
		return types.EnqueueTask{}, raw, fmt.Errorf("unmarshal claimed task: %w", err)
	}
	return task, raw, nil
}

func (q *RedisQueue) Ack(ctx context.Context, raw string) error {
	if err := q.client.LRem(ctx, q.processingQueue, 1, raw).Err(); err != nil {
		return fmt.Errorf("ack task from processing queue: %w", err)
	}
	return nil
}

func (q *RedisQueue) RequeueOrDeadLetter(ctx context.Context, raw string, task types.EnqueueTask, maxRetries int) error {
	_ = q.client.LRem(ctx, q.processingQueue, 1, raw).Err()
	task.RetryCount++

	updatedRaw, err := json.Marshal(task)
	if err != nil {
		return fmt.Errorf("marshal task for retry: %w", err)
	}
	if task.RetryCount > maxRetries {
		if err := q.client.LPush(ctx, q.deadLetterQueue, updatedRaw).Err(); err != nil {
			return fmt.Errorf("push to dead-letter queue: %w", err)
		}
		return nil
	}
	if err := q.client.LPush(ctx, q.mainQueue, updatedRaw).Err(); err != nil {
		return fmt.Errorf("requeue task to main queue: %w", err)
	}
	return nil
}
