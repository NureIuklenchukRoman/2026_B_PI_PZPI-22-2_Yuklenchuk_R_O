package config

import (
	"errors"
	"fmt"
	"os"
	"strconv"
)

type Config struct {
	HTTPPort string

	RedisAddr     string
	RedisPassword string
	RedisDB       int

	MainQueue       string
	PrepareQueue    string
	ProcessingQueue string
	DeadLetterQueue string

	SileroModelPath string
	ChunkDir        string
	ResultDir       string
	FFmpegPath      string

	ChunkWorkers int
}

func Load() (Config, error) {
	cfg := Config{
		HTTPPort:        getEnv("HTTP_PORT", "8080"),
		RedisAddr:       getEnv("REDIS_ADDR", "redis:6379"),
		RedisPassword:   getEnv("REDIS_PASSWORD", ""),
		RedisDB:         getEnvAsInt("REDIS_DB", 0),
		MainQueue:       getEnv("REDIS_MAIN_QUEUE", "stt:queue:main"),
		PrepareQueue:    getEnv("REDIS_PREPARE_QUEUE", "stt:queue:prepare"),
		ProcessingQueue: getEnv("REDIS_PROCESSING_QUEUE", "stt:queue:processing"),
		DeadLetterQueue: getEnv("REDIS_DEAD_LETTER_QUEUE", "stt:queue:dead"),
		SileroModelPath: getEnv("SILERO_MODEL_PATH", "/app/models/silero_vad.onnx"),
		ChunkDir:        getEnv("CHUNK_DIR", "/data/chunks"),
		ResultDir:       getEnv("RESULT_DIR", "/data/results"),
		FFmpegPath:      getEnv("FFMPEG_PATH", "ffmpeg"),
		ChunkWorkers:    getEnvAsInt("API_CHUNK_WORKERS", 4),
	}
	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func (c Config) Validate() error {
	if c.HTTPPort == "" {
		return errors.New("HTTP_PORT must not be empty")
	}
	if c.RedisAddr == "" {
		return errors.New("REDIS_ADDR must not be empty")
	}
	if c.ChunkWorkers < 1 {
		return errors.New("API_CHUNK_WORKERS must be >= 1")
	}
	return nil
}

func (c Config) HTTPAddress() string {
	return fmt.Sprintf(":%s", c.HTTPPort)
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getEnvAsInt(key string, fallback int) int {
	raw := os.Getenv(key)
	if raw == "" {
		return fallback
	}
	v, err := strconv.Atoi(raw)
	if err != nil {
		return fallback
	}
	return v
}
