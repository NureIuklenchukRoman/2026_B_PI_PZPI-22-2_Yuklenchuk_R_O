package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"stt-api/internal/api"
	"stt-api/internal/audio"
	"stt-api/internal/queue"
	"stt-api/internal/storage"
	"stt-api/internal/vad"
	"stt-api/pkg/config"
	"stt-api/pkg/logging"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("load config: %v", err)
	}
	logger := logging.New("stt-api")

	client := redis.NewClient(&redis.Options{
		Addr:     cfg.RedisAddr,
		Password: cfg.RedisPassword,
		DB:       cfg.RedisDB,
	})
	pingCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	if err := client.Ping(pingCtx).Err(); err != nil {
		cancel()
		log.Fatalf("redis ping failed: %v", err)
	}
	cancel()

	vadDetector := vad.NewDetector(cfg.SileroModelPath)
	if err := vadDetector.Load(); err != nil {
		logger.Warn("silero model unavailable, starting with duration-based fallback", "error", err, "model_path", cfg.SileroModelPath)
	}

	gin.SetMode(gin.ReleaseMode)
	app := gin.New()
	app.MaxMultipartMemory = 32 << 20
	app.Use(gin.Recovery())
	handler := api.NewHandler(
		logger,
		audio.NewExtractor(cfg.FFmpegPath, 10*time.Minute),
		vadDetector,
		storage.NewLocalChunkStore(cfg.ChunkDir, cfg.FFmpegPath),
		queue.NewRedisQueue(client, cfg.MainQueue, cfg.PrepareQueue),
		"/tmp/stt-api",
		cfg.ResultDir,
		cfg.ChunkWorkers,
	)
	handler.Register(app)

	server := &http.Server{
		Addr:    cfg.HTTPAddress(),
		Handler: app,
	}

	errCh := make(chan error, 1)
	runCtx, runCancel := context.WithCancel(context.Background())
	defer runCancel()
	handler.RunPrepareConsumers(runCtx, 1)

	go func() {
		errCh <- server.ListenAndServe()
	}()

	logger.Info("stt-api started", "addr", cfg.HTTPAddress(), "chunk_workers", cfg.ChunkWorkers)
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case sig := <-sigCh:
		logger.Info("shutdown signal received", "signal", sig.String())
	case err := <-errCh:
		if err != nil && err != http.ErrServerClosed {
			logger.Error("http listen failed", "error", err)
		}
	}

	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer shutdownCancel()
	runCancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		logger.Error("http shutdown failed", "error", err)
	}
	if err := client.Close(); err != nil {
		logger.Error("redis close failed", "error", err)
	}
	logger.Info("stt-api stopped")
}
