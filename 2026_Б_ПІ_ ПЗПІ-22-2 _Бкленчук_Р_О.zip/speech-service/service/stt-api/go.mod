module stt-api

go 1.23.0

require (
	github.com/gin-gonic/gin v1.10.1
	github.com/google/uuid v1.6.0
	github.com/redis/go-redis/v9 v9.7.0
)
