package storage

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"stt-api/internal/chunker"
)

type LocalChunkStore struct {
	chunkRoot  string
	ffmpegPath string
}

func NewLocalChunkStore(chunkRoot, ffmpegPath string) *LocalChunkStore {
	return &LocalChunkStore{chunkRoot: chunkRoot, ffmpegPath: ffmpegPath}
}

func (s *LocalChunkStore) SaveChunk(ctx context.Context, jobID string, plan chunker.ChunkPlan) (string, error) {
	targetDir := filepath.Join(s.chunkRoot, jobID)
	if err := os.MkdirAll(targetDir, 0o755); err != nil {
		return "", fmt.Errorf("create chunk directory: %w", err)
	}
	outPath := filepath.Join(targetDir, plan.ChunkID+".wav")

	cmdCtx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(
		cmdCtx,
		s.ffmpegPath,
		"-y",
		"-i", plan.InputWavPath,
		"-ss", fmt.Sprintf("%.3f", plan.StartSec),
		"-to", fmt.Sprintf("%.3f", plan.EndSec),
		"-ac", "1",
		"-ar", "16000",
		outPath,
	)
	if output, err := cmd.CombinedOutput(); err != nil {
		return "", fmt.Errorf("slice wav chunk: %w (output=%s)", err, string(output))
	}
	return outPath, nil
}
