package chunker

import (
	"fmt"
	"math"

	"stt-api/internal/vad"
)

const MaxChunkSeconds = 29.5

type ChunkPlan struct {
	ChunkID      string
	StartSec     float64
	EndSec       float64
	DurationSec  float64
	InputWavPath string
}

func BuildChunkPlan(inputWavPath, prefix string, boundaries []vad.SpeechBoundary) ([]ChunkPlan, error) {
	if len(boundaries) == 0 {
		return nil, fmt.Errorf("no boundaries detected")
	}

	var chunks []ChunkPlan
	seq := 0
	for _, b := range boundaries {
		if b.EndSec <= b.StartSec {
			continue
		}
		start := b.StartSec
		for start < b.EndSec {
			end := math.Min(start+MaxChunkSeconds, b.EndSec)
			chunks = append(chunks, ChunkPlan{
				ChunkID:      fmt.Sprintf("%s-%04d", prefix, seq),
				StartSec:     start,
				EndSec:       end,
				DurationSec:  end - start,
				InputWavPath: inputWavPath,
			})
			seq++
			start = end
		}
	}
	if len(chunks) == 0 {
		return nil, fmt.Errorf("no chunk produced from boundaries")
	}
	return chunks, nil
}
