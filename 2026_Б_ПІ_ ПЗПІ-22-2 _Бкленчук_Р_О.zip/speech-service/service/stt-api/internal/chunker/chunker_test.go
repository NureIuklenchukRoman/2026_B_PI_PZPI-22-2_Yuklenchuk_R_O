package chunker

import (
	"testing"

	"stt-api/internal/vad"
)

func TestBuildChunkPlanRespectsMaxChunk(t *testing.T) {
	boundaries := []vad.SpeechBoundary{{StartSec: 0, EndSec: 70}}
	chunks, err := BuildChunkPlan("audio.wav", "job1", boundaries)
	if err != nil {
		t.Fatalf("BuildChunkPlan returned error: %v", err)
	}
	if len(chunks) != 3 {
		t.Fatalf("expected 3 chunks, got %d", len(chunks))
	}
	for _, c := range chunks {
		if c.DurationSec > MaxChunkSeconds+0.0001 {
			t.Fatalf("chunk duration exceeded max: %.3f", c.DurationSec)
		}
	}
}
