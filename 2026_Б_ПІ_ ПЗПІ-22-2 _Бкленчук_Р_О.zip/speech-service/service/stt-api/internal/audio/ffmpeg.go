package audio

import (
	"context"
	"fmt"
	"os/exec"
	"time"
)

type Extractor struct {
	binaryPath string
	timeout    time.Duration
}

func NewExtractor(binaryPath string, timeout time.Duration) *Extractor {
	return &Extractor{binaryPath: binaryPath, timeout: timeout}
}

func (e *Extractor) ExtractToWav(ctx context.Context, inputMP4Path, outputWavPath string) error {
	cmdCtx, cancel := context.WithTimeout(ctx, e.timeout)
	defer cancel()

	cmd := exec.CommandContext(
		cmdCtx,
		e.binaryPath,
		"-y",
		"-i", inputMP4Path,
		"-vn",
		"-ac", "1",
		"-ar", "16000",
		outputWavPath,
	)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("ffmpeg extraction failed: %w (output=%s)", err, string(output))
	}
	return nil
}
