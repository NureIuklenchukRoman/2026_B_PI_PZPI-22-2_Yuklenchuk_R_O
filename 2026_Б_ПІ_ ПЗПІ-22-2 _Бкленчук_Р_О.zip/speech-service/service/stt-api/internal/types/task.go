package types

type EnqueueTask struct {
	JobID                 string  `json:"job_id"`
	ChunkID               string  `json:"chunk_id"`
	ChunkIndex            int     `json:"chunk_index"`
	TotalChunks           int     `json:"total_chunks"`
	FilePath              string  `json:"file_path"`
	GlobalStartTimeOffset float64 `json:"global_start_time_offset"`
	CallbackURL           string  `json:"callback_url,omitempty"`
	CallbackToken         string  `json:"callback_token,omitempty"`
	RetryCount            int     `json:"retry_count,omitempty"`
}

type PrepareTask struct {
	JobID         string `json:"job_id"`
	VideoPath     string `json:"video_path"`
	CallbackURL   string `json:"callback_url"`
	CallbackToken string `json:"callback_token,omitempty"`
	RetryCount    int    `json:"retry_count,omitempty"`
}
