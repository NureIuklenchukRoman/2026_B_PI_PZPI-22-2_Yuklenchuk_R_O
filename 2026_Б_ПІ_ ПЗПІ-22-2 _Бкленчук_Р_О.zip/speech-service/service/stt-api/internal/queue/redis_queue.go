package queue

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	"stt-api/internal/types"
)

type RedisQueue struct {
	client       *redis.Client
	mainQueue    string
	prepareQueue string
}

func NewRedisQueue(client *redis.Client, mainQueue string, prepareQueue string) *RedisQueue {
	return &RedisQueue{client: client, mainQueue: mainQueue, prepareQueue: prepareQueue}
}

func (q *RedisQueue) Enqueue(ctx context.Context, task types.EnqueueTask) error {
	raw, err := json.Marshal(task)
	if err != nil {
		return fmt.Errorf("marshal enqueue task: %w", err)
	}
	if err := q.client.LPush(ctx, q.mainQueue, raw).Err(); err != nil {
		return fmt.Errorf("push task to queue: %w", err)
	}
	return nil
}

func (q *RedisQueue) EnqueuePrepare(ctx context.Context, task types.PrepareTask) error {
	raw, err := json.Marshal(task)
	if err != nil {
		return fmt.Errorf("marshal prepare task: %w", err)
	}
	if err := q.client.LPush(ctx, q.prepareQueue, raw).Err(); err != nil {
		return fmt.Errorf("push prepare task to queue: %w", err)
	}
	return nil
}

func (q *RedisQueue) ClaimPrepare(ctx context.Context) (types.PrepareTask, string, error) {
	raw, err := q.client.BRPopLPush(ctx, q.prepareQueue, q.prepareQueue+":processing", 5*time.Second).Result()
	if err != nil {
		if err == redis.Nil {
			return types.PrepareTask{}, "", nil
		}
		return types.PrepareTask{}, "", fmt.Errorf("claim prepare task: %w", err)
	}
	var task types.PrepareTask
	if err := json.Unmarshal([]byte(raw), &task); err != nil {
		return types.PrepareTask{}, raw, fmt.Errorf("unmarshal prepare task: %w", err)
	}
	return task, raw, nil
}

func (q *RedisQueue) AckPrepare(ctx context.Context, raw string) error {
	if err := q.client.LRem(ctx, q.prepareQueue+":processing", 1, raw).Err(); err != nil {
		return fmt.Errorf("ack prepare task: %w", err)
	}
	return nil
}
