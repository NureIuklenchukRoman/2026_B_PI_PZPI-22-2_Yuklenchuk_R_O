package vad

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"os"
)

type SpeechBoundary struct {
	StartSec float64
	EndSec   float64
}

type Detector struct {
	modelPath string
	loaded    bool
}

func NewDetector(modelPath string) *Detector {
	return &Detector{modelPath: modelPath}
}

func (d *Detector) Load() error {
	if d.loaded {
		return nil
	}
	if _, err := os.Stat(d.modelPath); err != nil {
		return fmt.Errorf("silero model not found at %s: %w", d.modelPath, err)
	}
	d.loaded = true
	return nil
}

func (d *Detector) DetectBoundaries(_ context.Context, wavPath string) ([]SpeechBoundary, error) {
	if !d.loaded {
		return fallbackBoundaryFromWAV(wavPath)
	}
	return fallbackBoundaryFromWAV(wavPath)
}

func fallbackBoundaryFromWAV(wavPath string) ([]SpeechBoundary, error) {
	durationSec, err := wavDurationSeconds(wavPath)
	if err != nil {
		return nil, err
	}
	return []SpeechBoundary{{StartSec: 0, EndSec: durationSec}}, nil
}

func wavDurationSeconds(wavPath string) (float64, error) {
	f, err := os.Open(wavPath)
	if err != nil {
		return 0, fmt.Errorf("open wav for VAD: %w", err)
	}
	defer f.Close()

	header := make([]byte, 12)
	if _, err := io.ReadFull(f, header); err != nil {
		return 0, fmt.Errorf("read wav header for VAD: %w", err)
	}
	if string(header[0:4]) != "RIFF" || string(header[8:12]) != "WAVE" {
		return 0, fmt.Errorf("invalid wav header in %s", wavPath)
	}

	var byteRate uint32
	var dataSize uint32

	for {
		chunkHeader := make([]byte, 8)
		if _, err := io.ReadFull(f, chunkHeader); err != nil {
			if err == io.EOF || err == io.ErrUnexpectedEOF {
				break
			}
			return 0, fmt.Errorf("read wav chunk header for VAD: %w", err)
		}

		chunkID := string(chunkHeader[0:4])
		chunkSize := binary.LittleEndian.Uint32(chunkHeader[4:8])

		switch chunkID {
		case "fmt ":
			chunkData := make([]byte, chunkSize)
			if _, err := io.ReadFull(f, chunkData); err != nil {
				return 0, fmt.Errorf("read wav fmt chunk for VAD: %w", err)
			}
			if len(chunkData) >= 12 {
				byteRate = binary.LittleEndian.Uint32(chunkData[8:12])
			}
		case "data":
			dataSize = chunkSize
			if _, err := f.Seek(int64(chunkSize), io.SeekCurrent); err != nil {
				return 0, fmt.Errorf("seek wav data chunk for VAD: %w", err)
			}
		default:
			if _, err := f.Seek(int64(chunkSize), io.SeekCurrent); err != nil {
				return 0, fmt.Errorf("skip wav chunk for VAD: %w", err)
			}
		}

		if chunkSize%2 == 1 {
			if _, err := f.Seek(1, io.SeekCurrent); err != nil {
				return 0, fmt.Errorf("skip wav padding for VAD: %w", err)
			}
		}

		if byteRate > 0 && dataSize > 0 {
			break
		}
	}

	if byteRate == 0 || dataSize == 0 {
		return 0, fmt.Errorf("invalid wav metadata in %s", wavPath)
	}
	durationSec := float64(dataSize) / float64(byteRate)
	if durationSec <= 0 {
		return 0, fmt.Errorf("invalid wav duration in %s", wavPath)
	}
	return durationSec, nil
}
