package api

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"stt-api/internal/audio"
	"stt-api/internal/chunker"
	"stt-api/internal/queue"
	"stt-api/internal/storage"
	"stt-api/internal/types"
	"stt-api/internal/vad"
)

type Handler struct {
	logger      *slog.Logger
	extractor   *audio.Extractor
	vad         *vad.Detector
	chunks      *storage.LocalChunkStore
	queue       *queue.RedisQueue
	workDir     string
	resultDir   string
	chunkWorker int
}

type CreateTranscriptionResponse struct {
	JobID      string   `json:"job_id"`
	ChunkCount int      `json:"chunk_count"`
	ChunkIDs   []string `json:"chunk_ids"`
}

func NewHandler(
	logger *slog.Logger,
	extractor *audio.Extractor,
	vadDetector *vad.Detector,
	chunkStore *storage.LocalChunkStore,
	q *queue.RedisQueue,
	workDir string,
	resultDir string,
	chunkWorker int,
) *Handler {
	if chunkWorker < 1 {
		chunkWorker = 1
	}
	return &Handler{
		logger:      logger,
		extractor:   extractor,
		vad:         vadDetector,
		chunks:      chunkStore,
		queue:       q,
		workDir:     workDir,
		resultDir:   resultDir,
		chunkWorker: chunkWorker,
	}
}

func (h *Handler) Register(app *gin.Engine) {
	app.GET("/healthz", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok"})
	})
	app.POST("/v1/transcriptions/jobs", h.createJob)
}

func (h *Handler) createJob(c *gin.Context) {
	requestID := uuid.NewString()
	log := h.logger.With("request_id", requestID)

	videoFile, err := c.FormFile("video")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "video file is required in multipart form field 'video'"})
		return
	}

	jobID := c.PostForm("job_id")
	if jobID == "" {
		jobID = uuid.NewString()
	}
	callbackURL := c.PostForm("callback_url")
	callbackToken := c.PostForm("callback_token")
	log = log.With("job_id", jobID)
	outputDir := filepath.Join(h.workDir, "jobs", jobID)
	if err := os.MkdirAll(outputDir, 0o755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to prepare workspace"})
		return
	}
	inputVideoPath := filepath.Join(outputDir, filepath.Base(videoFile.Filename))
	if err := c.SaveUploadedFile(videoFile, inputVideoPath); err != nil {
		log.Error("save uploaded video failed", "error", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to save uploaded video"})
		return
	}
	task := types.PrepareTask{
		JobID:         jobID,
		VideoPath:     inputVideoPath,
		CallbackURL:   callbackURL,
		CallbackToken: callbackToken,
	}
	if err := h.queue.EnqueuePrepare(c.Request.Context(), task); err != nil {
		log.Error("enqueue prepare task failed", "error", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to enqueue media preparation"})
		return
	}

	log.Info("transcription job accepted", "video_name", videoFile.Filename, "video_path", inputVideoPath)
	c.JSON(http.StatusAccepted, CreateTranscriptionResponse{
		JobID: jobID,
	})
}

func (h *Handler) RunPrepareConsumers(ctx context.Context, consumers int) {
	if consumers < 1 {
		consumers = 1
	}
	for i := 0; i < consumers; i++ {
		go h.prepareLoop(ctx, i+1)
	}
}

func (h *Handler) prepareLoop(ctx context.Context, consumerID int) {
	log := h.logger.With("prepare_consumer_id", consumerID)
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		task, raw, err := h.queue.ClaimPrepare(ctx)
		if err != nil {
			log.Error("failed to claim prepare task", "error", err)
			time.Sleep(2 * time.Second)
			continue
		}
		if raw == "" {
			continue
		}
		if err := h.prepareTask(ctx, task); err != nil {
			log.Error("prepare task failed", "job_id", task.JobID, "error", err)
			_ = postCallback(ctx, task, "failed", "audio_extracting", "Speech preparation failed", 0, 0, 0, "", err.Error())
		}
		if err := h.queue.AckPrepare(ctx, raw); err != nil {
			log.Error("failed to ack prepare task", "job_id", task.JobID, "error", err)
		}
	}
}

func (h *Handler) prepareTask(ctx context.Context, task types.PrepareTask) error {
	log := h.logger.With("job_id", task.JobID)
	outputDir := filepath.Dir(task.VideoPath)
	wavPath := filepath.Join(outputDir, "source.wav")

	_ = postCallback(ctx, task, "processing", "audio_extracting", "Extracting audio", 0, 0, 0, "", "")
	if err := h.extractor.ExtractToWav(ctx, task.VideoPath, wavPath); err != nil {
		return fmt.Errorf("audio extraction failed: %w", err)
	}
	_ = postCallback(ctx, task, "processing", "chunking", "Detecting speech and creating chunks", 0, 0, 0, "", "")

	boundaries, err := h.vad.DetectBoundaries(ctx, wavPath)
	if err != nil {
		return fmt.Errorf("voice activity detection failed: %w", err)
	}
	plans, err := chunker.BuildChunkPlan(wavPath, task.JobID, boundaries)
	if err != nil {
		return fmt.Errorf("chunk planning failed: %w", err)
	}

	chunkIDs := make([]string, 0, len(plans))
	for idx, plan := range plans {
		chunkPath, err := h.chunks.SaveChunk(ctx, task.JobID, plan)
		if err != nil {
			return fmt.Errorf("save chunk: %w", err)
		}
		chunkTask := types.EnqueueTask{
			JobID:                 task.JobID,
			ChunkID:               plan.ChunkID,
			ChunkIndex:            idx,
			TotalChunks:           len(plans),
			FilePath:              chunkPath,
			GlobalStartTimeOffset: plan.StartSec,
			CallbackURL:           task.CallbackURL,
			CallbackToken:         task.CallbackToken,
		}
		if err := h.queue.Enqueue(ctx, chunkTask); err != nil {
			return fmt.Errorf("enqueue chunk: %w", err)
		}
		chunkIDs = append(chunkIDs, plan.ChunkID)
		log.Info("chunk queued", "chunk_id", plan.ChunkID)
	}

	_ = postCallback(ctx, task, "processing", "transcribing", "Transcribing audio chunks", len(plans), 0, 0, "", "")
	transcript, failed, err := waitForTranscript(ctx, h.resultDir, chunkIDs)
	if err != nil {
		return err
	}
	_ = postCallback(ctx, task, "processing", "assembling_transcript", "Assembling transcript", len(plans), len(plans)-failed, failed, "", "")
	_ = postCallback(ctx, task, "queued", "segmenting_text", "Transcript ready for parsing", len(plans), len(plans)-failed, failed, transcript, "")
	return nil
}

func waitForTranscript(ctx context.Context, resultDir string, chunkIDs []string) (string, int, error) {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return "", 0, ctx.Err()
		case <-ticker.C:
			var parts []string
			missing := 0
			for _, id := range chunkIDs {
				raw, err := os.ReadFile(filepath.Join(resultDir, id+".json"))
				if err != nil {
					missing++
					continue
				}
				var payload struct {
					Segments []struct {
						Text string `json:"text"`
					} `json:"segments"`
				}
				if err := json.Unmarshal(raw, &payload); err != nil {
					return "", 0, err
				}
				for _, segment := range payload.Segments {
					parts = append(parts, strings.TrimSpace(segment.Text))
				}
			}
			if missing == 0 {
				return strings.Join(parts, " "), 0, nil
			}
		}
	}
}

func postCallback(ctx context.Context, task types.PrepareTask, status, stage, message string, total, completed, failed int, transcript, errorMessage string) error {
	if task.CallbackURL == "" {
		return nil
	}
	payload := map[string]interface{}{
		"job_id":           task.JobID,
		"status":           status,
		"stage":            stage,
		"message":          message,
		"total_chunks":     total,
		"completed_chunks": completed,
		"failed_chunks":    failed,
	}
	if transcript != "" {
		payload["transcript"] = transcript
	}
	if errorMessage != "" {
		payload["error_message"] = errorMessage
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, task.CallbackURL, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	if task.CallbackToken != "" {
		req.Header.Set("X-Internal-Token", task.CallbackToken)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		raw, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("callback status %d: %s", resp.StatusCode, string(raw))
	}
	return nil
}
