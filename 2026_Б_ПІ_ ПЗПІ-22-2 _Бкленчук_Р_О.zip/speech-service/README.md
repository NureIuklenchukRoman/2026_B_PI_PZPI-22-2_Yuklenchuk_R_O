# Speech Service: Speech-to-Text Pipeline

Speech Service handles media ingestion and asynchronous speech-to-text processing for Testify.

## Role in Testify

`interface-web` sends uploaded media to `speech-api`. The API extracts audio, splits work into chunks, and queues jobs. `speech-worker` processes queued chunks with faster-whisper, aligns timestamps, and persists transcription results through shared storage.

Kubernetes role:

```text
namespace: testify-speech
workloads: speech-api, speech-worker, speech-queue
services: speech-api, speech-queue
storage: speech-shared-data, speech-queue-data
scaling: KEDA ScaledObject speech-worker
```

## Technology

- Go API service
- Go worker service
- Redis queue with main, processing, and dead-letter lists
- ffmpeg for audio extraction
- Silero VAD model for speech activity detection
- faster-whisper for transcription
- Shared storage for chunks and results
- KEDA autoscaling for workers
- Docker images and Helm chart deployment

## Installation

```bash
cd speech-service
task tidy
```

Runtime dependencies include Redis, ffmpeg, faster-whisper, and the configured Silero VAD model.

## Usage

Run tests:

```bash
task test
```

Build binaries:

```bash
task build
```

Build and push images:

```bash
task docker:push
```

Deploy a performance tier:

```bash
task release:balanced
task release:quality
task release:throughput
```

## License

Not specified.
